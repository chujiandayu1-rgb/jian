var content=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=[`input#email`,`input[name="email"]`,`input[type="email"]`,`input[autocomplete="email"]`],r=[`button[type="submit"]`,`form button:not([type="button"])`];function i(){if(location.hostname!==`chatgpt.com`&&location.hostname!==`auth.openai.com`)return!1;if(location.pathname.startsWith(`/auth/login`))return!0;let e=document.querySelector(`input#email, input[name="email"], input[type="email"], input[autocomplete="email"]`);return!!(e&&a(e)||location.hostname===`auth.openai.com`&&document.querySelector(`input[name="email"], input[type="email"]`))}function a(e){let t=e,n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.display!==`none`&&n.visibility!==`hidden`&&r.width>0&&r.height>0}async function o(e){let t=c(n);if(!t)return p(`没有找到邮箱输入框`);l(t,e),t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),await u();let r=s();return r?(r.disabled&&await d(r,2500),r.disabled?p(`继续按钮仍然不可点击`):(r.click(),f(`已填入邮箱并点击继续`))):p(`没有找到继续按钮`)}function s(){for(let e of r){let t=document.querySelector(e);if(t)return t}return Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim();return t===`继续`||t.toLowerCase()===`continue`})??null}function c(e){for(let t of e){let e=document.querySelector(t);if(e)return e}return null}function l(e,t){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set?.call(e,t)}function u(){return new Promise(e=>window.setTimeout(e,60))}function d(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function f(e){return{ok:!0,message:e}}function p(e){return{ok:!1,message:e}}var m=[`input[name="code"]`,`input[name="otp"]`,`input[autocomplete="one-time-code"]`,`input[inputmode="numeric"]`,`input[type="text"]`];function h(){if(location.hostname!==`auth.openai.com`||!location.pathname.startsWith(`/email-verification`))return!1;let e=(document.body?.textContent||``).toLowerCase();return!(e.includes(`已验证`)||e.includes(`verified`)||e.includes(`email verified`))}async function g(e){let t=e.replace(/\D/g,``);if(!t)return C(`验证码不能为空`);let n=y();if(!n)return C(`没有找到验证码输入框`);if(await _(n,t),await v(200),!n.value)return C(`验证码未写入输入框（React 框架兼容问题）`);let r=b();return r?(r.disabled&&await x(r,3e3),r.disabled?C(`验证码继续按钮仍然不可点击`):(r.click(),S(`已填入验证码并点击继续`))):C(`没有找到验证码继续按钮`)}async function _(e,t){if(e.focus(),e.dispatchEvent(new FocusEvent(`focus`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusin`,{bubbles:!0})),await v(100),e.select(),document.execCommand(`selectAll`),document.execCommand(`delete`),await v(50),!document.execCommand(`insertText`,!1,t)||e.value!==t){let n=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),`value`)?.set||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))}await v(100),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function v(e){return new Promise(t=>window.setTimeout(t,e))}function y(){for(let e of m){let t=document.querySelector(e);if(t)return t}return Array.from(document.querySelectorAll(`input`)).find(e=>{let t=[e.placeholder,e.ariaLabel,e.name,e.id].join(` `).toLowerCase();return t.includes(`code`)||t.includes(`otp`)||t.includes(`验证`)})??null}function b(){return document.querySelector(`button[type="submit"]`)||(Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim();return t===`继续`||t.toLowerCase()===`continue`})??null)}function x(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function S(e){return{ok:!0,message:e}}function C(e){return{ok:!1,message:e}}var w=[`input[name="name"]`,`input[name="fullName"]`,`input[autocomplete="name"]`,`input[type="text"]`],T=[`input[name="age"]`,`input[inputmode="numeric"]`,`input[type="number"]`,`input[type="text"]`],E=[`Arlen`,`Brennan`,`Calvin`,`Darian`,`Elliot`,`Finley`,`Gavin`,`Harlan`,`Jasper`,`Kieran`,`Landon`,`Morgan`,`Nolan`,`Parker`,`Rowan`,`Sawyer`,`Tristan`,`Warren`];function D(){return location.hostname===`auth.openai.com`&&location.pathname.startsWith(`/about-you`)}async function O(){let e=ee(),t=te(e);if(!e)return de(`没有找到全名输入框`);if(!t)return de(`没有找到年龄输入框`);let n=ce(),r=String(le(25,55));if(await k(e,n),await A(300),await k(t,r),await A(300),!e.value&&!t.value)return de(`资料填写失败：值未写入输入框`);let i=oe();return i?(i.disabled&&await se(i,3e3),i.disabled?de(`完成账户创建按钮仍然不可点击`):(i.click(),ue(`已填写 ${n} / ${r} 并点击创建`))):de(`没有找到完成账户创建按钮`)}async function k(e,t){if(e.focus(),e.dispatchEvent(new FocusEvent(`focus`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusin`,{bubbles:!0})),await A(100),e.select(),document.execCommand(`selectAll`),document.execCommand(`delete`),await A(50),!document.execCommand(`insertText`,!1,t)||e.value!==t){let n=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),`value`)?.set||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))}await A(100),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`blur`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusout`,{bubbles:!0}))}function A(e){return new Promise(t=>window.setTimeout(t,e))}function ee(){let e=ne([`全名`,`名字`,`name`,`full name`]);if(e)return e;for(let e of w){let t=document.querySelector(e);if(t&&!ae(t))return t}return ie().find(e=>!ae(e))??null}function te(e){let t=ne([`年龄`,`age`]);if(t&&t!==e)return t;for(let t of T){let n=Array.from(document.querySelectorAll(t)).find(t=>t!==e&&ae(t));if(n)return n}return ie().find(t=>t!==e)??null}function ne(e){let t=ie();for(let n of t){let t=[n.name,n.id,n.placeholder,n.ariaLabel,n.getAttribute(`aria-labelledby`)?re(n.getAttribute(`aria-labelledby`)||``):``,n.closest(`label`)?.textContent||``,n.parentElement?.textContent||``].join(` `).toLowerCase();if(e.some(e=>t.includes(e.toLowerCase())))return n}return null}function re(e){return e.split(/\s+/).map(e=>document.getElementById(e)?.textContent||``).join(` `)}function ie(){return Array.from(document.querySelectorAll(`input`)).filter(e=>{let t=(e.type||`text`).toLowerCase();return[`text`,`number`,`tel`,``].includes(t)})}function ae(e){let t=[e.name,e.id,e.placeholder,e.ariaLabel,e.inputMode,e.type,e.parentElement?.textContent||``].join(` `).toLowerCase();return t.includes(`age`)||t.includes(`年龄`)||t.includes(`numeric`)||e.type===`number`}function oe(){return document.querySelector(`button[type="submit"]`)||(Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim().toLowerCase();return t.includes(`完成帐户创建`)||t.includes(`完成账户创建`)||t.includes(`create account`)||t.includes(`continue`)})??null)}function se(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function ce(){return E[le(0,E.length-1)]}function le(e,t){return Math.floor(Math.random()*(t-e+1))+e}function ue(e){return{ok:!0,message:e}}function de(e){return{ok:!1,message:e}}var fe=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;function pe(e){let t=e.trim();if(!t)return me(`empty`,`请输入邮箱或 Outlook 账号行`);let n=t.split(/\r?\n/).map(e=>e.trim()).find(Boolean)||``;if(n.includes(`----`)){let e=n.split(`----`).map(e=>e.trim()),t=e[0]||``;return fe.test(t)?e.length<4||!e[2]||!e[3]?me(`invalid`,`Outlook 行需要 email----password----client_id----refresh_token`):{ok:!0,mode:`outlook-line`,email:t,accountLine:n,message:`Outlook API 自动验证码`}:me(`invalid`,`Outlook 行里的邮箱格式不正确`)}return fe.test(n)?{ok:!0,mode:`email`,email:n,accountLine:``,message:`单邮箱模式，验证码手动输入`}:me(`invalid`,`邮箱格式不正确`)}function me(e,t){return{ok:!1,mode:e,email:``,accountLine:``,message:t}}var he=/"accessToken"\s*:\s*"([^"]+)"/,ge=/"accessToken"\s*:\s*"?([A-Za-z0-9_.-]+)/,_e=/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/,j={planName:`chatgptplusplan`,uiMode:`hosted`,region:`US`,workspaceName:`MyTeam`,seatQuantity:5};function ve(e){let t=String(e||``).trim();if(!t)throw Error(`请输入包含 accessToken 的 JSON 或字符串`);let n=we(t)||Ee(t)||De(t);if(!n)throw Error(`未找到 accessToken`);if(n.split(`.`).length!==3)throw Error(`accessToken 格式不正确`);return n}function ye(e){let t=Oe(e)?e:{};return{planName:be(t.planName),uiMode:xe(t.uiMode),region:Se(t.region||t.country),workspaceName:String(t.workspaceName||t.workspace_name||j.workspaceName).trim()||j.workspaceName,seatQuantity:Ce(t.seatQuantity)}}function be(e){return e===`chatgptplusplan`||e===`chatgptteamplan`?e:j.planName}function xe(e){return e===`hosted`?`hosted`:`custom`}function Se(e){let t=String(e||j.region).trim().toUpperCase();return t===`ID`||t===`DE`||t===`JP`||t===`US`?t:j.region}function Ce(e){let t=Number(e||j.seatQuantity);if(!Number.isInteger(t)||t<1)throw Error(`team_plan_data.seat_quantity 必须是大于 0 的整数`);return t}function we(e){try{return Te(JSON.parse(e))}catch{return``}}function Te(e,t=0){if(!Oe(e)||t>4)return``;if(typeof e.accessToken==`string`)return e.accessToken.trim();for(let n of Object.values(e)){let e=Te(n,t+1);if(e)return e}return``}function Ee(e){let t=he.exec(e);if(t?.[1])return t[1].trim();let n=ge.exec(e);if(!n?.[1])return``;let r=n[1].trim().replace(/[",}\]\s]+$/,``);return _e.exec(r)?.[0]?.trim()||r}function De(e){return _e.exec(e)?.[0]?.trim()||``}function Oe(e){return!!(e&&typeof e==`object`)}var ke=`http://127.0.0.1:8787`,Ae=`http://localhost:1455/auth/callback`,M=`opx.registerAssist.state`,je={rawInput:``,email:``,accountLine:``,inputMode:`empty`,autoOtp:!1,apiBase:ke,otpRequestedAt:0,updatedAt:0},Me={checkoutOptions:j,updatedAt:0},N={codeVerifier:``,codeChallenge:``,state:``,redirectUri:Ae,authUrl:``,email:``,password:``,startedAt:0,callbackUrl:``,codeParam:``,exchangeStatus:`idle`,exchangeMessage:``,credentials:null,cpaJson:``,sub2apiJson:``,updatedAt:0},Ne={rawInput:``,history:[],updatedAt:0};async function P(){return I((await t.storage.local.get(M))[M])}async function Pe(e){let n=I({...await P(),activeTab:e});return await t.storage.local.set({[M]:n}),n}async function Fe(e){let n=I({...await P(),panelCollapsed:e});return await t.storage.local.set({[M]:n}),n}async function Ie(){return(await P()).register}async function Le(e){let n=await P(),r=Ge({...n.register,...e,updatedAt:Date.now()}),i=I({...n,register:r});return await t.storage.local.set({[M]:i}),i.register}async function Re(){return(await P()).linkExtractor}async function ze(e){let n=await P(),r=Ke({...n.linkExtractor,...e,updatedAt:Date.now()}),i=I({...n,linkExtractor:r});return await t.storage.local.set({[M]:i}),i.linkExtractor}async function Be(){return(await P()).oauth}async function F(e){let n=await P(),r=qe({...n.oauth,...e,updatedAt:Date.now()}),i=I({...n,oauth:r});return await t.storage.local.set({[M]:i}),i.oauth}async function Ve(){let e=await P(),n={...N,updatedAt:Date.now()},r=I({...e,oauth:n});return await t.storage.local.set({[M]:r}),r.oauth}async function He(){return(await P()).smsRelay}async function Ue(e){let n=await P(),r=Xe({...n.smsRelay,...e,updatedAt:Date.now()}),i=I({...n,smsRelay:r});return await t.storage.local.set({[M]:i}),i.smsRelay}function We(e){return e===`auto`||e===`register`||e===`link`||e===`oauth`||e===`address`||e===`sms`}function I(e){let t=L(e)?e:{},n=L(t.register)?t.register:t,r=L(t.linkExtractor)?t.linkExtractor:t,i=L(t.oauth)?t.oauth:N,a=L(t.smsRelay)?t.smsRelay:Ne;return{activeTab:We(String(t.activeTab||``))?t.activeTab:`auto`,panelCollapsed:!!t.panelCollapsed,register:Ge(n),linkExtractor:Ke(r),oauth:qe(i),smsRelay:Xe(a)}}function Ge(e){let t=L(e)?e:{};return{rawInput:String(t.rawInput||je.rawInput),email:String(t.email||je.email),accountLine:String(t.accountLine||je.accountLine),inputMode:Qe(t.inputMode),autoOtp:!!t.autoOtp,apiBase:String(t.apiBase||je.apiBase),otpRequestedAt:Number(t.otpRequestedAt||je.otpRequestedAt),updatedAt:Number(t.updatedAt||je.updatedAt)}}function Ke(e){let t=L(e)?e:{};return{checkoutOptions:ye(t.checkoutOptions||Me.checkoutOptions),updatedAt:Number(t.updatedAt||Me.updatedAt)}}function qe(e){let t=L(e)?e:{};return{codeVerifier:String(t.codeVerifier||N.codeVerifier),codeChallenge:String(t.codeChallenge||N.codeChallenge),state:String(t.state||N.state),redirectUri:String(t.redirectUri||N.redirectUri),authUrl:String(t.authUrl||N.authUrl),email:String(t.email||N.email),password:String(t.password||N.password),startedAt:Number(t.startedAt||N.startedAt),callbackUrl:String(t.callbackUrl||N.callbackUrl),codeParam:String(t.codeParam||N.codeParam),exchangeStatus:Ye(t.exchangeStatus),exchangeMessage:String(t.exchangeMessage||N.exchangeMessage),credentials:Je(t.credentials),cpaJson:String(t.cpaJson||N.cpaJson),sub2apiJson:String(t.sub2apiJson||N.sub2apiJson),updatedAt:Number(t.updatedAt||N.updatedAt)}}function Je(e){if(!L(e))return null;let t=String(e.access_token||``).trim();return t?{access_token:t,account_id:String(e.account_id||``),disabled:!!e.disabled,email:String(e.email||``),expired:String(e.expired||``),id_token:String(e.id_token||``),last_refresh:String(e.last_refresh||``),refresh_token:String(e.refresh_token||``),type:`codex`}:null}function Ye(e){return e===`pending`||e===`success`||e===`error`?e:`idle`}function Xe(e){let t=L(e)?e:{},n=Array.isArray(t.history)?t.history.map(Ze).filter(e=>!!e):Ne.history;return{rawInput:String(t.rawInput||Ne.rawInput),history:n,updatedAt:Number(t.updatedAt||Ne.updatedAt)}}function Ze(e){if(!L(e))return null;let t=String(e.phone||``).trim(),n=String(e.code||``).trim();if(!t||!n)return null;let r=Number(e.receivedAt||0)||Date.now();return{id:String(e.id||`${t}-${n}-${r}`),phone:t,code:n,message:String(e.message||``).trim(),receivedAt:r}}function Qe(e){return e===`email`||e===`outlook-line`||e===`invalid`?e:`empty`}function L(e){return!!(e&&typeof e==`object`)}var $e=!1;function et(){return{getPageState:tt,loadState:Ie,saveInput:async e=>{let t=pe(e);return Le({rawInput:e,email:t.email,accountLine:t.accountLine,inputMode:t.mode,autoOtp:t.mode===`outlook-line`})},fillEmailFromInput:async()=>{let e=pe((await Ie()).rawInput);return e.ok?i()?(await Le({email:e.email,accountLine:e.accountLine,inputMode:e.mode,autoOtp:e.mode===`outlook-line`,otpRequestedAt:Date.now()}),o(e.email)):R(`当前页面不是 ChatGPT 登录页`):R(e.message)},fillOtp:async e=>h()?g(e):R(`当前页面不是邮箱验证码页`),waitForOutlookOtp:async()=>{if(!h())return R(`当前页面不是邮箱验证码页`);let e=await Ie();if(!e.accountLine)return R(`当前输入不是 Outlook 账号行，不能自动接收验证码`);let n=await t.runtime.sendMessage({type:`opx:wait-outlook-otp`,accountLine:e.accountLine,apiBase:e.apiBase,since:e.otpRequestedAt||e.updatedAt||Date.now(),timeoutMs:18e4,intervalMs:5e3});if(!nt(n))return R(`Outlook API 没有返回有效结果`);if(!n.ok||!n.code)return n;let r=await g(n.code);return{...r,code:n.code,message:r.ok?`已收到并提交验证码：${n.code}`:r.message}},fillProfileAndCreate:async()=>D()?O():R(`当前页面不是资料填写页`),autoRunForCurrentPage:async()=>{!D()||$e||($e=!0,await rt(),await O())}}}function tt(){return i()?{kind:`login`,label:`ChatGPT 登录页`,canFillEmail:!0,canFillOtp:!1,canFillProfile:!1}:h()?{kind:`email-verification`,label:`邮箱验证码页`,canFillEmail:!1,canFillOtp:!0,canFillProfile:!1}:D()?{kind:`about-you`,label:`资料填写页`,canFillEmail:!1,canFillOtp:!1,canFillProfile:!0}:{kind:`unknown`,label:`未识别页面`,canFillEmail:!1,canFillOtp:!1,canFillProfile:!1}}function R(e){return{ok:!1,message:e}}function nt(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function rt(){return new Promise(e=>window.setTimeout(e,800))}var it=`opx.extension.settings`,at={payOpenAiEnabled:!0,payPalSignupEnabled:!0,countryCode:`US`,city:``,lastAddress:null,updatedAt:0},ot={addressAutofill:at,updatedAt:0},st=new Set([`RANDOM`,`US`,`CA`,`AU`,`JP`,`TW`,`KR`,`HK`,`GB`,`DE`,`SG`,`FR`,`IT`,`ES`,`NL`,`MY`,`RU`,`CN`,`TH`,`PH`,`AR`,`TR`,`VN`]);async function ct(){return dt((await t.storage.local.get(it))[it])}async function lt(e){let n=await ct(),r=ft({...n.addressAutofill,...e,updatedAt:Date.now()}),i=dt({...n,addressAutofill:r,updatedAt:Date.now()});return await t.storage.local.set({[it]:i}),i.addressAutofill}async function ut(){return(await ct()).addressAutofill}function dt(e){let t=_t(e)?e:{};return{addressAutofill:ft(t.addressAutofill),updatedAt:Number(t.updatedAt||ot.updatedAt)}}function ft(e){let t=_t(e)?e:{};return{payOpenAiEnabled:t.payOpenAiEnabled===void 0?at.payOpenAiEnabled:!!t.payOpenAiEnabled,payPalSignupEnabled:t.payPalSignupEnabled===void 0?at.payPalSignupEnabled:!!t.payPalSignupEnabled,countryCode:vt(t.countryCode||t.country),city:String(t.city||t.region||at.city),lastAddress:pt(t.lastAddress),updatedAt:Number(t.updatedAt||at.updatedAt)}}function pt(e){if(!_t(e))return null;let t=String(e.line1||``).trim(),n=String(e.city||``).trim(),r=String(e.countryCode||e.country||`US`).trim().toUpperCase(),i=String(e.state||``).trim(),a=r===`US`?i.toUpperCase():i,o=String(e.postalCode||``).trim();return!t||!n||!a||!o?null:{id:String(e.id||`${Date.now()}`),fullName:String(e.fullName||``).trim(),line1:t,line2:String(e.line2||``).trim(),city:n,state:a,stateFull:String(e.stateFull||``).trim(),postalCode:o,countryCode:r,countryLabel:String(e.countryLabel||``).trim(),countryPath:String(e.countryPath||``).trim(),phone:String(e.phone||``).trim(),identity:mt(e.identity),employment:ht(e.employment),creditCard:gt(e.creditCard),source:e.source===`fallback`?`fallback`:`meiguodizhi`,fetchedAt:Number(e.fetchedAt||0)}}function mt(e){let t=_t(e)?e:{};return{gender:String(t.gender||``).trim(),title:String(t.title||``).trim(),birthday:String(t.birthday||``).trim(),username:String(t.username||``).trim(),password:String(t.password||``).trim(),temporaryMail:String(t.temporaryMail||``).trim(),system:String(t.system||``).trim(),userAgent:String(t.userAgent||``).trim(),website:String(t.website||``).trim(),securityQuestion:String(t.securityQuestion||``).trim(),securityAnswer:String(t.securityAnswer||``).trim()}}function ht(e){let t=_t(e)?e:{};return{educationalBackground:String(t.educationalBackground||``).trim(),occupation:String(t.occupation||``).trim(),employmentStatus:String(t.employmentStatus||``).trim(),monthlySalary:String(t.monthlySalary||``).trim(),companySize:String(t.companySize||``).trim(),companyName:String(t.companyName||``).trim()}}function gt(e){let t=_t(e)?e:{},n=String(t.number||``).replace(/\D/g,``),r=String(t.last4||n.slice(-4)||``).replace(/\D/g,``).slice(-4);return{type:String(t.type||``).trim(),number:n,cvv:String(t.cvv||``).trim(),expires:String(t.expires||``).trim(),last4:r,maskedNumber:String(t.maskedNumber||(r?`**** **** **** ${r}`:``)).trim()}}function _t(e){return!!(e&&typeof e==`object`)}function vt(e){let t=String(e||at.countryCode).trim().toUpperCase();return st.has(t)?t:at.countryCode}var yt=[{code:`US`,label:`美国`,path:`/`},{code:`CA`,label:`加拿大`,path:`/ca-address`},{code:`AU`,label:`澳大利亚`,path:`/au-address`},{code:`JP`,label:`日本`,path:`/jp-address`},{code:`TW`,label:`台湾`,path:`/tw-address`},{code:`KR`,label:`韩国`,path:`/kr-address`},{code:`HK`,label:`香港`,path:`/hk-address`},{code:`GB`,label:`英国`,path:`/uk-address`},{code:`DE`,label:`德国`,path:`/de-address`},{code:`SG`,label:`新加坡`,path:`/sg-address`},{code:`FR`,label:`法国`,path:`/fr-address`},{code:`IT`,label:`意大利`,path:`/it-address`},{code:`ES`,label:`西班牙`,path:`/es-address`},{code:`NL`,label:`荷兰`,path:`/nl-address`},{code:`MY`,label:`马来西亚`,path:`/my-address`},{code:`RU`,label:`俄罗斯`,path:`/ru-address`},{code:`CN`,label:`中国`,path:`/cn-address`},{code:`TH`,label:`泰国`,path:`/th-address`},{code:`PH`,label:`菲律宾`,path:`/ph-address`},{code:`AR`,label:`阿根廷`,path:`/ar-address`},{code:`TR`,label:`土耳其`,path:`/tr-address`},{code:`VN`,label:`越南`,path:`/vn-address`}],bt=8,xt=4,St=new Set([`data`,`message`,`msg`,`content`,`text`,`body`,`sms`,`otp`,`code`,`verifycode`,`verificationcode`,`captcha`,`result`,`value`]),Ct=new Set([`status`,`statuscode`,`httpstatus`,`ret`,`errno`,`errorcode`]),wt=/^(no\s*message|no\s*sms|empty|none|null|暂无|没有|未收到)$/i,Tt=/^(ok|success|successful|true|请求成功|成功)$/i;function Et(e){let t=[],n=[],r=new Set;return e.split(/\r?\n/).map(e=>e.trim()).filter(Boolean).forEach((e,i)=>{let a=e.indexOf(`----`);if(a<0){n.push(`第 ${i+1} 行缺少 ---- 分隔符`);return}let o=e.slice(0,a).trim(),s=e.slice(a+4).trim();if(!o||!s){n.push(`第 ${i+1} 行号码或 API 链接为空`);return}if(!zt(s)){n.push(`第 ${i+1} 行 API 链接不是 http/https 地址`);return}let c=`${o}\n${s}`;r.has(c)||(r.add(c),t.push({id:Bt(o,s),phone:o,url:s}))}),{targets:t,errors:n}}function Dt(e){let t=e.trim();return!t||wt.test(t)?``:t.match(RegExp(`\\b\\d{${xt},${bt}}\\b`,`g`))?.[0]||``}function Ot(e){let t=kt(e),n=t.map(e=>({...e,code:Dt(e.text)})).filter(e=>e.text&&!Mt(e.text)&&!Nt(e.text)).sort((e,t)=>At(t)-At(e))[0];return n?.code?{code:n.code,message:n.text}:{code:``,message:t.map(e=>e.text).find(e=>e&&!Mt(e)&&!Nt(e))||``}}function kt(e){let t=[],n=new WeakSet;return r(e,``,0),t;function r(e,t,o){if(!(e==null||o>6)){if(typeof e==`string`){i(e,t,o),a(e,t,o);return}if(typeof e==`number`){Lt(t)&&i(String(e),t,o);return}if(typeof e==`object`&&!n.has(e)){if(n.add(e),Array.isArray(e)){e.forEach((e,n)=>r(e,t||String(n),o+1));return}for(let[t,n]of Object.entries(e))It(t)||r(n,t,o+1)}}}function i(e,n,r){let i=e.trim();!i||i.length>600||It(n)||t.push({text:i,key:n,depth:r,fromPreferredField:Ft(n)})}function a(e,t,n){let i=e.trim();if(!(!i||!/^[{[]/.test(i)))try{r(JSON.parse(i),t,n+1)}catch{}}}function At(e){let t=0;return e.code&&(t+=100),e.fromPreferredField&&(t+=30),jt(e.text)&&(t+=20),Lt(e.key)&&(t+=10),Pt(e.text)&&(t-=8),t-=e.depth,t}function jt(e){return/code|验证码|驗證碼|verify|verification|security|otp|paypal|openai|chatgpt/i.test(e)}function Mt(e){return wt.test(e.trim())}function Nt(e){return Tt.test(e.trim())}function Pt(e){return/^[{[]/.test(e.trim())}function Ft(e){return St.has(Rt(e))}function It(e){return Ct.has(Rt(e))}function Lt(e){let t=Rt(e);return t===`otp`||t===`smscode`||t===`verifycode`||t===`verificationcode`||t===`captcha`}function Rt(e){return e.toLowerCase().replace(/[^a-z0-9]/g,``)}function zt(e){try{let t=new URL(e);return t.protocol===`http:`||t.protocol===`https:`}catch{return!1}}function Bt(e,t){return`${e}|${t}`}async function Vt(e){let n;try{n=await t.runtime.sendMessage({type:`opx:fetch-sms-relay`,url:e.url})}catch(t){return{kind:`error`,target:e,message:`请求失败：${Ut(t)}`}}if(!Ht(n)||!n.ok)return{kind:`error`,target:e,message:n?.message||`API 返回结果无效`};let r=Ot({raw:n.raw,data:n.data,text:n.text,message:n.message}),i=r.message,a=r.code;return a?{kind:`code`,target:e,code:a,message:i}:{kind:`empty`,target:e,message:i||n.data||n.message||`暂无短信`}}function Ht(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function Ut(e){return e instanceof Error?e.message:String(e)}var Wt=`opx.orchestrator.state`,Gt=`[OPX Auto]`,Kt=2e3,qt=5e3,Jt=18e4,Yt=!1,Xt=null,Zt=[],Qt={enabled:!1,paused:!1,currentStep:`idle`,statusMessage:`等待开始`,startedAt:0,completedSteps:[],lastError:``,generatedLink:``,updatedAt:0};function $t(e){return Zt.push(e),()=>{Zt=Zt.filter(t=>t!==e)}}async function en(){return _n((await t.storage.local.get(Wt))[Wt])}async function z(e){let n=_n({...await en(),...e,updatedAt:Date.now()});return await t.storage.local.set({[Wt]:n}),gn(n),n}async function tn(){if(!(await Ie()).rawInput.trim()){await z({enabled:!1,paused:!1,currentStep:`error`,lastError:`请先在注册 tab 输入 Outlook 账号行`,statusMessage:`请先输入账号`});return}await z({enabled:!0,paused:!1,currentStep:`idle`,statusMessage:`自动化已启动，正在检测页面...`,startedAt:Date.now(),completedSteps:[],lastError:``,generatedLink:``}),on()}async function nn(){cn(),await z({enabled:!1,paused:!0,currentStep:`idle`,statusMessage:`已停止`})}async function rn(){cn(),await t.storage.local.get(Wt),await t.storage.local.set({[Wt]:{...Qt,paused:!0,statusMessage:`已重置`,updatedAt:Date.now()}}),gn({...Qt,paused:!0,statusMessage:`已重置`,updatedAt:Date.now()})}async function an(){return(await en()).paused}function on(){Xt||(Xt=window.setInterval(()=>void ln(),Kt),ln())}async function sn(){let e=await en();e.paused||e.enabled&&e.currentStep!==`done`&&e.currentStep!==`error`&&on()}function cn(){Xt&&=(window.clearInterval(Xt),null)}async function ln(){if(!Yt){Yt=!0;try{let e=await en();if(!e.enabled||e.paused){cn();return}await un(e)}catch(e){console.warn(`${Gt} tick error`,e),await z({currentStep:`error`,lastError:yn(e),statusMessage:`出错：${yn(e)}`})}finally{Yt=!1}}}async function un(e){let n=location.hostname,r=location.href;if(i()){if(e.completedSteps.includes(`fill-email`)){await B(`wait-otp`,`已填过邮箱，等待跳转到验证码页...`);return}await B(`fill-email`,`检测到登录页，正在填入邮箱...`);let t=await et().fillEmailFromInput();t.ok?await V(`fill-email`,`邮箱已填入，等待验证码页...`):await B(`error`,t.message,t.message);return}if(h()){if(e.completedSteps.includes(`wait-otp`)){let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await V(`fill-profile`,`老号已登录，跳过资料填写`),await V(`fetch-session`,`Session 已读取：${e.session.email}`),await dn(e.session.accessToken);return}await B(`fill-profile`,`验证码已处理，等待资料页或登录跳转...`);return}await B(`wait-otp`,`检测到验证码页，正在等待 Outlook 验证码...`);let n=await et().waitForOutlookOtp();n.ok?await V(`wait-otp`,`验证码已填入：${n.code||``}`):await B(`error`,n.message,n.message);return}if(D()){if(e.completedSteps.includes(`fill-profile`)){await B(`fetch-session`,`资料已填，等待跳转到 chatgpt.com...`);return}await B(`fill-profile`,`检测到资料页，正在填写...`);let t=await et().fillProfileAndCreate();t.ok?await V(`fill-profile`,`资料已填写并提交`):await B(`error`,t.message,t.message);return}if(n===`chatgpt.com`&&!r.includes(`/auth`)&&!i()){if(e.completedSteps.includes(`generate-link`)&&e.generatedLink){await B(`open-checkout`,`正在打开支付链接...`),window.location.href=e.generatedLink;return}e.completedSteps.includes(`fill-profile`)||await V(`fill-profile`,`已登录，跳过资料填写`),await B(`fetch-session`,`正在读取 ChatGPT session...`);let n=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(!n?.ok||!n.session?.accessToken){await B(`fetch-session`,n?.message||`等待登录完成...`);return}e.completedSteps.includes(`fetch-session`)||await V(`fetch-session`,`Session 已读取：${n.session.email}`),await dn(n.session.accessToken);return}if(n===`pay.openai.com`){if(e.completedSteps.includes(`open-checkout`)||await V(`open-checkout`,`已到达支付页`),e.completedSteps.includes(`wait-payment-page`)){await B(`wait-payment-page`,`支付页已填写，等待跳转 PayPal...`);return}await B(`wait-payment-page`,`支付页已到达，正在选择 PayPal 并填写地址...`),await bn(3e3);let n=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:`US`,city:``});if(n?.ok&&n?.address){let e=await Mn(n.address);if(e.ok)await V(`wait-payment-page`,`支付页已填写 ${e.filled} 项，等待跳转 PayPal...`);else{xn(),await bn(1e3);let e=n.address;Sn(`#billingName`,e.fullName),Cn(`#billingCountry`,e.countryCode),await bn(600),Sn(`#billingAddressLine1`,e.line1),Sn(`#billingAddressLine2`,e.line2),Sn(`#billingLocality`,e.city),Sn(`#billingAdministrativeArea`,e.state),Sn(`#billingPostalCode`,e.postalCode),Sn(`#phoneNumber`,e.phone),wn(),await V(`wait-payment-page`,`支付页已填写地址（回退方式），等待跳转 PayPal...`)}}else await B(`wait-payment-page`,`获取地址失败，等待手动操作...`);return}if(n===`www.paypal.com`||n===`paypal.com`){if(e.completedSteps.includes(`wait-payment-page`)||await V(`wait-payment-page`,`已跳转 PayPal`),fn()){await B(`wait-paypal-sms`,`检测到 PayPal 短信验证页，正在接码...`);let e=await pn();e.ok?(await V(`wait-paypal-sms`,`短信验证码已填入：${e.code}`),await B(`done`,`全流程完成！`),await z({enabled:!1}),cn()):await B(`wait-paypal-sms`,e.message)}else await B(`wait-paypal-sms`,`PayPal 页面填写中，等待短信验证...`);return}if(n===`auth.openai.com`){if(e.completedSteps.includes(`wait-otp`)&&!e.completedSteps.includes(`fill-profile`)){if(D()){await B(`fill-profile`,`检测到资料页，正在填写...`);let e=await et().fillProfileAndCreate();e.ok?await V(`fill-profile`,`资料已填写并提交`):await B(`error`,e.message,e.message);return}let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await V(`fill-profile`,`已注册账号，跳过资料填写`),await V(`fetch-session`,`Session 已读取：${e.session.email}`),await dn(e.session.accessToken);return}await B(`fill-profile`,`验证完成，等待页面跳转到资料页...`);return}if(e.completedSteps.includes(`fill-profile`)&&!e.completedSteps.includes(`fetch-session`)){await B(`fetch-session`,`资料已提交，正在读取 session...`);let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await V(`fetch-session`,`Session 已读取：${e.session.email}`),await dn(e.session.accessToken);return}await B(`fetch-session`,`Session 还未生成，继续等待...`);return}if(e.completedSteps.includes(`fetch-session`)&&!e.completedSteps.includes(`generate-link`)){let e=(await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`}))?.session?.accessToken||``;if(e){await dn(e);return}await B(`generate-link`,`等待 session...`);return}await B(e.currentStep,`在 auth.openai.com 中间页，等待跳转...`);return}}async function dn(e){await B(`generate-link`,`正在生成 Plus 订阅链接...`);let n=await Re(),r=await t.runtime.sendMessage({type:`opx:create-checkout-link`,raw:e,options:n.checkoutOptions}),i=r?.link||r?.url||``;if(!r?.ok||!i){await B(`error`,r?.message||`生成链接失败`,r?.message||``);return}await z({generatedLink:i}),await V(`generate-link`,`链接已生成`),await B(`open-checkout`,`正在跳转到支付页...`),window.location.href=i}async function B(e,t,n){let r={currentStep:e,statusMessage:t};n&&(r.lastError=n),await z(r),console.info(`${Gt} [${e}] ${t}`)}async function V(e,t){let n=[...(await en()).completedSteps];n.includes(e)||n.push(e),await z({completedSteps:n,statusMessage:t}),console.info(`${Gt} [DONE] ${e}: ${t}`)}function fn(){if(document.querySelector(`input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="验证码"], input[aria-label*="code" i], input[placeholder*="code" i]`)||document.querySelector(`input[name="ciBasic-0"], input[id="ci-ciBasic-0"], input[name^="ciBasic-"]`))return!0;let e=(document.body?.textContent||``).toLowerCase();return e.includes(`enter the code`)||e.includes(`verification code`)||e.includes(`输入验证码`)||e.includes(`confirm your number`)}async function pn(){let e=hn((await He()).rawInput);if(!e.length)return{ok:!1,code:``,message:`没有配置接码 API 链接，请在接码 tab 输入`};let t=e[0],n=Date.now()+Jt;for(;Date.now()<n;){let e=await Vt(t);if(e.kind===`code`&&e.code)return mn(e.code),{ok:!0,code:e.code,message:`已收到验证码：${e.code}`};await bn(qt)}return{ok:!1,code:``,message:`等待短信验证码超时`}}function mn(e){let t=document.querySelectorAll(`input[name^="ciBasic-"]`);if(t.length>0&&e.length>=t.length){let n=Array.from(t).sort((e,t)=>(parseInt(e.name.replace(`ciBasic-`,``),10)||0)-(parseInt(t.name.replace(`ciBasic-`,``),10)||0));for(let t=0;t<n.length;t++){let r=n[t],i=e[t]||``,a=HTMLInputElement.prototype,o=Object.getOwnPropertyDescriptor(a,`value`);o?.set?o.set.call(r,i):r.value=i,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0}))}setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500);return}let n=document.querySelectorAll(`input[id^="ci-ciBasic-"]`);if(n.length>0&&e.length>=n.length){let t=Array.from(n).sort((e,t)=>(parseInt(e.id.replace(`ci-ciBasic-`,``),10)||0)-(parseInt(t.id.replace(`ci-ciBasic-`,``),10)||0));for(let n=0;n<t.length;n++){let r=t[n],i=e[n]||``,a=HTMLInputElement.prototype,o=Object.getOwnPropertyDescriptor(a,`value`);o?.set?o.set.call(r,i):r.value=i,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0}))}setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500);return}let r=document.querySelector(`input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="验证码"], input[aria-label*="code" i], input[placeholder*="code" i]`);if(!r)return;let i=HTMLInputElement.prototype,a=Object.getOwnPropertyDescriptor(i,`value`);a?.set?a.set.call(r,e):r.value=e,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0})),setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500)}function hn(e){let t=e.split(`
`).map(e=>e.trim()).filter(Boolean),n=[];for(let e of t){let t=e.split(/[\s|]+/),r=t.find(e=>e.startsWith(`http`)),i=t.find(e=>/^\+?\d{7,}$/.test(e))||``;r&&n.push({id:`${i||`auto`}-${Date.now()}`,phone:i,url:r})}return n}function gn(e){for(let t of Zt)try{t(e)}catch{}}function _n(e){if(!e||typeof e!=`object`)return{...Qt};let t=e;return{enabled:!!t.enabled,paused:!!t.paused,currentStep:vn(t.currentStep)?t.currentStep:`idle`,statusMessage:String(t.statusMessage||Qt.statusMessage),startedAt:Number(t.startedAt||0),completedSteps:Array.isArray(t.completedSteps)?t.completedSteps.filter(vn):[],lastError:String(t.lastError||``),generatedLink:String(t.generatedLink||``),updatedAt:Number(t.updatedAt||0)}}function vn(e){return typeof e==`string`&&[`idle`,`fill-email`,`wait-otp`,`fill-profile`,`fetch-session`,`generate-link`,`open-checkout`,`wait-payment-page`,`wait-paypal-sms`,`done`,`error`].includes(e)}function yn(e){return e instanceof Error?e.message:String(e)}function bn(e){return new Promise(t=>setTimeout(t,e))}function xn(){for(let e of[`[data-testid="paypal-accordion-item"]`,`#payment-method-accordion-item-title-paypal`,`button[data-testid="paypal-accordion-item-button"]`,`button[aria-label*="PayPal"]`,`[aria-label*="paypal" i]`]){let t=document.querySelector(e);if(t){t.click(),console.info(`[OPX Auto] 点击了 PayPal:`,e);return}}let e=document.querySelectorAll(`button, label, [role="button"], [role="radio"], div[class*="accordion"], div[class*="payment"]`);for(let t of Array.from(e)){let e=(t.textContent||``).toLowerCase();if(e.includes(`paypal`)&&!e.includes(`银行`)){t.click(),console.info(`[OPX Auto] 通过文本点击了 PayPal`);return}}let t=document.querySelectorAll(`input[type="radio"]`);for(let e of Array.from(t)){let t=e.closest(`label, div, li`);if(t&&(t.textContent||``).toLowerCase().includes(`paypal`)){e.click(),console.info(`[OPX Auto] 点击了 PayPal radio`);return}}console.warn(`[OPX Auto] 未找到 PayPal 选项`)}function Sn(e,t){if(!t)return;let n=document.querySelector(e);if(!n||n.value===t)return;let r=HTMLInputElement.prototype,i=Object.getOwnPropertyDescriptor(r,`value`);i?.set?i.set.call(n,t):n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),n.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function Cn(e,t){if(!t)return;let n=document.querySelector(e);if(!n)return;let r=Array.from(n.options).find(e=>e.value===t||e.text.toLowerCase().includes(t.toLowerCase()));r&&n.value!==r.value&&(n.value=r.value,n.dispatchEvent(new Event(`change`,{bubbles:!0})))}function wn(){let e=document.querySelectorAll(`input[type="checkbox"]`);for(let t of Array.from(e))if(!t.checked){let e=(t.closest(`label, div`)?.textContent||``).toLowerCase();(e.includes(`terms`)||e.includes(`consent`)||e.includes(`条款`)||e.includes(`同意`)||t.id.includes(`terms`))&&t.click()}}var H=`[OPX Pay Autofill]`,Tn=!1,En=!1,Dn=null,On=null,kn=``;function An(){Tn||location.hostname!==`pay.openai.com`||(Tn=!0,Yn(),Jn(),Xn(800))}async function jn(){if(!En){En=!0;try{if(await an()){console.info(`${H} paused by orchestrator`);return}let e=await ut();if(!e.payOpenAiEnabled){console.info(`${H} disabled`);return}let t=await Nn(e);if(!t){console.info(`${H} no address available`);return}let n=await Mn(t);console.info(`${H} ${n.message}`,{city:t.city,state:t.state,postalCode:t.postalCode,country:t.countryCode,source:t.source})}catch(e){console.warn(`${H} failed`,e)}finally{En=!1}}}async function Mn(e){if(location.hostname!==`pay.openai.com`)return{ok:!1,filled:0,message:`当前不是 pay.openai.com 页面`};In(),await rr(450),await nr(3e3);let t=await Fn(e);return{ok:t>0,filled:t,message:t>0?`已填写 OpenAI 支付页 ${t} 项`:`未找到可填写的 OpenAI 支付字段`}}async function Nn(e){let t=`${e.countryCode}|${e.city}`;return On&&kn===t?On:(On=await Pn(e),kn=t,On)}async function Pn(e){let n=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});return!ir(n)||!n.ok||!n.address?(console.warn(`${H} address fetch failed`,n),null):(await lt({lastAddress:n.address}),n.address)}async function Fn(e){let t=0;return t+=Ln(`#billingName`,e.fullName,!0),t+=zn(`#billingCountry`,e.countryCode,[e.countryLabel,e.countryCode]),document.querySelector(`#billingCountry`)&&await rr(550),t+=Ln(`#billingAddressLine1`,e.line1,!0),tr(),await rr(300),t+=Ln(`#billingAddressLine2`,e.line2,!0),t+=Ln(`#billingLocality`,e.city,!0),t+=Vn(`#billingAdministrativeArea`,e.state,[e.stateFull,e.state]),t+=Ln(`#billingPostalCode`,e.postalCode,!0),t+=Ln(`#phoneNumber`,e.phone,!1),t+=Rn(`billing address-line1`,e.line1),tr(),await rr(300),t+=Rn(`billing address-line2`,e.line2),t+=Rn(`billing address-level2`,e.city),t+=Rn(`billing postal-code`,e.postalCode),t+=Hn(`billing address-level1`,e.state,[e.stateFull,e.state]),t+=Bn(`billing country`,e.countryCode,[e.countryLabel,e.countryCode]),t+=Gn(),t}function In(){let e=document.querySelector(`#payment-method-accordion-item-title-paypal`);if(e?.checked||e?.getAttribute(`aria-checked`)===`true`)return!0;let t=document.querySelector(`#payment-method-label-paypal`);if(t&&U(t))return qn(t),console.info(`${H} 已点击 PayPal label`),!0;let n=document.querySelector(`button[data-testid="paypal-accordion-item-button"]`);if(n&&U(n))return qn(n),console.info(`${H} 已点击 PayPal button`),!0;if(e){let t=e.closest(`.PaymentMethodFormAccordionItemTitle, .flex-container.direction-row.align-items-center, label, [role="radio"]`);return t&&U(t)?(qn(t),console.info(`${H} 已点击 PayPal radio 容器`),!0):(qn(e),console.info(`${H} 已点击 PayPal radio`),!0)}let r=Array.from(document.querySelectorAll(`div, span, label`)).filter(U).find(e=>W(e.textContent)===`paypal`);return r?(qn(r),console.info(`${H} 通过文本匹配点击了 PayPal`),!0):(console.warn(`${H} 未找到 PayPal 选项`),!1)}function Ln(e,t,n){if(!t)return 0;let r=document.querySelector(e);return!Qn(r)||!U(r)||Zn(r)||!n&&r.value.trim()||r.value===t?0:(Wn(r,t),1)}function Rn(e,t){let n=`input[autocomplete="${er(e)}"], textarea[autocomplete="${er(e)}"]`,r=document.querySelector(n);return!Qn(r)||!U(r)||r.value===t||Zn(r)?0:(Wn(r,t),1)}function zn(e,t,n){let r=document.querySelector(e);return!$n(r)||!U(r)?0:Un(r,t,n)}function Bn(e,t,n){let r=document.querySelector(`select[autocomplete="${er(e)}"]`);return!$n(r)||!U(r)?0:Un(r,t,n)}function Vn(e,t,n){let r=document.querySelector(e);return $n(r)?U(r)?Un(r,t,n):0:Qn(r)?Ln(e,t,!0):0}function Hn(e,t,n){let r=document.querySelector(`select[autocomplete="${er(e)}"]`);return $n(r)?U(r)?Un(r,t,n):0:Rn(e,t||n[0]||``)}function Un(e,t,n){let r=Array.from(e.options).filter(e=>!e.disabled&&e.value),i=W(t),a=n.map(e=>W(e)).filter(Boolean),o=r.find(e=>W(e.value)===i)||r.find(e=>a.some(t=>W(`${e.text} ${e.value}`).includes(t)));return!o||e.value===o.value?0:(e.value=o.value,Kn(e),1)}function Wn(e,t){let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`);r?.set?r.set.call(e,t):e.value=t,Kn(e)}function Gn(){let e=0,t=Array.from(document.querySelectorAll(`input[type="checkbox"]`)).filter(U).filter(e=>!e.checked).filter(e=>{let t=W([e.id,e.name,e.getAttribute(`aria-label`),e.closest(`label`)?.textContent,e.parentElement?.textContent].join(` `));return t.includes(`terms`)||t.includes(`consent`)||t.includes(`使用条款`)||t.includes(`隐私政策`)||t.includes(`取消`)||e.id===`termsOfServiceConsentCheckbox`});for(let n of t)n.click(),e+=1;return e}function Kn(e){e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function qn(e){e.scrollIntoView({block:`center`,inline:`center`});for(let t of[`pointerdown`,`mousedown`,`pointerup`,`mouseup`,`click`]){let n=t.startsWith(`pointer`)?PointerEvent:MouseEvent;e.dispatchEvent(new n(t,{bubbles:!0,cancelable:!0,composed:!0,button:0,buttons:+!!t.endsWith(`down`),pointerId:1,pointerType:`mouse`}))}e.click()}function Jn(){new MutationObserver(()=>Xn(250)).observe(document.documentElement,{childList:!0,subtree:!0})}function Yn(){t.storage.onChanged.addListener((e,t)=>{t===`local`&&Object.keys(e).some(e=>e.includes(`settings`))&&(On=null,kn=``,Xn(100))})}function Xn(e){Dn&&window.clearTimeout(Dn),Dn=window.setTimeout(()=>{Dn=null,jn()},e)}function U(e){let t=e;if(`disabled`in t&&t.disabled)return!1;let n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.visibility!==`hidden`&&n.display!==`none`&&r.width>0&&r.height>0}function Zn(e){let t=W([e.getAttribute(`aria-label`),e.getAttribute(`placeholder`),e.getAttribute(`autocomplete`),e.getAttribute(`name`),e.getAttribute(`id`)].join(` `));return[`cc-number`,`card number`,`credit card`,`security code`,`cvc`,`cvv`,`expiry`,`expiration`].some(e=>t.includes(e))}function Qn(e){return!!(e&&(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))}function $n(e){return!!(e&&e instanceof HTMLSelectElement)}function W(e){return String(e||``).replace(/\s+/g,` `).trim().toLowerCase()}function er(e){return typeof CSS<`u`&&typeof CSS.escape==`function`?CSS.escape(e):e.replace(/"/g,`\\"`)}function tr(){let e=document.activeElement;e&&(e.dispatchEvent(new KeyboardEvent(`keydown`,{key:`Escape`,code:`Escape`,bubbles:!0})),e.dispatchEvent(new KeyboardEvent(`keyup`,{key:`Escape`,code:`Escape`,bubbles:!0})),e.blur());let t=document.querySelectorAll(`.pac-container`);for(let e of Array.from(t))e.style.display=`none`;let n=document.querySelectorAll(`a, button, span, div`);for(let e of Array.from(n)){let t=W(e.textContent||``);if((t.includes(`enter address manually`)||t.includes(`手动输入地址`)||t.includes(`manual`))&&U(e)){e.click();break}}}async function nr(e){let t=Date.now()+e,n=[`#billingName`,`#billingAddressLine1`,`#billingCountry`,`input[autocomplete="billing address-line1"]`,`input[name="billingName"]`];for(;Date.now()<t;){for(let e of n){let t=document.querySelector(e);if(t&&U(t))return!0}await rr(300)}return!1}function rr(e){return new Promise(t=>window.setTimeout(t,e))}function ir(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var ar=`[OPX PayPal Autofill]`,or=`opx.paypal.autofill.address`,sr=`opx.paypal.autofill.pendingManual`,cr=`data-opx-paypal-filled`,lr=`opx-paypal-random-fill`,ur=3,dr={AR:`Argentina`,AU:`Australia`,CA:`Canada`,CN:`China`,DE:`Germany`,ES:`Spain`,FR:`France`,GB:`United Kingdom`,HK:`Hong Kong`,IT:`Italy`,JP:`Japan`,KR:`South Korea`,MY:`Malaysia`,NL:`Netherlands`,PH:`Philippines`,RU:`Russia`,SG:`Singapore`,TH:`Thailand`,TR:`Turkey`,TW:`Taiwan`,US:`United States`,VN:`Vietnam`},fr=!1,pr=!1,mr=null,G=null,hr=null,gr=``,_r=0,vr=``;function yr(){fr||!Ei()||(fr=!0,ni(),ui(),ti(),gi()?pi(900):di(800))}async function br(e,t=!1,n=!0){if(!Ei())return{ok:!1,filled:0,message:`当前不是 PayPal 注册支付页`,countryChanged:!1};let r=await ut(),i=e||await Sr(r);if(!i)return{ok:!1,filled:0,message:`没有可用地址资料`,countryChanged:!1};vi(i),t&&!n&&fi(),t&&(Wr(),qr());let a=await Cr(i,n);return Gr(i,a.countryChanged,n),t&&!n&&(vr=Jr(i),a.countryChanged?(hi(),pi(1600)):_i()),{ok:a.filled>0||a.countryChanged,filled:a.filled,countryChanged:a.countryChanged,message:a.countryChanged?`已选择 PayPal 国家：${i.countryCode}，等待页面重新加载`:a.filled>0?`已填写 PayPal ${a.filled} 项`:`未找到可填写的 PayPal 字段`}}async function xr(){if(!pr&&!(vr&&gr===vr)){pr=!0;try{if(await an()){console.info(`${ar} paused by orchestrator`);return}if(!(await ut()).payPalSignupEnabled){console.info(`${ar} disabled`);return}let e=await br();console.info(`${ar} ${e.message}`),(!e.ok||Kr())&&(hr?.disconnect(),hr=null)}catch(e){console.warn(`${ar} failed`,e)}finally{pr=!1}}}async function Sr(e){if(G&&yi(G,e))return G;let n=mi();if(n&&yi(n,e))return G=n,G;let r=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});return!Pi(r)||!r.ok||!r.address?(console.warn(`${ar} address fetch failed`,r),null):(G=r.address,vi(r.address),await lt({lastAddress:r.address}),G)}async function Cr(e,t){let n=0;if(wr(e))return t&&di(1500),{filled:1,countryChanged:!0};let r=await Tr(e),i=xi(e.fullName),a=bi(e.creditCard.expires);return n+=K(Y.email,r,!0),n+=Dr(r),Or(r),n+=K(Y.phone,wi(e.phone,e.countryCode),!0),n+=K(Y.cardNumber,e.creditCard.number,!0),n+=K(Y.expiry,a.short,!0),n+=K(Y.csc,e.creditCard.cvv,!0),n+=K(Y.fullName,e.fullName,!0),n+=K(Y.firstName,i.first,!0),n+=K(Y.lastName,i.last,!0),n+=K(Y.address1,e.line1,!0),n+=K(Y.address2,e.line2,!0),n+=K(Y.city,e.city,!0),n+=kr(Y.state,e.state,[e.stateFull,e.state]),n+=K(Y.postalCode,e.postalCode,!0),n+=Ar(e,i),n+=kr(Y.expiryMonth,a.month,[a.month]),n+=kr(Y.expiryYear,a.year4,[a.year4,a.year2]),n>0&&setTimeout(()=>Di(),800),{filled:n,countryChanged:!1}}function wr(e){let t=Ir(Y.country);return!t||!q(t)?!1:Qr(t,e.countryCode,[e.countryCode,dr[e.countryCode]||``,e.countryLabel])}async function Tr(e){let t=await Ie(),n=pe(t.rawInput);return n.ok&&Mi(n.email)?n.email:Mi(t.email)?t.email:Mi(e.identity.temporaryMail)?e.identity.temporaryMail:Si(e)}function K(e,t,n){if(!t)return 0;let r=Fr(e);return!r||!q(r)?0:Er(r,t,n)}function Er(e,t,n){if(!t||!q(e))return 0;let r=e.value.trim();return e.getAttribute(cr)===`1`||Yr(r,t)?(e.setAttribute(cr,`1`),0):!n&&r?0:($r(e,t),e.setAttribute(cr,`1`),1)}function Dr(e){if(!e)return 0;let t=document.querySelector(`input#password`)||Fr(Y.password);if(!t||!q(t))return 0;let n=Ti(e);return Yr(t.value.trim(),n)?0:($r(t,n),1)}function Or(e){let t=si();if(!t)return;let n=Ti(e);Dr(n);let r=`opx-paypal-password-note`,i=`当前密码：${n}`,a=document.getElementById(r);a||(a=document.createElement(`div`),a.id=r,Object.assign(a.style,{color:`#93e4bd`,fontSize:`12px`,lineHeight:`18px`,margin:`4px 0 10px`,padding:`6px 10px`,border:`1px solid rgba(47, 209, 124, 0.36)`,borderRadius:`6px`,background:`rgba(15, 23, 42, 0.82)`,display:`block`}));let o=t.parentElement;o&&(o.insertBefore(a,t),a.textContent=i)}function kr(e,t,n){if(!t&&!n.some(Boolean))return 0;let r=Ir(e);return r&&q(r)?+!!Qr(r,t,n):K(e,t||n.find(Boolean)||``,!0)}function Ar(e,t){let n=Nr();if(!n)return 0;let r=Array.from(n.querySelectorAll(`input, textarea, select`)).filter(e=>(Ai(e)||ji(e))&&q(e)&&!Oi(e)&&!ki(e)),i=0;return i+=jr(n,[`first name`,`given name`],t.first,r[0]),i+=jr(n,[`last name`,`family name`,`surname`],t.last,r[1]),i+=jr(n,[`street address`,`address line 1`,`address 1`],e.line1,r[2]),i+=jr(n,[`apt`,`ste`,`bldg`,`address line 2`,`address 2`],e.line2,r[3]),i+=jr(n,[`city`,`locality`],e.city,r[4]),i+=Mr(n,[`state`,`province`,`region`],e.state,[e.stateFull,e.state],r[5]),i+=jr(n,[`zip`,`postal code`,`postcode`],e.postalCode,r[6]),i}function jr(e,t,n,r){let i=r&&Ai(r)?r:null,a=Pr(e,t,Ai)||i;return a?Er(a,n,!0):0}function Mr(e,t,n,r,i){let a=i&&ji(i)?i:null,o=Pr(e,t,ji)||a;if(o)return+!!Qr(o,n,r);let s=i&&Ai(i)?i:null,c=Pr(e,t,Ai)||s;return c?Er(c,n||r.find(Boolean)||``,!0):0}function Nr(){return Array.from(document.querySelectorAll(`fieldset, [role="group"], section, form > div`)).find(e=>{let t=J(e.textContent||``);return t.includes(`billing address`)&&(t.includes(`street address`)||t.includes(`address`))&&(t.includes(`first name`)||t.includes(`last name`))})||null}function Pr(e,t,n){let r=t.map(J).filter(Boolean);return Array.from(e.querySelectorAll(`input, textarea, select`)).filter(n).map(e=>({control:e,score:Br(e,r)})).filter(e=>e.score>0&&q(e.control)&&!Oi(e.control)).sort((e,t)=>t.score-e.score)[0]?.control||null}function Fr(e){for(let t of e){let e=Lr(t);if(Ai(e))return e}return zr(e,Ai)}function Ir(e){for(let t of e){let e=Lr(t);if(ji(e))return e}return zr(e,ji)}function Lr(e){if(!Rr(e))return null;try{return document.querySelector(e)}catch{return null}}function Rr(e){let t=e.trim();return/^[.#[]/.test(t)||/^(input|select|textarea|button|label|form|fieldset|section|div)([#.[\s:]|$)/i.test(t)}function zr(e,t){let n=e.filter(e=>!e.includes(`[`)&&!e.includes(`#`)&&!e.includes(`.`)).map(J).filter(Boolean);return n.length&&Array.from(document.querySelectorAll(`input, textarea, select`)).filter(t).map(e=>({control:e,score:Br(e,n)})).filter(e=>e.score>0&&q(e.control)&&!Oi(e.control)).sort((e,t)=>t.score-e.score)[0]?.control||null}function Br(e,t){if(!q(e)||Oi(e))return 0;let n=J([e.id,e.name,`placeholder`in e?e.placeholder:``,`autocomplete`in e?e.autocomplete:``,e.getAttribute(`aria-label`),Vr(e),Hr(e)].join(` `)),r=J([e.previousElementSibling?.textContent,e.nextElementSibling?.textContent,Ur(e)].join(` `)),i=J(e.parentElement?.textContent||``);return t.some(e=>n.includes(e))?30:t.some(e=>r.includes(e))?20:i.length<=120&&t.some(e=>i.includes(e))?5:0}function Vr(e){let t=[],n=e.getAttribute(`aria-labelledby`);if(n)for(let e of n.split(/\s+/)){let n=document.getElementById(e);n?.textContent&&t.push(n.textContent)}let r=e.id;if(r)for(let e of Array.from(document.querySelectorAll(`label[for="${Zr(r)}"]`)))t.push(e.textContent||``);return t.join(` `)}function Hr(e){return e.closest(`label`)?.textContent||``}function Ur(e){let t=e.closest(`div, label, section`)?.textContent||``;return t.length<=160?t:``}function Wr(){for(let e of Array.from(document.querySelectorAll(`[${cr}]`)))e.removeAttribute(cr)}function Gr(e,t,n){let r=Jr(e);gr!==r&&(gr=r,_r=0),_r+=1,n&&!t&&_r<ur&&di(1200)}function Kr(){return!!(gr&&_r>=ur)}function qr(){gr=``,_r=0,vr=``}function Jr(e){return[location.origin,location.pathname,new URLSearchParams(location.search).get(`token`)||``,e.id].join(`|`)}function Yr(e,t){return!e||!t?!1:e===t?!0:Xr(e)===Xr(t)}function Xr(e){return e.toLowerCase().replace(/[^a-z0-9]/g,``)}function Zr(e){return typeof CSS<`u`&&typeof CSS.escape==`function`?CSS.escape(e):e.replace(/"/g,`\\"`)}function Qr(e,t,n){let r=J(t),i=n.map(J).filter(Boolean),a=Array.from(e.options).filter(e=>!e.disabled&&e.value),o=a.find(e=>J(e.value)===r)||a.find(e=>i.some(t=>J(`${e.text} ${e.value}`).includes(t)));return!o||e.value===o.value?!1:(e.value=o.value,ei(e),!0)}function $r(e,t){e.focus();let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`);r?.set?r.set.call(e,t):e.value=t,ei(e)}function ei(e){e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function ti(){hr?.disconnect(),hr=new MutationObserver(()=>{ni(),!(vr&&gr===vr)&&(Kr()||di(350))}),hr.observe(document.documentElement,{childList:!0,subtree:!0})}function ni(){if(!Ei()||document.getElementById(lr))return;let e=oi(),t=ai(),n=ri();if(e?.parentElement){n.style.marginTop=`8px`,n.style.marginBottom=`12px`,e.parentElement.insertBefore(n,e.nextSibling);return}t?.parentElement&&t.parentElement.insertBefore(n,t)}function ri(){let e=document.createElement(`div`);e.id=lr,e.setAttribute(`data-opx-paypal-random-fill`,`1`),Object.assign(e.style,{display:`flex`,alignItems:`center`,justifyContent:`flex-end`,gap:`8px`,margin:`10px 0 14px`,minHeight:`32px`});let t=document.createElement(`button`);t.type=`button`,t.textContent=`随机输入`,Object.assign(t.style,{appearance:`none`,border:`0`,borderRadius:`6px`,background:`#10b981`,color:`#ffffff`,cursor:`pointer`,fontSize:`13px`,fontWeight:`700`,lineHeight:`1`,minHeight:`32px`,padding:`0 14px`,whiteSpace:`nowrap`});let n=document.createElement(`span`);return Object.assign(n.style,{color:`#64748b`,fontSize:`12px`,lineHeight:`16px`,minWidth:`0`}),t.addEventListener(`click`,()=>{ii(t,n)}),e.append(t,n),e}async function ii(e,n){e.disabled=!0,e.textContent=`获取中...`,Object.assign(e.style,{cursor:`wait`,opacity:`0.72`}),n.textContent=`正在获取新资料`;try{let e=await ut(),r=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});if(!Pi(r)||!r.ok||!r.address){n.textContent=r?.message||`获取失败`;return}G=r.address,vi(r.address),await lt({lastAddress:r.address});let i=await br(r.address,!0,!1);n.textContent=i.countryChanged?`已切换国家，刷新后继续填写`:i.ok?`已随机输入 ${i.filled} 项`:i.message}catch(e){n.textContent=`失败：${Ni(e)}`}finally{e.disabled=!1,e.textContent=`随机输入`,Object.assign(e.style,{cursor:`pointer`,opacity:`1`})}}function ai(){let e=Fr(Y.cardNumber);return e?.closest(`div, label, section`)||e}function oi(){let e=document.querySelector(`div.css-ltr-cssveg > form > section.css-ltr-4jicje:nth-of-type(1) > p.css-ltr-6pd54h.css-ltr-16jt5za-text_body`);return e&&q(e)?e:Array.from(document.querySelectorAll(`form section p, form p`)).filter(e=>q(e)).map(e=>({element:e,score:li(e)})).filter(e=>e.score>0).sort((e,t)=>t.score-e.score)[0]?.element||null}function si(){let e=document.querySelector(`section.css-ltr-h5yxuz:nth-of-type(3) > div.css-ltr-h5yxuz:nth-of-type(2) > div.css-ltr-1lvkl1r:nth-of-type(2) > p.css-ltr-abbmt5:nth-of-type(1)`);if(e&&q(e))return e;let t=document.querySelector(`input#password`)||Fr(Y.password),n=t?.closest(`section`)||document;return Array.from(n.querySelectorAll(`p`)).filter(e=>q(e)).map(e=>({element:e,score:ci(e,t)})).filter(e=>e.score>0).sort((e,t)=>t.score-e.score)[0]?.element||null}function ci(e,t){let n=J(e.textContent||``);return!n||![`by creating an account`,`confirm you’re at least 18 years old`,`confirm you're at least 18 years old`,`agree to the`,`privacy statement`].some(e=>n.includes(J(e)))?0:t&&t.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING?20:10}function li(e){let t=J(e.textContent||``);return t&&[`we don’t share your financial details with the merchant`,`we don't share your financial details with the merchant`,`financial details`,`merchant`].some(e=>t.includes(J(e)))?10:0}function ui(){t.storage.onChanged.addListener((e,t)=>{t===`local`&&Object.keys(e).some(e=>e.includes(`settings`))&&(G=null,qr(),di(100))})}function di(e){fi(),mr=window.setTimeout(()=>{mr=null,xr()},e)}function fi(){mr&&=(window.clearTimeout(mr),null)}function pi(e){window.setTimeout(()=>{let e=mi();if(!e){_i();return}br(e,!0,!1)},e)}function mi(){try{let e=sessionStorage.getItem(or);return e?JSON.parse(e):null}catch{return null}}function hi(){try{sessionStorage.setItem(sr,`1`)}catch{}}function gi(){try{let e=sessionStorage.getItem(sr)===`1`;return e&&sessionStorage.removeItem(sr),e}catch{return!1}}function _i(){try{sessionStorage.removeItem(sr)}catch{}}function vi(e){try{sessionStorage.setItem(or,JSON.stringify(e))}catch{}}function yi(e,t){let n=t.countryCode===`RANDOM`||e.countryCode===t.countryCode,r=!t.city.trim()||J(e.city)===J(t.city);return n&&r}function bi(e){let t=e.match(/\d+/g)||[],n=(t[0]||``).padStart(2,`0`).slice(0,2),r=t[1]||``,i=r.length===2?`20${r}`:r.slice(0,4),a=i.slice(-2);return{month:n,year2:a,year4:i,short:n&&a?`${n}/${a}`:e}}function xi(e){let t=e.replace(/[^a-zA-Z]/g,``);if(t&&!e.includes(` `))return{first:t.slice(0,Math.max(1,Math.floor(t.length/2))),last:t.slice(Math.max(1,Math.floor(t.length/2)))||t};let n=e.split(/\s+/).map(e=>e.trim()).filter(Boolean);return{first:n[0]||t||`Alex`,last:n.slice(1).join(` `)||`Walker`}}function Si(e){return`${(e.identity.username||e.fullName||`outlookuser`).toLowerCase().replace(/[^a-z0-9]/g,``).slice(0,18)||`outlookuser`}${(e.id+e.fetchedAt).replace(/\D/g,``).slice(-6)||String(Date.now()).slice(-6)}@outlook.com`}var Ci={US:[`1`],CA:[`1`],AU:[`61`],CN:[`86`],JP:[`81`],KR:[`82`],TW:[`886`],HK:[`852`],SG:[`65`],GB:[`44`],DE:[`49`],FR:[`33`],IT:[`39`],ES:[`34`],NL:[`31`],MY:[`60`],RU:[`7`],TH:[`66`],PH:[`63`],AR:[`54`],TR:[`90`],VN:[`84`]};function wi(e,t){let n=String(e||``).trim();if(!n)return``;let r=n.replace(/[^\d+]/g,``);if(!r)return``;if(r.startsWith(`+`)){let e=r.slice(1),n=Ci[String(t||``).trim().toUpperCase()]||[];for(let t of n)if(e.startsWith(t))return e.slice(t.length);return e}return r}function Ti(e){let t=/[a-zA-Z]/.test(e),n=/\d/.test(e);if(t&&n&&e.length>=8)return e;let r=e.replace(/@.*$/,``).replace(/[^a-zA-Z0-9]/g,``)||`Paypal`;for(/[a-zA-Z]/.test(r)||(r=`Pp`+r),/\d/.test(r)||(r+=`2024`);r.length<8;)r+=`x1`;return r.charAt(0).toUpperCase()+r.slice(1)}function Ei(){return location.hostname.endsWith(`paypal.com`)&&location.pathname.startsWith(`/checkoutweb/signup`)}function Di(){let e=Array.from(document.querySelectorAll(`button[type="submit"], button`));for(let t of e){if(!q(t)||t.disabled)continue;let e=J(t.textContent||``);if(e.includes(`agree and create account`)||e.includes(`同意并创建账户`)||e.includes(`同意并创建帐户`)||e.includes(`create account`)||e.includes(`创建账户`)||e.includes(`创建帐户`)){t.click(),console.info(`${ar} 已点击创建帐户按钮`);return}}}function Oi(e){return e instanceof HTMLSelectElement||e instanceof HTMLTextAreaElement?!1:[`hidden`,`radio`,`checkbox`,`submit`,`button`].includes((e.type||``).toLowerCase())}function ki(e){let t=J([e.id,e.name,`placeholder`in e?e.placeholder:``,`autocomplete`in e?e.autocomplete:``,e.getAttribute(`aria-label`),Vr(e)].join(` `));return[`email`,`phone`,`mobile`,`card`,`credit`,`expiry`,`expiration`,`cvv`,`csc`,`security code`].some(e=>t.includes(e))}function q(e){let t=e;if(`disabled`in t&&t.disabled)return!1;let n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.visibility!==`hidden`&&n.display!==`none`&&r.width>0&&r.height>0}function Ai(e){return!!(e&&(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))}function ji(e){return!!(e&&e instanceof HTMLSelectElement)}function Mi(e){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)}function J(e){return String(e||``).replace(/\s+/g,` `).trim().toLowerCase()}function Ni(e){return e instanceof Error?e.message:String(e)}function Pi(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var Y={country:[`select#country`,`select[name="country"]`,`select[name="country.x"]`,`country`,`country or region`],email:[`input#email`,`input[name="email"]`,`input[type="email"]`,`input[autocomplete="email"]`,`email`],password:[`input#password`,`input[name="password"]`,`input[type="password"]`,`input[autocomplete="new-password"]`,`create password`,`password`],phone:[`input#phone`,`input#phoneNumber`,`input[name="phone"]`,`input[name="phoneNumber"]`,`input[type="tel"]`,`phone number`,`mobile`],cardNumber:[`input#cardNumber`,`input#card_number`,`input[name="cardNumber"]`,`input[name="card_number"]`,`input[autocomplete="cc-number"]`,`card number`,`credit card number`],expiry:[`input#expiryDate`,`input#expirationDate`,`input#cardExpiry`,`input[name="expiryDate"]`,`input[name="expirationDate"]`,`input[name="cardExpiry"]`,`input[autocomplete="cc-exp"]`,`expiration`,`expiry`,`有效期限`],expiryMonth:[`select#expMonth`,`select#expiryMonth`,`select[name="expMonth"]`,`select[name="expiryMonth"]`,`expiration month`,`expiry month`],expiryYear:[`select#expYear`,`select#expiryYear`,`select[name="expYear"]`,`select[name="expiryYear"]`,`expiration year`,`expiry year`],csc:[`input#cvv`,`input#csc`,`input#securityCode`,`input[name="cvv"]`,`input[name="csc"]`,`input[name="securityCode"]`,`input[autocomplete="cc-csc"]`,`csc`,`cvv`,`security code`],fullName:[`input#cardholderName`,`input#nameOnCard`,`input#fullName`,`input[name="cardholderName"]`,`input[name="nameOnCard"]`,`input[name="fullName"]`,`input[autocomplete="cc-name"]`,`name on card`,`full name`],firstName:[`input#firstName`,`input#billingFirstName`,`input[name="firstName"]`,`input[name="billingFirstName"]`,`input[autocomplete="given-name"]`,`first name`],lastName:[`input#lastName`,`input#billingLastName`,`input[name="lastName"]`,`input[name="billingLastName"]`,`input[autocomplete="family-name"]`,`last name`],address1:[`input#address1`,`input#addressLine1`,`input#billingAddressLine1`,`input#billingLine1`,`input[name="address1"]`,`input[name="addressLine1"]`,`input[name="billingLine1"]`,`input[autocomplete="address-line1"]`,`address line 1`,`street address`],address2:[`input#address2`,`input#addressLine2`,`input#billingAddressLine2`,`input#billingLine2`,`input[name="address2"]`,`input[name="addressLine2"]`,`input[name="billingLine2"]`,`input[autocomplete="address-line2"]`,`address line 2`],city:[`input#city`,`input#billingLocality`,`input#billingCity`,`input[name="city"]`,`input[name="billingCity"]`,`input[autocomplete="address-level2"]`,`city`],state:[`select#state`,`input#state`,`select#billingAdministrativeArea`,`input#billingAdministrativeArea`,`select#billingState`,`input#billingState`,`select[name="state"]`,`input[name="state"]`,`select[name="billingState"]`,`input[name="billingState"]`,`select[autocomplete="address-level1"]`,`input[autocomplete="address-level1"]`,`state`,`province`],postalCode:[`input#zip`,`input#postalCode`,`input#billingPostalCode`,`input#billingZip`,`input[name="zip"]`,`input[name="postalCode"]`,`input[name="billingPostalCode"]`,`input[name="billingZip"]`,`input[autocomplete="postal-code"]`,`zip code`,`postal code`]};function Fi(e){let n=document.createElement(`div`);n.className=`opx-summary`;let r=Li(),i=document.createElement(`input`);i.className=`opx-input`,i.type=`text`,i.placeholder=`城市留空即随机，例如 Tokyo / Berlin / New York`,i.autocomplete=`off`;let a=document.createElement(`div`);a.className=`opx-grid`,a.append(Ri(`地址国家`,r),Ri(`指定城市`,i));let o=document.createElement(`div`);o.className=`opx-button-row opx-address-actions`;let s=zi(`获取地址`);o.append(s);let c=document.createElement(`div`);c.className=`opx-copy-list`;let l=document.createElement(`div`);l.className=`opx-status`,e.append(n,a,o,c,l),r.addEventListener(`change`,()=>void d(`国家已保存`)),i.addEventListener(`change`,()=>void d(`城市已保存`)),s.addEventListener(`click`,()=>void f());let u=async()=>{m(await ut())};return u(),{update:u};async function d(e){let t=await ut(),n=r.value,a=i.value.trim();m(await lt({countryCode:n,city:a,lastAddress:t.countryCode!==n||t.city.trim()!==a?null:t.lastAddress})),Vi(l,e,`ok`)}async function f(){s.disabled=!0,Vi(l,`正在获取随机地址...`,`pending`);try{let e=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:r.value,city:i.value.trim()});if(!Ui(e)||!e.ok||!e.address){Vi(l,e?.message||`获取地址失败`,`error`);return}m(await lt({countryCode:r.value,city:i.value.trim(),lastAddress:e.address}));let n=await p(e.address);Vi(l,n?`${e.message}；${n}`:e.message,`ok`)}catch(e){Vi(l,`获取地址失败：${Hi(e)}`,`error`)}finally{s.disabled=!1}}async function p(e){return location.hostname===`pay.openai.com`?(await Mn(e)).message:location.hostname.endsWith(`paypal.com`)?(await br(e,!0,!1)).message:``}function m(e){r.value=e.countryCode,i.value=e.city,h(e),g(e.lastAddress)}function h(e){n.textContent=`${r.selectedOptions[0]?.textContent||e.countryCode} · ${e.city||`随机城市`}`}function g(e){if(c.textContent=``,!e){c.append(Bi(`暂无地址，点击“获取地址”。`));return}for(let t of Ii(e))c.append(v(t))}function _(e,t){let n=document.createElement(`button`);n.className=`opx-copy-row`,n.type=`button`,n.title=`点击复制`;let r=document.createElement(`span`);r.className=`opx-copy-label`,r.textContent=`${e}：`;let i=document.createElement(`strong`);i.textContent=t;let a=document.createElement(`span`);a.className=`opx-copy-feedback`,a.textContent=`已复制`,a.hidden=!0;let o=null;return n.append(r,i,a),n.addEventListener(`click`,async()=>{await navigator.clipboard.writeText(t),o&&window.clearTimeout(o),n.classList.add(`is-copied`),a.hidden=!1,o=window.setTimeout(()=>{n.classList.remove(`is-copied`),a.hidden=!0,o=null},1400)}),n}function v(e){let t=document.createElement(`div`);t.className=`opx-copy-section-body`;for(let n of e.items)n.value&&t.append(_(n.label,n.value));if(e.collapsed){let n=document.createElement(`details`);n.className=`opx-accordion-section`;let r=document.createElement(`summary`);return r.textContent=e.title,n.append(r,t),n}let n=document.createElement(`section`);n.className=`opx-copy-section`;let r=document.createElement(`div`);return r.className=`opx-copy-section-title`,r.textContent=e.title,n.append(r,t),n}}function Ii(e){return[{title:`地址资料`,items:[{label:`国家`,value:`${e.countryLabel||e.countryCode} / ${e.countryCode}`},{label:`姓名`,value:e.fullName},{label:`电话`,value:e.phone},{label:`地址1`,value:e.line1},{label:`地址2`,value:e.line2},{label:`城市`,value:e.city},{label:`州/省`,value:e.stateFull?`${e.stateFull} / ${e.state}`:e.state},{label:`邮编`,value:e.postalCode}]},{title:`信用卡资料`,items:[{label:`卡类型`,value:e.creditCard.type},{label:`卡号`,value:e.creditCard.number},{label:`CVV`,value:e.creditCard.cvv},{label:`有效期`,value:e.creditCard.expires},{label:`后四位`,value:e.creditCard.last4}]},{title:`身份资料`,collapsed:!0,items:[{label:`性别`,value:e.identity.gender},{label:`称谓`,value:e.identity.title},{label:`生日`,value:e.identity.birthday},{label:`用户名`,value:e.identity.username},{label:`密码`,value:e.identity.password},{label:`临时邮箱`,value:e.identity.temporaryMail},{label:`系统`,value:e.identity.system},{label:`网站`,value:e.identity.website},{label:`安全问题`,value:e.identity.securityQuestion},{label:`安全答案`,value:e.identity.securityAnswer}]},{title:`就业资料`,collapsed:!0,items:[{label:`公司`,value:e.employment.companyName},{label:`职业`,value:e.employment.occupation},{label:`就业状态`,value:e.employment.employmentStatus},{label:`月薪`,value:e.employment.monthlySalary},{label:`公司规模`,value:e.employment.companySize},{label:`教育背景`,value:e.employment.educationalBackground}]}]}function Li(){let e=document.createElement(`select`);e.className=`opx-select`;let t=document.createElement(`option`);t.value=`RANDOM`,t.textContent=`随机国家`,e.append(t);for(let t of yt){let n=document.createElement(`option`);n.value=t.code,n.textContent=`${t.label} / ${t.code}`,e.append(n)}return e}function Ri(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function zi(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Bi(e){let t=document.createElement(`div`);return t.className=`opx-empty-inline`,t.textContent=e,t}function Vi(e,t,n){e.textContent=t,e.dataset.type=n}function Hi(e){return e instanceof Error?e.message:String(e)}function Ui(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var Wi={idle:`等待开始`,"fill-email":`填入邮箱`,"wait-otp":`等待验证码`,"fill-profile":`填写资料`,"fetch-session":`读取 Session`,"generate-link":`生成订阅链接`,"open-checkout":`打开支付页`,"wait-payment-page":`等待支付页填写`,"wait-paypal-sms":`等待 PayPal 短信验证`,done:`全流程完成`,error:`出错`};function Gi(e){let t=document.createElement(`div`);t.className=`opx-auto-panel`;let n=document.createElement(`div`);n.className=`opx-hint`,n.textContent=`一键自动化：输入 Outlook 账号后点击开始，全流程自动执行。`;let r=document.createElement(`div`);r.className=`opx-button-row`,r.style.marginTop=`12px`;let i=document.createElement(`button`);i.className=`opx-button`,i.type=`button`,i.textContent=`一键开始`;let a=document.createElement(`button`);a.className=`opx-button opx-button-secondary`,a.type=`button`,a.textContent=`停止`,a.disabled=!0;let o=document.createElement(`button`);o.className=`opx-button opx-button-secondary`,o.type=`button`,o.textContent=`重置`,r.append(i,a,o);let s=document.createElement(`div`);s.className=`opx-status`,s.style.marginTop=`12px`,s.textContent=`等待开始`;let c=document.createElement(`div`);c.className=`opx-steps-list`,c.style.marginTop=`12px`;let l=[`fill-email`,`wait-otp`,`fill-profile`,`fetch-session`,`generate-link`,`open-checkout`,`wait-payment-page`,`wait-paypal-sms`],u={};for(let e of l){let t=document.createElement(`div`);t.style.cssText=`display:flex;align-items:center;gap:6px;padding:3px 0;font-size:12px;color:#94a3b8;`;let n=document.createElement(`span`);n.style.cssText=`width:16px;text-align:center;`,n.textContent=`○`;let r=document.createElement(`span`);r.textContent=Wi[e],t.append(n,r),c.append(t),u[e]=t}let d=document.createElement(`div`);d.className=`opx-hint`,d.style.marginTop=`8px`,d.style.wordBreak=`break-all`,t.append(n,r,s,c,d),e.append(t),i.addEventListener(`click`,async()=>{i.disabled=!0,a.disabled=!1,await tn()}),a.addEventListener(`click`,async()=>{a.disabled=!0,i.disabled=!1,await nn()}),o.addEventListener(`click`,async()=>{await rn(),i.disabled=!1,a.disabled=!0}),$t(e=>{f(e)});function f(e){i.disabled=e.enabled,a.disabled=!e.enabled,s.textContent=e.statusMessage,s.dataset.type=e.currentStep===`error`?`error`:e.currentStep===`done`?`ok`:`pending`;for(let t of l){let n=u[t],r=n?.firstElementChild;!n||!r||(e.completedSteps.includes(t)?(r.textContent=`✔`,n.style.color=`#10b981`):e.currentStep===t?(r.textContent=`●`,n.style.color=`#f59e0b`):(r.textContent=`○`,n.style.color=`#94a3b8`))}e.generatedLink?d.textContent=`订阅链接：${e.generatedLink}`:d.textContent=``}let p=async()=>{f(await en())};return p(),{update:p}}var Ki=[[`ID`,`印尼 / IDR`],[`DE`,`德国 / EUR`],[`JP`,`日本 / JPY`],[`US`,`美国 / USD`]];function qi(e){let n=document.createElement(`div`);n.className=`opx-summary`;let r=document.createElement(`div`);r.className=`opx-session-card`;let i=Ji(`邮箱`,`未读取`),a=Ji(`套餐`,`未读取`),o=Ji(`Token`,`未读取`);r.append(i.row,a.row,o.row);let s=Yi(`读取 ChatGPT session`,`opx-button opx-button-secondary`),c=Zi([[`chatgptplusplan`,`ChatGPT Plus`],[`chatgptteamplan`,`ChatGPT Team`]]),l=Zi([[`custom`,`短链接 / custom`],[`hosted`,`长链接 / hosted`]]),u=Zi(Ki),d=Xi(`Workspace 名称`,`text`),f=Xi(`席位数量`,`number`);f.min=`2`,f.step=`1`;let p=document.createElement(`div`);p.className=`opx-grid`;let m=Qi(`套餐类型`,c),h=Qi(`链接形式`,l),g=Qi(`计费区域`,u);p.append(m,h,g);let _=document.createElement(`div`);_.className=`opx-team-options`;let v=document.createElement(`div`);v.className=`opx-grid`,v.append(Qi(`Workspace`,d),Qi(`席位`,f)),_.append(v);let y=document.createElement(`textarea`);y.className=`opx-textarea opx-token-textarea`,y.placeholder=`自动读取或手动粘贴 ChatGPT session JSON / Access Token`,y.autocomplete=`off`,y.spellcheck=!1;let b=document.createElement(`div`);b.className=`opx-hint`,b.textContent=`切到提链接 tab 会读取 /api/auth/session；token 只在当前页面内使用。`;let x=Yi(`生成订阅链接`),S=document.createElement(`textarea`);S.className=`opx-textarea opx-output`,S.placeholder=`生成后的订阅链接`,S.readOnly=!0,S.spellcheck=!1;let C=document.createElement(`div`);C.className=`opx-button-row`;let w=Yi(`复制链接`,`opx-button opx-button-secondary`),T=Yi(`打开链接`,`opx-button opx-button-secondary`),E=Yi(`清空`,`opx-button opx-button-secondary`);C.append(w,T,E);let D=document.createElement(`div`);D.className=`opx-status`,D.textContent=`等待读取 ChatGPT session。`;let O=``,k=``,A=!1,ee=!1,te=async()=>{ae((await Re()).checkoutOptions)},ne=async()=>{await ie()},re=async()=>{try{let e=oe();await ze({checkoutOptions:e}),se(e),X(D,`本地参数已更新`,`ok`)}catch(e){X(D,$i(e),`error`)}};for(let e of[c,l,u,d,f])e.addEventListener(`change`,()=>void re()),e.addEventListener(`input`,()=>void re());return s.addEventListener(`click`,()=>void ie()),y.addEventListener(`paste`,()=>window.setTimeout(()=>ce(!1),0)),y.addEventListener(`input`,()=>{k=``,(y.value.includes(`accessToken`)||y.value.length>900)&&ce(!1)}),x.addEventListener(`click`,async()=>{if(x.disabled)return;x.disabled=!0;let e=x.textContent||`生成订阅链接`;x.textContent=`生成中...`,X(D,`正在生成订阅链接...`,`pending`);try{let e=y.value.trim()?ce(!0):k;if(!e){X(D,`没有 accessToken，请先读取 session 或手动粘贴。`,`error`);return}let n;try{n=oe(),await ze({checkoutOptions:n})}catch(e){X(D,$i(e),`error`);return}let r;try{r=await t.runtime.sendMessage({type:`opx:create-checkout-link`,raw:e,options:n})}catch(e){X(D,`生成失败：${String(e)}`,`error`);return}let i=r?.link||r?.url||``;if(!ea(r)||!r.ok||!i){X(D,r?.message||`生成失败：返回结果无效`,`error`),le(``);return}le(i),X(D,r.message,`ok`)}finally{x.disabled=!1,x.textContent=e}}),w.addEventListener(`click`,async()=>{O&&(await navigator.clipboard.writeText(O),X(D,`已复制链接`,`ok`))}),T.addEventListener(`click`,()=>{O&&window.open(O,`_blank`,`noopener,noreferrer`)}),E.addEventListener(`click`,()=>{y.value=``,k=``,b.textContent=`切到提链接 tab 会读取 /api/auth/session；token 只在当前页面内使用。`,b.classList.remove(`is-ok`),le(``),ue(``,``,``),X(D,`已清空`,`ok`),y.focus()}),e.append(n,r,s,p,_,y,b,x,Qi(`订阅链接`,S),C,D),te(),le(``),{update:te,onShow:ne};async function ie(){if(!A){A=!0,s.disabled=!0,X(D,`正在读取 https://chatgpt.com/api/auth/session ...`,`pending`);try{let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(ee=!0,!ta(e)){X(D,`session 返回结果无效`,`error`);return}let n=e.session;ue(n?.email||``,n?.planType||``,n?.accessToken||``),n?.accessToken&&(k=n.accessToken,y.value=n.accessToken,b.textContent=`已从 ChatGPT session 读取 accessToken。`,b.classList.add(`is-ok`)),X(D,e.message,e.ok?`ok`:`error`)}catch(e){X(D,`读取 session 失败：${String(e)}`,`error`)}finally{s.disabled=!1,A=!1}}}function ae(e){let t=ye(e);c.value=t.planName,l.value=t.uiMode,u.value=t.region,d.value=t.workspaceName,f.value=String(t.seatQuantity),se(t)}function oe(){return ye({planName:c.value,uiMode:l.value,region:u.value,workspaceName:d.value,seatQuantity:Number(f.value||5)})}function se(e){let t=e.planName===`chatgptteamplan`?`Team · ${e.seatQuantity} seats`:`Plus`,r=e.uiMode===`hosted`?`长链接 hosted`:`短链接 custom`,i=ee?`session 已请求`:`session 待读取`;n.textContent=`${t} · ${r} · ${e.region} · ${i}`,_.hidden=e.planName!==`chatgptteamplan`,g.hidden=e.planName===`chatgptteamplan`}function ce(e){try{let e=ve(y.value);return y.value.trim()!==e&&(y.value=e),b.textContent=`已本地提取 accessToken。`,b.classList.add(`is-ok`),e}catch(t){return b.classList.remove(`is-ok`),e&&X(D,$i(t),`error`),``}}function le(e){O=e,S.value=e,w.disabled=!e,T.disabled=!e}function ue(e,t,n){i.value.textContent=e||`未读取`,a.value.textContent=t||`未读取`,o.value.textContent=n?`已获取`:`未获取`}}function Ji(e,t){let n=document.createElement(`div`);n.className=`opx-session-row`;let r=document.createElement(`span`);r.textContent=e;let i=document.createElement(`strong`);return i.textContent=t,n.append(r,i),{row:n,value:i}}function Yi(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Xi(e,t){let n=document.createElement(`input`);return n.className=`opx-input`,n.type=t,n.placeholder=e,n}function Zi(e){let t=document.createElement(`select`);t.className=`opx-select`;for(let[n,r]of e){let e=document.createElement(`option`);e.value=n,e.textContent=r,t.append(e)}return t}function Qi(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function X(e,t,n){e.textContent=t,e.dataset.type=n}function $i(e){return e instanceof Error?e.message:String(e)}function ea(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function ta(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var na=`app_EMoamEEZ73f0CkXaXp7hrann`,ra=`https://auth.openai.com/oauth/authorize`,ia=`https://auth.openai.com/oauth/token`,aa=`openid profile email offline_access`;function oa(){return`http://localhost:1455/auth/callback`}async function sa(e){try{let t=ha(64),n=ha(32),r=await ga(t);return{ok:!0,message:`已生成 OAuth 授权链接`,authUrl:`${ra}?${new URLSearchParams({response_type:`code`,client_id:na,redirect_uri:e,scope:aa,state:n,code_challenge:r,code_challenge_method:`S256`}).toString()}`,state:n,codeVerifier:t,codeChallenge:r}}catch(e){return{ok:!1,message:`生成授权链接失败：${ya(e)}`}}}async function ca(e){if(!e.code)return{ok:!1,message:`缺少 code 参数`};if(!e.codeVerifier)return{ok:!1,message:`缺少 code_verifier，请重新生成授权链接`};let t;try{let n=new URLSearchParams({grant_type:`authorization_code`,client_id:na,code:e.code,redirect_uri:e.redirectUri,code_verifier:e.codeVerifier});t=await fetch(ia,{method:`POST`,headers:{Accept:`application/json`,"Content-Type":`application/x-www-form-urlencoded`},body:n.toString(),credentials:`omit`})}catch(e){return{ok:!1,message:`调用 token 接口失败：${ya(e)}`}}let n=await t.text(),r={};try{r=n?JSON.parse(n):{}}catch{r={}}if(!t.ok){let e=va(r,`error_description`)||va(r,`error`)||n||t.statusText;return{ok:!1,message:`换 token 失败：HTTP ${t.status} ${e}`,raw:r}}let i=va(r,`access_token`),a=va(r,`refresh_token`),o=va(r,`id_token`);if(!i)return{ok:!1,message:`响应里没有 access_token`,raw:r};let s=Number(r.expires_in||0),c=Date.now(),l=s>0?new Date(c+s*1e3).toISOString():``,u=new Date(c).toISOString();return{ok:!0,message:`已换取 token`,credentials:{access_token:i,account_id:fa(o,i),disabled:!1,email:e.email,expired:l,id_token:o,last_refresh:u,refresh_token:a,type:`codex`},raw:r}}function la(e){return JSON.stringify({access_token:e.access_token,refresh_token:e.refresh_token,id_token:e.id_token,account_id:e.account_id,email:e.email,expired:e.expired,last_refresh:e.last_refresh,type:e.type},null,2)}function ua(e){return JSON.stringify({OPENAI_API_KEY:``,tokens:{access_token:e.access_token,refresh_token:e.refresh_token,id_token:e.id_token,account_id:e.account_id},last_refresh:e.last_refresh},null,2)}function da(e){try{let t=new URL(e.trim());return{code:t.searchParams.get(`code`)||``,state:t.searchParams.get(`state`)||``}}catch{let t=new URLSearchParams(e.replace(/^\?/,``));return{code:t.get(`code`)||``,state:t.get(`state`)||``}}}function fa(e,t){return pa(e,`chatgpt_account_id`)||pa(e,`sub`)||pa(t,`chatgpt_account_id`)||pa(t,`sub`)||``}function pa(e,t){if(!e)return``;let n=e.split(`.`);if(n.length<2)return``;try{let e=JSON.parse(ma(n[1]))[t];return typeof e==`string`?e:e==null?``:String(e)}catch{return``}}function ma(e){let t=e.replace(/-/g,`+`).replace(/_/g,`/`).padEnd(e.length+(4-(e.length%4||4))%4,`=`);if(typeof atob==`function`)try{return decodeURIComponent(atob(t).split(``).map(e=>`%${e.charCodeAt(0).toString(16).padStart(2,`0`)}`).join(``))}catch{return atob(t)}return Buffer.from(t,`base64`).toString(`utf-8`)}function ha(e){let t=new Uint8Array(e);return crypto.getRandomValues(t),_a(t).slice(0,e)}async function ga(e){let t=new TextEncoder().encode(e),n=await crypto.subtle.digest(`SHA-256`,t);return _a(new Uint8Array(n))}function _a(e){let t=``;for(let n of e)t+=String.fromCharCode(n);return(typeof btoa==`function`?btoa(t):Buffer.from(t,`binary`).toString(`base64`)).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}function va(e,t){let n=e[t];return typeof n==`string`?n:``}function ya(e){return e instanceof Error?e.message:String(e)}function ba(e){let t=document.createElement(`div`);t.className=`opx-summary`,t.textContent=`OAuth 状态：未启动`;let n=wa(`OAuth 登录邮箱（自动同步注册 tab）`,`email`),r=wa(`Redirect URI`,`text`);r.placeholder=oa();let i=Z(`生成授权链接并打开`),a=document.createElement(`textarea`);a.className=`opx-textarea opx-output`,a.placeholder=`生成后的 OAuth 授权链接`,a.readOnly=!0,a.spellcheck=!1;let o=document.createElement(`div`);o.className=`opx-button-row`;let s=Z(`复制链接`,`opx-button opx-button-secondary`),c=Z(`打开链接`,`opx-button opx-button-secondary`),l=Z(`重置`,`opx-button opx-button-secondary`);o.append(s,c,l);let u=document.createElement(`textarea`);u.className=`opx-textarea`,u.placeholder=`把回调 URL 或 code=xxx&state=xxx 粘贴到这里`,u.spellcheck=!1,u.autocomplete=`off`;let d=Z(`换取 token`),f=document.createElement(`div`);f.className=`opx-session-card`;let p=Ea(`access_token`,`未获取`),m=Ea(`account_id`,`未获取`),h=Ea(`refresh_token`,`未获取`),g=Ea(`expired`,`未获取`);f.append(p.row,m.row,h.row,g.row);let _=document.createElement(`div`);_.className=`opx-button-row`;let v=Z(`复制 code/state`,`opx-button opx-button-secondary`),y=Z(`下载 sub2api JSON`,`opx-button opx-button-secondary`),b=Z(`下载 CPA JSON`,`opx-button opx-button-secondary`);_.append(v,y,b);let x=document.createElement(`div`);x.className=`opx-status`,x.textContent=`尚未生成授权链接`;let S=null,C=async()=>{let e=await Be();S=e,n.value||=e.email||await D(),r.value=e.redirectUri||oa(),a.value=e.authUrl,e.callbackUrl&&!u.value&&(u.value=e.callbackUrl),w(e),T(e.credentials),E(e),e.exchangeStatus===`error`&&e.exchangeMessage?Q(x,e.exchangeMessage,`error`):e.exchangeStatus===`success`&&e.credentials&&Q(x,e.exchangeMessage||`已获取 token`,`ok`)};return n.addEventListener(`input`,()=>{F({email:n.value.trim()})}),r.addEventListener(`input`,()=>{F({redirectUri:r.value.trim()||oa()})}),i.addEventListener(`click`,async()=>{if(!i.disabled){i.disabled=!0,Q(x,`正在生成授权链接...`,`pending`);try{let e=r.value.trim()||oa(),t=await sa(e);if(!t.ok||!t.authUrl){Q(x,t.message,`error`);return}let i=await F({codeVerifier:t.codeVerifier||``,codeChallenge:t.codeChallenge||``,state:t.state||``,redirectUri:e,authUrl:t.authUrl,email:n.value.trim(),startedAt:Date.now(),callbackUrl:``,codeParam:``,exchangeStatus:`idle`,exchangeMessage:``,credentials:null,cpaJson:``,sub2apiJson:``});S=i,a.value=i.authUrl,u.value=``,window.open(i.authUrl,`_blank`,`noopener,noreferrer`),w(i),T(i.credentials),E(i),Q(x,`已打开授权页，登录后把回调链接粘贴到下面。`,`ok`)}catch(e){Q(x,`生成失败：${Oa(e)}`,`error`)}finally{i.disabled=!1}}}),s.addEventListener(`click`,async()=>{a.value&&(await navigator.clipboard.writeText(a.value),Q(x,`已复制授权链接`,`ok`))}),c.addEventListener(`click`,()=>{a.value&&window.open(a.value,`_blank`,`noopener,noreferrer`)}),l.addEventListener(`click`,async()=>{let e=await Ve();S=e,a.value=``,u.value=``,T(null),E(e),w(e),Q(x,`已重置 OAuth 状态`,`ok`)}),d.addEventListener(`click`,async()=>{if(!d.disabled){d.disabled=!0,Q(x,`正在换取 token...`,`pending`);try{let e=S||await Be();if(!e.codeVerifier){Q(x,`请先生成授权链接`,`error`);return}let t=u.value.trim();if(!t){Q(x,`请粘贴回调 URL 或 code=xxx&state=xxx`,`error`);return}let r=da(t);if(!r.code){Q(x,`回调里没有 code 参数`,`error`);return}if(e.state&&r.state&&e.state!==r.state){Q(x,`state 不一致，可能有 CSRF 风险，请重新生成授权链接`,`error`);return}await F({callbackUrl:t,codeParam:r.code,exchangeStatus:`pending`,exchangeMessage:``});let i=await ca({code:r.code,codeVerifier:e.codeVerifier,redirectUri:e.redirectUri||oa(),email:n.value.trim()||e.email});if(!i.ok||!i.credentials){let e=await F({exchangeStatus:`error`,exchangeMessage:i.message});S=e,w(e),Q(x,i.message,`error`);return}let a=la(i.credentials),o=ua(i.credentials),s=await F({credentials:i.credentials,sub2apiJson:a,cpaJson:o,exchangeStatus:`success`,exchangeMessage:`已换取 token`});S=s,T(s.credentials),E(s),w(s),Q(x,`已换取 token`,`ok`)}catch(e){let t=await F({exchangeStatus:`error`,exchangeMessage:`换取失败：${Oa(e)}`});S=t,w(t),Q(x,t.exchangeMessage,`error`)}finally{d.disabled=!1}}}),v.addEventListener(`click`,async()=>{let e=S||await Be();if(!e.codeParam){Q(x,`没有 code，先粘贴回调 URL 并换取 token`,`error`);return}let t=`code=${e.codeParam}&state=${e.state}`;await navigator.clipboard.writeText(t),Q(x,`已复制 code/state`,`ok`)}),y.addEventListener(`click`,async()=>{let e=S||await Be();if(!e.sub2apiJson){Q(x,`还没有 sub2api JSON，请先换取 token`,`error`);return}Ca(e.sub2apiJson,Sa(e,`sub2api`)),Q(x,`已下载 sub2api JSON`,`ok`)}),b.addEventListener(`click`,async()=>{let e=S||await Be();if(!e.cpaJson){Q(x,`还没有 CPA JSON，请先换取 token`,`error`);return}Ca(e.cpaJson,Sa(e,`cpa`)),Q(x,`已下载 CPA JSON`,`ok`)}),e.append(t,Ta(`OAuth 邮箱`,n),Ta(`Redirect URI`,r),i,Ta(`授权链接`,a),o,Ta(`回调 URL / code`,u),d,f,_,x),C(),{update:C,onShow:async()=>{n.value||=await D(),await C()}};function w(e){let n=[];e.email&&n.push(`邮箱：${e.email}`),n.push(`状态：${xa(e)}`),e.exchangeStatus===`success`&&e.credentials?.account_id&&n.push(`account_id：${e.credentials.account_id}`),t.textContent=n.join(` · `)}function T(e){p.value.textContent=e?.access_token?Da(e.access_token,36):`未获取`,m.value.textContent=e?.account_id||`未获取`,h.value.textContent=e?.refresh_token?Da(e.refresh_token,36):`未获取`,g.value.textContent=e?.expired||`未获取`}function E(e){v.disabled=!e.codeParam,y.disabled=!e.sub2apiJson,b.disabled=!e.cpaJson}async function D(){try{let e=await Ie(),t=pe(e.rawInput);return t.ok&&t.email?t.email:e.email||``}catch{return``}}}function xa(e){return e.exchangeStatus===`success`?`已获取 token`:e.exchangeStatus===`pending`?`正在换取 token...`:e.exchangeStatus===`error`?`失败 - ${e.exchangeMessage}`:e.authUrl?`等待回调`:`未启动`}function Sa(e,t){return`${(e.credentials?.email||e.email||`codex`).replace(/[^a-z0-9._-]/gi,`_`)}.${t}.json`}function Ca(e,t){let n=new Blob([e],{type:`application/json`}),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=t,i.style.display=`none`,document.documentElement.append(i),i.click(),i.remove(),setTimeout(()=>URL.revokeObjectURL(r),2e3)}function wa(e,t){let n=document.createElement(`input`);return n.className=`opx-input`,n.type=t,n.placeholder=e,n.autocomplete=`off`,n.spellcheck=!1,n}function Z(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Ta(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function Ea(e,t){let n=document.createElement(`div`);n.className=`opx-session-row`;let r=document.createElement(`span`);r.textContent=e;let i=document.createElement(`strong`);return i.textContent=t,n.append(r,i),{row:n,value:i}}function Q(e,t,n){e.textContent=t,e.dataset.type=n}function Da(e,t){return e?e.length<=t?e:`${e.slice(0,t)}...`:``}function Oa(e){return e instanceof Error?e.message:String(e)}function ka(e,t){let n=document.createElement(`textarea`);n.className=`opx-textarea`,n.placeholder=`邮箱或 Outlook 行`,n.autocomplete=`off`,n.spellcheck=!1;let r=document.createElement(`div`);r.className=`opx-hint`,r.textContent=`支持 user@example.com 或 email----password----client_id----refresh_token`;let i=Aa(`填入邮箱并继续`),a=document.createElement(`input`);a.className=`opx-input`,a.type=`text`,a.inputMode=`numeric`,a.placeholder=`验证码`,a.autocomplete=`one-time-code`;let o=Aa(`填入验证码并继续`),s=Aa(`自动接收并填入验证码`,`opx-button opx-button-secondary`),c=Aa(`填写资料并创建`),l=document.createElement(`div`);l.className=`opx-status`,l.textContent=`等待操作`;let u=async()=>{let e=t.getPageState(),a=await t.loadState();n.value!==a.rawInput&&(n.value=a.rawInput),i.disabled=!e.canFillEmail,o.disabled=!e.canFillOtp,s.disabled=!e.canFillOtp||!a.autoOtp,c.disabled=!e.canFillProfile,r.textContent=a.autoOtp?`Outlook 行模式：验证码页会通过本地 API 自动收码`:`单邮箱模式：验证码需要手动输入`};return n.addEventListener(`input`,async()=>{r.textContent=(await t.saveInput(n.value)).autoOtp?`Outlook 行模式：验证码页会通过本地 API 自动收码`:`单邮箱模式：验证码需要手动输入`}),i.addEventListener(`click`,async()=>{Ma(l,`正在提交邮箱...`,`pending`),await t.saveInput(n.value),ja(l,await t.fillEmailFromInput()),await u()}),o.addEventListener(`click`,async()=>{Ma(l,`正在提交验证码...`,`pending`),ja(l,await t.fillOtp(a.value)),await u()}),s.addEventListener(`click`,async()=>{Ma(l,`等待 Outlook 验证码...`,`pending`),ja(l,await t.waitForOutlookOtp()),await u()}),c.addEventListener(`click`,async()=>{Ma(l,`正在填写资料...`,`pending`),ja(l,await t.fillProfileAndCreate()),await u()}),e.append(n,r,i,a,o,s,c,l),u(),{update:u}}function Aa(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function ja(e,t){Ma(e,t.message,t.ok?`ok`:`error`)}function Ma(e,t,n){e.textContent=t,e.dataset.type=n}var Na=`opx.versionCheck.state`,Pa={ignoredVersion:``,lastCheckedAt:0,latest:null};async function Fa(){return Ra((await t.storage.local.get(Na))[Na])}async function Ia(e){let n=Ra({...await Fa(),...e});return await t.storage.local.set({[Na]:n}),n}async function La(e){return Ia({ignoredVersion:Ba(e)})}function Ra(e){let t=Va(e)?e:{};return{ignoredVersion:Ba(t.ignoredVersion),lastCheckedAt:Number(t.lastCheckedAt||Pa.lastCheckedAt),latest:za(t.latest)}}function za(e){if(!Va(e))return null;let t=Ba(e.version),n=String(e.htmlUrl||``).trim();return!t||!n?null:{version:t,tagName:String(e.tagName||t).trim(),name:String(e.name||e.tagName||t).trim(),body:String(e.body||``).trim(),htmlUrl:n,downloadUrl:String(e.downloadUrl||n).trim(),publishedAt:String(e.publishedAt||``).trim()}}function Ba(e){return String(e||``).trim().replace(/^v/i,``)}function Va(e){return!!(e&&typeof e==`object`)}var Ha=`https://api.github.com/repos/suyancc/openai-plus-vxt/releases/latest`,Ua=1800*1e3;async function Wa(e=!1){let n=Ja(t.runtime.getManifest().version),r=await Fa();if(!e&&r.latest&&Date.now()-r.lastCheckedAt<Ua)return Ka(n,r.latest,r.ignoredVersion);try{let e=await fetch(Ha,{headers:{Accept:`application/vnd.github+json`},cache:`no-store`});if(e.status===404)return await Ia({latest:null,lastCheckedAt:Date.now()}),{currentVersion:n,latest:null,updateAvailable:!1,ignored:!1,error:`当前仓库还没有 GitHub Release`};if(!e.ok)throw Error(`GitHub API ${e.status}`);let t=qa(await e.json());return await Ia({latest:t,lastCheckedAt:Date.now()}),Ka(n,t,r.ignoredVersion)}catch(e){return{currentVersion:n,latest:r.latest,updateAvailable:!!(r.latest&&Ga(r.latest.version,n)>0),ignored:!!(r.latest&&r.ignoredVersion===r.latest.version),error:e instanceof Error?e.message:String(e)}}}function Ga(e,t){let n=Ja(e).split(`.`).map(Ya),r=Ja(t).split(`.`).map(Ya),i=Math.max(n.length,r.length);for(let e=0;e<i;e+=1){let t=(n[e]||0)-(r[e]||0);if(t!==0)return t>0?1:-1}return 0}function Ka(e,t,n){return{currentVersion:e,latest:t,updateAvailable:!!(t&&Ga(t.version,e)>0),ignored:!!(t&&n===t.version)}}function qa(e){let t=String(e.tag_name||``).trim(),n=Ja(t),r=String(e.html_url||``).trim();if(!n||!r)return null;let i=e.assets?.find(e=>{let t=String(e.name||``).toLowerCase();return t.endsWith(`.zip`)&&t.includes(`chrome`)})?.browser_download_url||e.assets?.find(e=>String(e.name||``).toLowerCase().endsWith(`.zip`))?.browser_download_url;return{version:n,tagName:t,name:String(e.name||t).trim(),body:String(e.body||``).trim(),htmlUrl:r,downloadUrl:String(i||r).trim(),publishedAt:String(e.published_at||``).trim()}}function Ja(e){return e.trim().replace(/^v/i,``)}function Ya(e){let t=Number.parseInt(e.replace(/\D.*$/,``),10);return Number.isFinite(t)?t:0}var Xa=`https://t.me/fuck_open`;function Za(e={}){let n=document.createElement(`div`);n.className=`opx-settings-overlay`,n.hidden=!0;let r=document.createElement(`section`);r.className=`opx-settings-dialog`,r.setAttribute(`role`,`dialog`),r.setAttribute(`aria-modal`,`true`),r.setAttribute(`aria-label`,`插件设置`);let i=document.createElement(`div`);i.className=`opx-settings-header`;let a=document.createElement(`div`);a.className=`opx-settings-title`;let o=document.createElement(`strong`);o.textContent=`设置`;let s=document.createElement(`span`);s.className=`opx-version-badge`,s.textContent=`v${t.runtime.getManifest().version}`;let c=eo(`×`,`关闭设置`);a.append(o,s),i.append(a,c);let l=document.createElement(`input`);l.type=`checkbox`,l.className=`opx-checkbox`;let u=document.createElement(`input`);u.type=`checkbox`,u.className=`opx-checkbox`;let d=Qa(l,`OpenAI 支付页自动填写`,`用于 pay.openai.com/c/pay 页面，填写姓名、国家、地址、邮编、电话并勾选条款。`),f=Qa(u,`PayPal 注册页自动填写`,`用于 paypal.com/checkoutweb/signup 页面，填写国家、邮箱、卡资料、姓名、地址和密码提示。`),p=document.createElement(`button`);p.className=`opx-external-link-button`,p.type=`button`,p.title=`立即检查 GitHub Release 最新版本`,p.textContent=`检测更新`;let m=document.createElement(`button`);m.className=`opx-external-link-button`,m.type=`button`,m.title=`打开 TG 群组`,m.append($a(),document.createTextNode(`TG 群组：t.me/fuck_open`));let h=document.createElement(`div`);h.className=`opx-hint`,h.textContent=`国家、城市和获取地址在“地址”tab 中操作。`;let g=document.createElement(`div`);g.className=`opx-status`,r.append(i,d,f,p,m,h,g),n.append(r),c.addEventListener(`click`,v),n.addEventListener(`click`,e=>{e.target===n&&v()}),l.addEventListener(`change`,async()=>{await lt({payOpenAiEnabled:l.checked}),$(g,`设置已保存`,`ok`)}),u.addEventListener(`change`,async()=>{await lt({payPalSignupEnabled:u.checked}),$(g,`设置已保存`,`ok`)}),m.addEventListener(`click`,()=>{window.open(Xa,`_blank`,`noopener,noreferrer`)}),p.addEventListener(`click`,async()=>{p.disabled=!0,$(g,`正在检测 GitHub 最新版本...`,`pending`);try{let t=await Wa(!0);await e.onVersionChecked?.(),t.latest&&t.updateAvailable?$(g,`发现新版本 v${t.latest.version}，顶部已显示更新提示`,`ok`):t.latest?$(g,`当前已是最新版本 v${t.currentVersion}`,`ok`):$(g,t.error||`暂未找到可用 Release`,`pending`)}catch(e){$(g,e instanceof Error?e.message:String(e),`error`)}finally{p.disabled=!1}});let _=async()=>{let e=await ut();l.checked=e.payOpenAiEnabled,u.checked=e.payPalSignupEnabled;let t=Number(e.payOpenAiEnabled)+Number(e.payPalSignupEnabled);$(g,t>0?`已开启 ${t} 项自动填写`:`自动填写未开启`,t>0?`ok`:`pending`)};return{element:n,open:()=>{n.hidden=!1,_()},update:_};function v(){n.hidden=!0}}function Qa(e,t,n){let r=document.createElement(`div`);r.className=`opx-setting-item`;let i=document.createElement(`label`);i.className=`opx-check-row`;let a=document.createElement(`span`);a.textContent=t,i.append(e,a);let o=document.createElement(`div`);return o.className=`opx-setting-description`,o.textContent=n,r.append(i,o),r}function $a(){let e=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.classList.add(`opx-telegram-icon`),e.setAttribute(`viewBox`,`0 0 24 24`),e.setAttribute(`aria-hidden`,`true`);let t=document.createElementNS(`http://www.w3.org/2000/svg`,`path`);return t.setAttribute(`fill`,`currentColor`),t.setAttribute(`d`,`M21.9 4.3 18.7 19c-.2 1-.8 1.2-1.6.8l-4.6-3.4-2.2 2.1c-.2.2-.4.4-.9.4l.3-4.7 8.5-7.7c.4-.3-.1-.5-.6-.2L7.1 12.9 2.6 11.5c-1-.3-1-1 0-1.4L20.2 3.3c.8-.3 1.5.2 1.7 1Z`),e.append(t),e}function eo(e,t){let n=document.createElement(`button`);return n.className=`opx-icon-button`,n.type=`button`,n.textContent=e,n.title=t,n.setAttribute(`aria-label`,t),n}function $(e,t,n){e.textContent=t,e.dataset.type=n}var to=3e3;function no(e){let t=document.createElement(`div`);t.className=`opx-summary`;let n=document.createElement(`textarea`);n.className=`opx-textarea opx-sms-input`,n.placeholder=`+14642649811----https://xxxx.com/xxx
每行一个号码和 API 链接`,n.autocomplete=`off`,n.spellcheck=!1;let r=document.createElement(`div`);r.className=`opx-button-row opx-sms-actions`;let i=io(`保存并开始`),a=io(`立即获取`,`opx-button opx-button-secondary`),o=io(`清空历史`,`opx-button opx-button-secondary`);r.append(i,a,o);let s=ao(`当前号码`),c=document.createElement(`div`);c.className=`opx-sms-targets`;let l=ao(`验证码历史`),u=document.createElement(`div`);u.className=`opx-sms-table`;let d=document.createElement(`div`);d.className=`opx-status`;let f=new Map,p=null,m=null,h=``,g=null,_=!1;e.append(t,ro(`接码信息`,n),r,s,c,l,u,d),n.addEventListener(`input`,()=>{y(),S()}),n.addEventListener(`focus`,()=>{_=!0}),n.addEventListener(`blur`,()=>{_=!1,b()}),i.addEventListener(`click`,async()=>{await b(),S(),await w()}),a.addEventListener(`click`,async()=>{await b(),S(),await w()}),o.addEventListener(`click`,async()=>{let e=await Ue({history:[]});p=e,O(e.history),lo(d,`验证码历史已清空，输入内容已保留。`,`ok`)});let v=async()=>{let e=await He();p=e,!_&&n.value!==e.rawInput&&(n.value=e.rawInput,h=e.rawInput,S()),O(e.history),C()};return v(),{update:v,onShow:async()=>{await v(),x()}};function y(){g&&window.clearTimeout(g),g=window.setTimeout(()=>void b(),450)}async function b(){g&&=(window.clearTimeout(g),null);let e=n.value;e!==h&&(p=await Ue({rawInput:e}),h=e,C())}function x(){m===null&&(m=window.setInterval(()=>void w(),to))}function S(){let e=Et(n.value),t=new Set(e.targets.map(e=>e.id));for(let[e]of f)t.has(e)||f.delete(e);for(let t of e.targets){let e=f.get(t.id);e?e.target=t:f.set(t.id,{target:t,status:`waiting`,message:`等待获取`,code:``,lastCheckedAt:0,inFlight:!1})}if(c.textContent=``,!e.targets.length)c.append(oo(e.errors[0]||`暂无号码，按每行“号码----API链接”输入。`));else for(let t of e.targets){let e=f.get(t.id);e&&c.append(D(e))}e.errors.length?lo(d,e.errors.join(`；`),`error`):e.targets.length?lo(d,`已加载 ${e.targets.length} 个接码链接，每 3 秒自动获取。`,`pending`):lo(d,`输入内容会自动保存。`,`pending`),C()}function C(){let e=Et(n.value),r=p?.history.length||0,i=[...f.values()].filter(e=>e.code).length;t.textContent=`${e.targets.length} 个接码链接 · ${i} 个当前验证码 · ${r} 条历史`}async function w(){let e=Et(n.value);!e.targets.length||e.errors.length||(await b(),await Promise.all(e.targets.map(e=>T(e))),S(),O(p?.history||[]))}async function T(e){let t=f.get(e.id);if(!t||t.inFlight)return;t.inFlight=!0,t.status=t.code?`found`:`waiting`,t.message=`正在获取...`,S();let n=await Vt(e);if(t.inFlight=!1,t.lastCheckedAt=Date.now(),n.kind===`code`){t.status=`found`,t.code=n.code,t.message=n.message,await E(e.phone,n.code,n.message),lo(d,`${e.phone} 收到验证码 ${n.code}`,`ok`);return}if(n.kind===`error`){t.status=`error`,t.message=n.message,lo(d,`${e.phone} 获取失败：${n.message}`,`error`);return}t.status=`waiting`,t.message=n.message}async function E(e,t,n){let r=p||await He();if(r.history.some(r=>r.phone===e&&r.code===t&&r.message===n)){p=r;return}p=await Ue({history:[{id:`${e}-${t}-${Date.now()}`,phone:e,code:t,message:n,receivedAt:Date.now()},...r.history].slice(0,80)})}function D(e){let t=document.createElement(`div`);t.className=`opx-sms-target-row`,t.dataset.status=e.status;let n=document.createElement(`div`);n.className=`opx-sms-target-main`;let r=document.createElement(`strong`);r.textContent=e.target.phone;let i=document.createElement(`span`);i.textContent=e.code?e.message:e.message||`等待获取`,n.append(r,i);let a=document.createElement(`button`);return a.className=`opx-sms-code-chip`,a.type=`button`,a.textContent=e.code||(e.inFlight?`...`:`等待`),a.disabled=!e.code,a.title=e.code?`点击复制验证码`:`尚未收到验证码`,a.addEventListener(`click`,()=>void k(e.code,a)),t.append(n,a),t}function O(e){u.textContent=``;let t=document.createElement(`div`);if(t.className=`opx-sms-table-row opx-sms-table-head`,t.append(so(`号码`),so(`验证码`),so(`时间`)),u.append(t),!e.length){let e=document.createElement(`div`);e.className=`opx-empty-inline`,e.textContent=`暂无验证码历史。`,u.append(e);return}for(let t of e){let e=document.createElement(`div`);e.className=`opx-sms-table-row`;let n=document.createElement(`button`);n.className=`opx-sms-code-chip`,n.type=`button`,n.textContent=t.code,n.title=t.message||`点击复制验证码`,n.addEventListener(`click`,()=>void k(t.code,n)),e.append(so(t.phone),co(n),so(uo(t.receivedAt))),u.append(e)}}async function k(e,t){if(!e)return;await navigator.clipboard.writeText(e);let n=t.textContent||e;t.textContent=`已复制`,t.classList.add(`is-copied`),window.setTimeout(()=>{t.textContent=n,t.classList.remove(`is-copied`)},1200)}}function ro(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function io(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function ao(e){let t=document.createElement(`div`);return t.className=`opx-section-title`,t.textContent=e,t}function oo(e){let t=document.createElement(`div`);return t.className=`opx-empty-inline`,t.textContent=e,t}function so(e){let t=document.createElement(`div`);return t.className=`opx-sms-table-cell`,t.textContent=e,t}function co(e){let t=document.createElement(`div`);return t.className=`opx-sms-table-cell`,t.append(e),t}function lo(e,t,n){e.textContent=t,e.dataset.type=n}function uo(e){return e?new Date(e).toLocaleTimeString(`zh-CN`,{hour12:!1,hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):`-`}function fo(){let e=document.createElement(`section`);e.className=`opx-version-notice`,e.hidden=!0;let t=document.createElement(`div`);t.className=`opx-version-notice-title`;let n=document.createElement(`div`);n.className=`opx-version-notice-body`;let r=document.createElement(`div`);r.className=`opx-version-notice-actions`;let i=document.createElement(`button`);i.className=`opx-mini-button`,i.type=`button`,i.textContent=`下载更新`;let a=document.createElement(`button`);a.className=`opx-mini-button opx-mini-button-secondary`,a.type=`button`,a.textContent=`更新说明`;let o=document.createElement(`button`);o.className=`opx-mini-button opx-mini-button-secondary`,o.type=`button`,o.textContent=`忽略`,r.append(i,a,o),e.append(t,n,r);let s=null;return i.addEventListener(`click`,()=>{s?.downloadUrl&&window.open(s.downloadUrl,`_blank`,`noopener,noreferrer`)}),a.addEventListener(`click`,()=>{s?.htmlUrl&&window.open(s.htmlUrl,`_blank`,`noopener,noreferrer`)}),o.addEventListener(`click`,async()=>{s&&(await La(s.version),e.hidden=!0)}),{element:e,update:async(r=!1)=>{let i=await Wa(r);s=i.latest,po(i,e,t,n)}}}function po(e,t,n,r){if(!e.latest||!e.updateAvailable||e.ignored){t.hidden=!0;return}n.textContent=`发现新版本 v${e.latest.version}`,r.textContent=mo(e.currentVersion,e.latest),t.hidden=!1}function mo(e,t){let n=t.body.split(/\r?\n/).map(e=>e.replace(/^#+\s*/,``).trim()).filter(Boolean).slice(0,2).join(` / `),r=`当前 v${e}，最新 ${t.tagName||`v${t.version}`}`;return n?`${r}。${n}`:r}var ho=`
:host {
  all: initial;
  color-scheme: light dark;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.opx-shell {
  position: fixed;
  top: 72px;
  right: 0;
  z-index: 2147483647;
  display: flex;
  align-items: flex-start;
  max-height: calc(100vh - 88px);
}

.opx-panel {
  box-sizing: border-box;
  width: min(360px, calc(100vw - 42px));
  max-height: calc(100vh - 88px);
  margin-right: 18px;
  padding: 10px;
  border: 1px solid rgba(54, 211, 153, 0.28);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.32);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-color: rgba(47, 209, 124, 0.55) rgba(15, 23, 42, 0.72);
  scrollbar-width: thin;
}

.opx-panel::-webkit-scrollbar {
  width: 8px;
}

.opx-panel::-webkit-scrollbar-track {
  background: rgba(15, 23, 42, 0.72);
  border-radius: 999px;
}

.opx-panel::-webkit-scrollbar-thumb {
  background: rgba(47, 209, 124, 0.55);
  border-radius: 999px;
}

.opx-collapse-toggle {
  box-sizing: border-box;
  width: 32px;
  min-height: 64px;
  margin: 8px 0 0 0;
  padding: 8px 6px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-right: 0;
  border-radius: 8px 0 0 8px;
  background: #0b1220;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 14px;
  writing-mode: vertical-rl;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.28);
}

.opx-shell.is-collapsed .opx-panel {
  display: none;
}

.opx-shell.is-collapsed .opx-collapse-toggle {
  margin-right: 0;
  border-radius: 8px 0 0 8px;
  background: #102019;
}

.opx-topbar {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 34px;
  gap: 6px;
  align-items: stretch;
  margin-bottom: 8px;
}

.opx-tabs {
  display: flex;
  flex-wrap: nowrap;
  gap: 4px;
  margin-bottom: 0;
  padding: 3px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 8px;
  background: rgba(15, 23, 42, 0.8);
  overflow-x: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(47, 209, 124, 0.55) transparent;
}

.opx-tabs::-webkit-scrollbar {
  height: 4px;
}

.opx-tabs::-webkit-scrollbar-thumb {
  background: rgba(47, 209, 124, 0.55);
  border-radius: 999px;
}

.opx-tab {
  flex: 1 1 0;
  min-width: 48px;
  height: 30px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 650;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-tab.is-active {
  background: #2fd17c;
  color: #04130a;
}

.opx-icon-button {
  box-sizing: border-box;
  width: 34px;
  height: 36px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-radius: 8px;
  background: #111827;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 17px;
  font-weight: 700;
  line-height: 1;
}

.opx-icon-button:hover {
  border-color: rgba(47, 209, 124, 0.74);
  color: #bbf7d0;
}

.opx-state {
  margin: 0 0 8px;
  color: #93e4bd;
  font-size: 12px;
  line-height: 16px;
}

.opx-version-notice {
  display: grid;
  gap: 7px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.42);
  border-radius: 7px;
  background: rgba(47, 209, 124, 0.1);
  color: #dcfce7;
}

.opx-version-notice[hidden] {
  display: none;
}

.opx-version-notice-title {
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 800;
  line-height: 16px;
}

.opx-version-notice-body {
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

.opx-version-notice-actions {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 54px;
  gap: 5px;
}

.opx-mini-button {
  box-sizing: border-box;
  min-width: 0;
  height: 28px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 11px;
  font-weight: 750;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-mini-button-secondary {
  border: 1px solid rgba(47, 209, 124, 0.34);
  background: rgba(15, 23, 42, 0.72);
  color: #93e4bd;
}

.opx-view {
  display: block;
}

.opx-view[hidden] {
  display: none;
}

.opx-empty-view {
  min-height: 84px;
  display: grid;
  place-items: center;
  border: 1px dashed rgba(148, 163, 184, 0.28);
  border-radius: 8px;
  color: #94a3b8;
  font-size: 13px;
}

.opx-input,
.opx-select,
.opx-textarea {
  box-sizing: border-box;
  width: 100%;
  height: 36px;
  margin: 0 0 8px;
  padding: 0 10px;
  border: 1px solid rgba(148, 163, 184, 0.32);
  border-radius: 6px;
  background: #111827;
  color: #e5f7ef;
  font: inherit;
  font-size: 13px;
  outline: none;
}

.opx-select {
  appearance: none;
}

.opx-textarea {
  min-height: 72px;
  max-height: 140px;
  padding: 9px 10px;
  resize: vertical;
  line-height: 18px;
}

.opx-input:focus,
.opx-select:focus,
.opx-textarea:focus {
  border-color: #2fd17c;
}

.opx-hint {
  margin: -2px 0 8px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-hint.is-ok {
  color: #86efac;
}

.opx-summary {
  margin: 0 0 8px;
  padding: 7px 8px;
  border: 1px solid rgba(47, 209, 124, 0.28);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.08);
  color: #bbf7d0;
  font-size: 11px;
  line-height: 15px;
  word-break: break-word;
  white-space: pre-line;
}

.opx-session-card {
  display: grid;
  gap: 5px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-session-row {
  display: grid;
  grid-template-columns: 42px minmax(0, 1fr);
  gap: 6px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-session-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  word-break: break-word;
}

.opx-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 8px;
}

.opx-team-options[hidden] {
  display: none;
}

.opx-field {
  display: block;
  min-width: 0;
}

.opx-label {
  display: block;
  margin: 0 0 4px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 14px;
}

.opx-token-textarea {
  min-height: 92px;
}

.opx-output {
  min-height: 58px;
  resize: vertical;
}

.opx-button-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 6px;
}

.opx-address-actions {
  grid-template-columns: minmax(0, 1fr);
}

.opx-button {
  box-sizing: border-box;
  width: 100%;
  height: 34px;
  margin: 0 0 10px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
}

.opx-button-secondary {
  background: #182235;
  color: #93e4bd;
  border: 1px solid rgba(47, 209, 124, 0.36);
}

.opx-button:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}

.opx-status {
  min-height: 18px;
  color: #cbd5e1;
  font-size: 12px;
  line-height: 18px;
  word-break: break-word;
}

.opx-status[data-type="ok"] {
  color: #86efac;
}

.opx-status[data-type="error"] {
  color: #fca5a5;
}

.opx-settings-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: grid;
  place-items: start center;
  padding: 22px 10px;
  background: rgba(2, 6, 23, 0.58);
}

.opx-settings-overlay[hidden] {
  display: none;
}

.opx-settings-dialog {
  box-sizing: border-box;
  width: min(300px, calc(100vw - 52px));
  max-height: calc(100vh - 44px);
  overflow-y: auto;
  padding: 10px;
  border: 1px solid rgba(47, 209, 124, 0.38);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 20px 52px rgba(0, 0, 0, 0.42);
}

.opx-settings-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 0 0 10px;
  color: #bbf7d0;
  font-size: 14px;
  line-height: 18px;
}

.opx-settings-title {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}

.opx-version-badge {
  padding: 1px 6px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.08);
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 16px;
}

.opx-settings-header .opx-icon-button {
  width: 28px;
  height: 28px;
  font-size: 18px;
}

.opx-settings-dialog .opx-grid {
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
}

.opx-setting-item {
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.22);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.54);
}

.opx-setting-item .opx-check-row {
  margin-bottom: 4px;
}

.opx-setting-description {
  margin-left: 26px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-external-link-button {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  width: 100%;
  min-height: 34px;
  margin: 0 0 8px;
  padding: 8px 10px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.1);
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  text-align: left;
}

.opx-telegram-icon {
  flex: 0 0 auto;
  width: 14px;
  height: 14px;
}

.opx-external-link-button:hover {
  border-color: rgba(47, 209, 124, 0.7);
  background: rgba(47, 209, 124, 0.16);
  color: #dcfce7;
}

.opx-external-link-button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-check-row {
  display: grid;
  grid-template-columns: 18px minmax(0, 1fr);
  gap: 8px;
  align-items: center;
  margin: 0 0 10px;
  color: #e5f7ef;
  cursor: pointer;
  font-size: 12px;
  line-height: 16px;
}

.opx-checkbox {
  width: 16px;
  height: 16px;
  accent-color: #2fd17c;
}

.opx-address-summary {
  min-height: 68px;
}

.opx-settings-buttons {
  margin-top: 2px;
}

.opx-section-title {
  margin: 10px 0 6px;
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
}

.opx-copy-list {
  display: grid;
  gap: 5px;
}

.opx-copy-section {
  display: grid;
  gap: 5px;
  margin: 5px 0 1px;
}

.opx-copy-section-title {
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
}

.opx-copy-section-body {
  display: grid;
  gap: 5px;
}

.opx-accordion-section {
  overflow: hidden;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.56);
}

.opx-accordion-section summary {
  padding: 7px 8px;
  color: #93e4bd;
  cursor: pointer;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
  list-style-position: inside;
}

.opx-accordion-section .opx-copy-section-body {
  padding: 0 6px 6px;
}

.opx-copy-row,
.opx-empty-inline {
  box-sizing: border-box;
  width: 100%;
  min-height: 30px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
  color: #cbd5e1;
  font: inherit;
  font-size: 11px;
  line-height: 15px;
  text-align: left;
  word-break: break-word;
}

.opx-copy-row {
  cursor: pointer;
}

.opx-copy-row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 4px;
  align-items: start;
}

.opx-copy-row:hover {
  border-color: rgba(47, 209, 124, 0.48);
  color: #e5f7ef;
}

.opx-copy-row.is-copied {
  border-color: rgba(47, 209, 124, 0.72);
  background: rgba(47, 209, 124, 0.12);
}

.opx-copy-label {
  color: #94a3b8;
  white-space: nowrap;
}

.opx-copy-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  overflow-wrap: anywhere;
}

.opx-copy-feedback {
  align-self: start;
  padding: 1px 5px;
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.16);
  color: #86efac !important;
  font-size: 10px;
  font-weight: 700;
  line-height: 14px;
  white-space: nowrap;
}

.opx-copy-feedback[hidden] {
  display: none;
}

.opx-empty-inline {
  color: #94a3b8;
  border-style: dashed;
}

.opx-sms-input {
  min-height: 88px;
}

.opx-sms-actions {
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.86fr) minmax(0, 0.86fr);
}

.opx-sms-targets {
  display: grid;
  gap: 6px;
}

.opx-sms-target-row {
  box-sizing: border-box;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  min-height: 44px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-sms-target-row[data-status="found"] {
  border-color: rgba(47, 209, 124, 0.5);
  background: rgba(47, 209, 124, 0.1);
}

.opx-sms-target-row[data-status="error"] {
  border-color: rgba(248, 113, 113, 0.42);
  background: rgba(127, 29, 29, 0.2);
}

.opx-sms-target-main {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.opx-sms-target-main strong,
.opx-sms-target-main span {
  min-width: 0;
  overflow-wrap: anywhere;
}

.opx-sms-target-main strong {
  color: #e5f7ef;
  font-size: 12px;
  line-height: 16px;
}

.opx-sms-target-main span {
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-sms-code-chip {
  box-sizing: border-box;
  min-width: 56px;
  max-width: 92px;
  min-height: 28px;
  padding: 4px 8px;
  border: 1px solid rgba(47, 209, 124, 0.44);
  border-radius: 999px;
  background: #182235;
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-sms-code-chip:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-sms-code-chip.is-copied {
  background: #2fd17c;
  color: #04130a;
}

.opx-sms-table {
  display: grid;
  gap: 5px;
}

.opx-sms-table-row {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(64px, 0.8fr) 62px;
  gap: 6px;
  align-items: center;
  min-height: 32px;
  padding: 5px 6px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.58);
}

.opx-sms-table-head {
  min-height: 24px;
  background: transparent;
  border-color: transparent;
  color: #93e4bd;
  font-weight: 700;
}

.opx-sms-table-cell {
  min-width: 0;
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

@media (max-height: 640px) {
  .opx-shell {
    top: 12px;
    max-height: calc(100vh - 24px);
  }

  .opx-panel {
    max-height: calc(100vh - 24px);
  }
}
`;function go(e,t){e.innerHTML=``;let n=document.createElement(`style`);n.textContent=ho;let r=document.createElement(`div`);r.className=`opx-shell`;let i=document.createElement(`button`);i.className=`opx-collapse-toggle`,i.type=`button`,i.textContent=`收起`,i.title=`收起侧边栏`,i.setAttribute(`aria-expanded`,`true`);let a=document.createElement(`aside`);a.className=`opx-panel`;let o=document.createElement(`div`);o.className=`opx-topbar`;let s=document.createElement(`div`);s.className=`opx-tabs`;let c=yo(`register`,`注册`),l=yo(`link`,`提链接`),u=yo(`oauth`,`OAuth`),d=yo(`address`,`地址`),f=yo(`sms`,`接码`),p=yo(`auto`,`一键`);s.append(p,c,l,u,d,f);let m=document.createElement(`button`);m.className=`opx-icon-button`,m.type=`button`,m.textContent=`⚙`,m.title=`打开设置`,m.setAttribute(`aria-label`,`打开设置`);let h=document.createElement(`div`);h.className=`opx-state`;let g=vo(),_=vo(),v=vo(),y=vo(),b=vo(),x=vo(),S={auto:Gi(x),register:ka(g,t),link:qi(_),oauth:ba(v),address:Fi(y),sms:no(b)},C=fo(),w=Za({onVersionChecked:()=>C.update(!0)}),T=`auto`,E=e=>{r.classList.toggle(`is-collapsed`,e),i.textContent=e?`展开`:`收起`,i.title=e?`展开侧边栏`:`收起侧边栏`,i.setAttribute(`aria-expanded`,e?`false`:`true`)},D=async e=>{We(e)&&(T=e,await Pe(e),O(),await S[e].onShow?.(),await k())},O=()=>{for(let e of[p,c,l,u,d,f])e.classList.toggle(`is-active`,e.dataset.tab===T);x.hidden=T!==`auto`,g.hidden=T!==`register`,_.hidden=T!==`link`,v.hidden=T!==`oauth`,y.hidden=T!==`address`,b.hidden=T!==`sms`},k=async()=>{let e=await P();T=e.activeTab,E(e.panelCollapsed),O(),h.textContent=_o(T,t),await S[T].update()};c.addEventListener(`click`,()=>void D(`register`)),l.addEventListener(`click`,()=>void D(`link`)),u.addEventListener(`click`,()=>void D(`oauth`)),d.addEventListener(`click`,()=>void D(`address`)),f.addEventListener(`click`,()=>void D(`sms`)),p.addEventListener(`click`,()=>void D(`auto`)),m.addEventListener(`click`,()=>w.open()),i.addEventListener(`click`,()=>{let e=!r.classList.contains(`is-collapsed`);E(e),Fe(e)}),o.append(s,m),a.append(o,C.element,h,x,g,_,v,y,b,w.element),r.append(i,a),e.append(n,r),window.setInterval(()=>void k(),1e3),window.setTimeout(()=>void C.update(),800),k().then(()=>{S[T].onShow?.()})}function _o(e,t){return e===`auto`?`一键自动化`:e===`register`?t.getPageState().label:e===`link`?`提链接：ChatGPT session`:e===`oauth`?`OAuth：授权码导出`:e===`address`?`地址：随机资料`:`接码：短信验证码`}function vo(){let e=document.createElement(`section`);return e.className=`opx-view`,e}function yo(e,t){let n=document.createElement(`button`);return n.className=`opx-tab`,n.type=`button`,n.dataset.tab=e,n.textContent=t,n}var bo=`opx-assistant-root`;function xo(){if(document.getElementById(bo))return;let e=document.createElement(`div`);e.id=bo,document.documentElement.append(e);let t=e.attachShadow({mode:`open`}),n=et();go(t,n),n.autoRunForCurrentPage()}var So=`__opx_assistant_content_loaded__`,Co=e({matches:[`https://chatgpt.com/*`,`https://auth.openai.com/*`,`https://pay.openai.com/*`,`https://www.paypal.com/*`,`https://paypal.com/*`,`http://127.0.0.1:1455/*`,`http://localhost:1455/*`],runAt:`document_idle`,registration:`manifest`,main(){let e=globalThis;if(!e[So]){e[So]=!0,xo();try{An()}catch(e){console.warn(`[OPX] pay autofill init failed`,e)}try{yr()}catch(e){console.warn(`[OPX] PayPal autofill init failed`,e)}try{sn()}catch(e){console.warn(`[OPX] orchestrator resume failed`,e)}}}}),wo={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},To=class e extends Event{static EVENT_NAME=Eo(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function Eo(e){return`${t?.runtime?.id}:content:${e}`}var Do=typeof globalThis.navigation?.addEventListener==`function`;function Oo(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Do?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new To(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new To(e,t)),t=e)},1e3))}}}var ko=class e{static SCRIPT_STARTED_MESSAGE_TYPE=Eo(`wxt:content-script-started`);id;abortController;locationWatcher=Oo(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?Eo(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),wo.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Ao={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Co;return await e(new ko(`content`,t))}catch(e){throw Ao.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;