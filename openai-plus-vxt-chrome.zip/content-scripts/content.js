// OpenAI Plus VXT - Content Script
(function() {
  var browser = (typeof chrome !== 'undefined') ? chrome : (typeof browser !== 'undefined' ? browser : {});
  function defineContentScript(opts) { opts.main(); }

(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/features/settings/state.ts
  async function loadExtensionSettings() {
    const data = await browser.storage.local.get(SETTINGS_STORAGE_KEY);
    return normalizeExtensionSettings(data[SETTINGS_STORAGE_KEY]);
  }
  async function saveAddressAutofillSettings(patch) {
    const current = await loadExtensionSettings();
    const addressAutofill = normalizeAddressAutofillSettings({
      ...current.addressAutofill,
      ...patch,
      updatedAt: Date.now()
    });
    const next = normalizeExtensionSettings({
      ...current,
      addressAutofill,
      updatedAt: Date.now()
    });
    await browser.storage.local.set({ [SETTINGS_STORAGE_KEY]: next });
    return next.addressAutofill;
  }
  async function loadAddressAutofillSettings() {
    return (await loadExtensionSettings()).addressAutofill;
  }
  function normalizeExtensionSettings(value) {
    const source = isRecord3(value) ? value : {};
    return {
      addressAutofill: normalizeAddressAutofillSettings(source.addressAutofill),
      updatedAt: Number(source.updatedAt || DEFAULT_SETTINGS.updatedAt)
    };
  }
  function normalizeAddressAutofillSettings(value) {
    const source = isRecord3(value) ? value : {};
    const payOpenAiEnabled = source.payOpenAiEnabled === void 0 ? DEFAULT_ADDRESS_AUTOFILL_SETTINGS.payOpenAiEnabled : Boolean(source.payOpenAiEnabled);
    const payPalSignupEnabled = source.payPalSignupEnabled === void 0 ? DEFAULT_ADDRESS_AUTOFILL_SETTINGS.payPalSignupEnabled : Boolean(source.payPalSignupEnabled);
    return {
      payOpenAiEnabled,
      payPalSignupEnabled,
      countryCode: normalizeCountryCode(source.countryCode || source.country),
      city: String(source.city || source.region || DEFAULT_ADDRESS_AUTOFILL_SETTINGS.city),
      lastAddress: normalizeAddress(source.lastAddress),
      updatedAt: Number(source.updatedAt || DEFAULT_ADDRESS_AUTOFILL_SETTINGS.updatedAt)
    };
  }
  function normalizeAddress(value) {
    if (!isRecord3(value)) {
      return null;
    }
    const line1 = String(value.line1 || "").trim();
    const city = String(value.city || "").trim();
    const countryCode = String(value.countryCode || value.country || "US").trim().toUpperCase();
    const rawState = String(value.state || "").trim();
    const state = countryCode === "US" ? rawState.toUpperCase() : rawState;
    const postalCode = String(value.postalCode || "").trim();
    if (!line1 || !city || !state || !postalCode) {
      return null;
    }
    return {
      id: String(value.id || `${Date.now()}`),
      fullName: String(value.fullName || "").trim(),
      line1,
      line2: String(value.line2 || "").trim(),
      city,
      state,
      stateFull: String(value.stateFull || "").trim(),
      postalCode,
      countryCode,
      countryLabel: String(value.countryLabel || "").trim(),
      countryPath: String(value.countryPath || "").trim(),
      phone: String(value.phone || "").trim(),
      identity: normalizeIdentity(value.identity),
      employment: normalizeEmployment(value.employment),
      creditCard: normalizeCreditCard(value.creditCard),
      source: value.source === "fallback" ? "fallback" : "meiguodizhi",
      fetchedAt: Number(value.fetchedAt || 0)
    };
  }
  function normalizeIdentity(value) {
    const source = isRecord3(value) ? value : {};
    return {
      gender: String(source.gender || "").trim(),
      title: String(source.title || "").trim(),
      birthday: String(source.birthday || "").trim(),
      username: String(source.username || "").trim(),
      password: String(source.password || "").trim(),
      temporaryMail: String(source.temporaryMail || "").trim(),
      system: String(source.system || "").trim(),
      userAgent: String(source.userAgent || "").trim(),
      website: String(source.website || "").trim(),
      securityQuestion: String(source.securityQuestion || "").trim(),
      securityAnswer: String(source.securityAnswer || "").trim()
    };
  }
  function normalizeEmployment(value) {
    const source = isRecord3(value) ? value : {};
    return {
      educationalBackground: String(source.educationalBackground || "").trim(),
      occupation: String(source.occupation || "").trim(),
      employmentStatus: String(source.employmentStatus || "").trim(),
      monthlySalary: String(source.monthlySalary || "").trim(),
      companySize: String(source.companySize || "").trim(),
      companyName: String(source.companyName || "").trim()
    };
  }
  function normalizeCreditCard(value) {
    const source = isRecord3(value) ? value : {};
    const number = String(source.number || "").replace(/\D/g, "");
    const last4 = String(source.last4 || number.slice(-4) || "").replace(/\D/g, "").slice(-4);
    return {
      type: String(source.type || "").trim(),
      number,
      cvv: String(source.cvv || "").trim(),
      expires: String(source.expires || "").trim(),
      last4,
      maskedNumber: String(source.maskedNumber || (last4 ? `**** **** **** ${last4}` : "")).trim()
    };
  }
  function isRecord3(value) {
    return Boolean(value && typeof value === "object");
  }
  function normalizeCountryCode(value) {
    const code = String(value || DEFAULT_ADDRESS_AUTOFILL_SETTINGS.countryCode).trim().toUpperCase();
    return SUPPORTED_COUNTRY_CODES.has(code) ? code : DEFAULT_ADDRESS_AUTOFILL_SETTINGS.countryCode;
  }
  var SETTINGS_STORAGE_KEY, DEFAULT_ADDRESS_AUTOFILL_SETTINGS, DEFAULT_SETTINGS, SUPPORTED_COUNTRY_CODES;
  var init_state = __esm({
    "src/features/settings/state.ts"() {
      SETTINGS_STORAGE_KEY = "opx.extension.settings";
      DEFAULT_ADDRESS_AUTOFILL_SETTINGS = {
        payOpenAiEnabled: true,
        payPalSignupEnabled: true,
        countryCode: "US",
        city: "",
        lastAddress: null,
        updatedAt: 0
      };
      DEFAULT_SETTINGS = {
        addressAutofill: DEFAULT_ADDRESS_AUTOFILL_SETTINGS,
        updatedAt: 0
      };
      SUPPORTED_COUNTRY_CODES = /* @__PURE__ */ new Set([
        "RANDOM",
        "US",
        "CA",
        "AU",
        "JP",
        "TW",
        "KR",
        "HK",
        "GB",
        "DE",
        "SG",
        "FR",
        "IT",
        "ES",
        "NL",
        "MY",
        "RU",
        "CN",
        "TH",
        "PH",
        "AR",
        "TR",
        "VN"
      ]);
    }
  });

  // src/features/address-autofill/pay-openai-autofill.ts
  var pay_openai_autofill_exports = {};
  __export(pay_openai_autofill_exports, {
    fillPayOpenAiAddressNow: () => fillPayOpenAiAddressNow,
    initPayOpenAiAddressAutofill: () => initPayOpenAiAddressAutofill
  });
  function initPayOpenAiAddressAutofill() {
    if (initialized || location.hostname !== "pay.openai.com") {
      return;
    }
    initialized = true;
    installStorageListener();
    installObserver();
    scheduleAutofill(800);
  }
  async function runAutofill() {
    if (running) {
      return;
    }
    running = true;
    try {
      const settings = await loadAddressAutofillSettings();
      if (!settings.payOpenAiEnabled) {
        console.info(`${LOG_PREFIX} disabled`);
        return;
      }
      const address = await getPageAddress(settings);
      if (!address) {
        console.info(`${LOG_PREFIX} no address available`);
        return;
      }
      const result = await fillPayOpenAiAddressNow(address);
      console.info(`${LOG_PREFIX} ${result.message}`, {
        city: address.city,
        state: address.state,
        postalCode: address.postalCode,
        country: address.countryCode,
        source: address.source
      });
    } catch (error) {
      console.warn(`${LOG_PREFIX} failed`, error);
    } finally {
      running = false;
    }
  }
  async function fillPayOpenAiAddressNow(address) {
    if (location.hostname !== "pay.openai.com") {
      return { ok: false, filled: 0, message: "\u5F53\u524D\u4E0D\u662F pay.openai.com \u9875\u9762" };
    }
    selectPaypalIfPresent();
    await delay(450);
    const filled = await fillCheckoutFields(address);
    return {
      ok: filled > 0,
      filled,
      message: filled > 0 ? `\u5DF2\u586B\u5199 OpenAI \u652F\u4ED8\u9875 ${filled} \u9879` : "\u672A\u627E\u5230\u53EF\u586B\u5199\u7684 OpenAI \u652F\u4ED8\u5B57\u6BB5"
    };
  }
  async function getPageAddress(settings) {
    const scope = `${settings.countryCode}|${settings.city}`;
    if (pageAddress && pageAddressScope === scope) {
      return pageAddress;
    }
    pageAddress = await fetchAndStoreAddress(settings);
    pageAddressScope = scope;
    return pageAddress;
  }
  async function fetchAndStoreAddress(settings) {
    const response = await browser.runtime.sendMessage({
      type: "opx:fetch-random-address",
      countryCode: settings.countryCode,
      city: settings.city
    });
    if (!isRandomAddressResponse(response) || !response.ok || !response.address) {
      console.warn(`${LOG_PREFIX} address fetch failed`, response);
      return null;
    }
    await saveAddressAutofillSettings({ lastAddress: response.address });
    return response.address;
  }
  async function fillCheckoutFields(address) {
    let filled = 0;
    filled += fillInput("#billingName", address.fullName, true);
    filled += fillSelect("#billingCountry", address.countryCode, [address.countryLabel, address.countryCode]);
    if (document.querySelector("#billingCountry")) {
      await delay(550);
    }
    filled += fillInput("#billingAddressLine1", address.line1, true);
    filled += fillInput("#billingAddressLine2", address.line2, true);
    filled += fillInput("#billingLocality", address.city, true);
    filled += fillSelectOrInput("#billingAdministrativeArea", address.state, [address.stateFull, address.state]);
    filled += fillInput("#billingPostalCode", address.postalCode, true);
    filled += fillInput("#phoneNumber", address.phone, false);
    filled += fillByAutocomplete("billing address-line1", address.line1);
    filled += fillByAutocomplete("billing address-line2", address.line2);
    filled += fillByAutocomplete("billing address-level2", address.city);
    filled += fillByAutocomplete("billing postal-code", address.postalCode);
    filled += fillSelectOrInputByAutocomplete("billing address-level1", address.state, [address.stateFull, address.state]);
    filled += fillSelectByAutocomplete("billing country", address.countryCode, [address.countryLabel, address.countryCode]);
    filled += checkVisibleTermsCheckboxes();
    return filled;
  }
  function selectPaypalIfPresent() {
    const paypalRadio = document.querySelector("#payment-method-accordion-item-title-paypal");
    if (paypalRadio?.checked) {
      return true;
    }
    for (const selector of PAYPAL_SELECTORS) {
      const element = document.querySelector(selector);
      if (!element || !isVisible2(element)) {
        continue;
      }
      clickElement(element);
      return true;
    }
    const textMatch = Array.from(document.querySelectorAll('button, label, [role="button"], [role="radio"], [data-testid], div')).filter(isVisible2).find((element) => normalizedText(element.innerText || element.textContent).includes("paypal"));
    if (textMatch) {
      clickElement(textMatch);
      return true;
    }
    return false;
  }
  function fillInput(selector, value, overwrite) {
    if (!value) {
      return 0;
    }
    const input = document.querySelector(selector);
    if (!isTextControl(input) || !isVisible2(input) || isSensitivePaymentField(input)) {
      return 0;
    }
    if (!overwrite && input.value.trim()) {
      return 0;
    }
    if (input.value === value) {
      return 0;
    }
    setNativeValue4(input, value);
    return 1;
  }
  function fillByAutocomplete(autocomplete, value) {
    const selector = `input[autocomplete="${cssEscape(autocomplete)}"], textarea[autocomplete="${cssEscape(autocomplete)}"]`;
    const input = document.querySelector(selector);
    if (!isTextControl(input) || !isVisible2(input) || input.value === value || isSensitivePaymentField(input)) {
      return 0;
    }
    setNativeValue4(input, value);
    return 1;
  }
  function fillSelect(selector, preferredValue, preferredLabels) {
    const select = document.querySelector(selector);
    if (!isSelectControl(select) || !isVisible2(select)) {
      return 0;
    }
    return setSelectOption(select, preferredValue, preferredLabels);
  }
  function fillSelectByAutocomplete(autocomplete, preferredValue, preferredLabels) {
    const select = document.querySelector(`select[autocomplete="${cssEscape(autocomplete)}"]`);
    if (!isSelectControl(select) || !isVisible2(select)) {
      return 0;
    }
    return setSelectOption(select, preferredValue, preferredLabels);
  }
  function fillSelectOrInput(selector, preferredValue, preferredLabels) {
    const element = document.querySelector(selector);
    if (isSelectControl(element)) {
      return isVisible2(element) ? setSelectOption(element, preferredValue, preferredLabels) : 0;
    }
    if (isTextControl(element)) {
      return fillInput(selector, preferredValue, true);
    }
    return 0;
  }
  function fillSelectOrInputByAutocomplete(autocomplete, preferredValue, preferredLabels) {
    const select = document.querySelector(`select[autocomplete="${cssEscape(autocomplete)}"]`);
    if (isSelectControl(select)) {
      return isVisible2(select) ? setSelectOption(select, preferredValue, preferredLabels) : 0;
    }
    return fillByAutocomplete(autocomplete, preferredValue || preferredLabels[0] || "");
  }
  function setSelectOption(select, preferredValue, preferredLabels) {
    const options = Array.from(select.options).filter((option2) => !option2.disabled && option2.value);
    const normalizedPreferred = normalizedText(preferredValue);
    const labelNeedles = preferredLabels.map((label) => normalizedText(label)).filter(Boolean);
    const option = options.find((item) => normalizedText(item.value) === normalizedPreferred) || options.find((item) => labelNeedles.some((needle) => normalizedText(`${item.text} ${item.value}`).includes(needle)));
    if (!option || select.value === option.value) {
      return 0;
    }
    select.value = option.value;
    emitChange(select);
    return 1;
  }
  function setNativeValue4(input, value) {
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor?.set) {
      descriptor.set.call(input, value);
    } else {
      input.value = value;
    }
    emitChange(input);
  }
  function checkVisibleTermsCheckboxes() {
    let checked = 0;
    const checkboxes = Array.from(document.querySelectorAll('input[type="checkbox"]')).filter(isVisible2).filter((checkbox) => !checkbox.checked).filter((checkbox) => {
      const text = normalizedText([
        checkbox.id,
        checkbox.name,
        checkbox.getAttribute("aria-label"),
        checkbox.closest("label")?.textContent,
        checkbox.parentElement?.textContent
      ].join(" "));
      return text.includes("terms") || text.includes("consent") || text.includes("\u4F7F\u7528\u6761\u6B3E") || text.includes("\u9690\u79C1\u653F\u7B56") || text.includes("\u53D6\u6D88") || checkbox.id === "termsOfServiceConsentCheckbox";
    });
    for (const checkbox of checkboxes) {
      checkbox.click();
      checked += 1;
    }
    return checked;
  }
  function emitChange(element) {
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function clickElement(element) {
    element.scrollIntoView({ block: "center", inline: "center" });
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      const EventCtor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
      element.dispatchEvent(new EventCtor(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        button: 0,
        buttons: type.endsWith("down") ? 1 : 0,
        pointerId: 1,
        pointerType: "mouse"
      }));
    }
    element.click();
  }
  function installObserver() {
    const observer2 = new MutationObserver(() => scheduleAutofill(250));
    observer2.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  function installStorageListener() {
    browser.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") {
        return;
      }
      if (Object.keys(changes).some((key) => key.includes("settings"))) {
        pageAddress = null;
        pageAddressScope = "";
        scheduleAutofill(100);
      }
    });
  }
  function scheduleAutofill(delayMs) {
    if (scheduledTimer) {
      window.clearTimeout(scheduledTimer);
    }
    scheduledTimer = window.setTimeout(() => {
      scheduledTimer = null;
      void runAutofill();
    }, delayMs);
  }
  function isVisible2(element) {
    const htmlElement = element;
    if ("disabled" in htmlElement && Boolean(htmlElement.disabled)) {
      return false;
    }
    const style = window.getComputedStyle(htmlElement);
    const rect = htmlElement.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function isSensitivePaymentField(element) {
    const haystack = normalizedText([
      element.getAttribute("aria-label"),
      element.getAttribute("placeholder"),
      element.getAttribute("autocomplete"),
      element.getAttribute("name"),
      element.getAttribute("id")
    ].join(" "));
    return [
      "cc-number",
      "card number",
      "credit card",
      "security code",
      "cvc",
      "cvv",
      "expiry",
      "expiration"
    ].some((needle) => haystack.includes(needle));
  }
  function isTextControl(element) {
    return Boolean(element && (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement));
  }
  function isSelectControl(element) {
    return Boolean(element && element instanceof HTMLSelectElement);
  }
  function normalizedText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function cssEscape(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
      return CSS.escape(value);
    }
    return value.replace(/"/g, '\\"');
  }
  function delay(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
  function isRandomAddressResponse(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }
  var LOG_PREFIX, PAYPAL_SELECTORS, initialized, running, scheduledTimer, pageAddress, pageAddressScope;
  var init_pay_openai_autofill = __esm({
    "src/features/address-autofill/pay-openai-autofill.ts"() {
      init_state();
      LOG_PREFIX = "[OPX Pay Autofill]";
      PAYPAL_SELECTORS = [
        '[data-testid="paypal-accordion-item"]',
        "#payment-method-accordion-item-title-paypal",
        'button[data-testid="paypal-accordion-item-button"]',
        'button[aria-label*="PayPal"]',
        'button[aria-label*="paypal" i]'
      ];
      initialized = false;
      running = false;
      scheduledTimer = null;
      pageAddress = null;
      pageAddressScope = "";
    }
  });

  // src/features/register/chatgpt-auth-page.ts
  var EMAIL_SELECTORS = [
    "input#email",
    'input[name="email"]',
    'input[type="email"]',
    'input[autocomplete="email"]'
  ];
  var SUBMIT_SELECTORS = [
    'button[type="submit"]',
    'form button:not([type="button"])'
  ];
  function isChatGptLoginPage() {
    if (location.hostname !== "chatgpt.com" && location.hostname !== "auth.openai.com") {
      return false;
    }
    if (location.pathname.startsWith("/auth/login")) {
      return true;
    }
    const emailInput = document.querySelector(
      'input#email, input[name="email"], input[type="email"], input[autocomplete="email"]'
    );
    if (emailInput && isVisible(emailInput)) {
      return true;
    }
    if (location.hostname === "auth.openai.com" && document.querySelector('input[name="email"], input[type="email"]')) {
      return true;
    }
    return false;
  }
  function isVisible(element) {
    const el = element;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }
  async function fillEmailAndContinue(email) {
    const input = findFirst(EMAIL_SELECTORS);
    if (!input) {
      return fail("\u6CA1\u6709\u627E\u5230\u90AE\u7BB1\u8F93\u5165\u6846");
    }
    setNativeValue(input, email);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await waitForUiTick();
    const button = findSubmitButton();
    if (!button) {
      return fail("\u6CA1\u6709\u627E\u5230\u7EE7\u7EED\u6309\u94AE");
    }
    if (button.disabled) {
      await waitForEnabled(button, 2500);
    }
    if (button.disabled) {
      return fail("\u7EE7\u7EED\u6309\u94AE\u4ECD\u7136\u4E0D\u53EF\u70B9\u51FB");
    }
    button.click();
    return ok("\u5DF2\u586B\u5165\u90AE\u7BB1\u5E76\u70B9\u51FB\u7EE7\u7EED");
  }
  function findSubmitButton() {
    for (const selector of SUBMIT_SELECTORS) {
      const button = document.querySelector(selector);
      if (button) {
        return button;
      }
    }
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const text = (button.textContent || "").trim();
      return text === "\u7EE7\u7EED" || text.toLowerCase() === "continue";
    }) ?? null;
  }
  function findFirst(selectors) {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        return element;
      }
    }
    return null;
  }
  function setNativeValue(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    descriptor?.set?.call(input, value);
  }
  function waitForUiTick() {
    return new Promise((resolve) => window.setTimeout(resolve, 60));
  }
  function waitForEnabled(button, timeoutMs) {
    const started = Date.now();
    return new Promise((resolve) => {
      const check = () => {
        if (!button.disabled || Date.now() - started >= timeoutMs) {
          resolve();
          return;
        }
        window.setTimeout(check, 100);
      };
      check();
    });
  }
  function ok(message) {
    return { ok: true, message };
  }
  function fail(message) {
    return { ok: false, message };
  }

  // src/features/register/openai-email-verification-page.ts
  var OTP_SELECTORS = [
    'input[name="code"]',
    'input[name="otp"]',
    'input[autocomplete="one-time-code"]',
    'input[inputmode="numeric"]',
    'input[type="text"]'
  ];
  function isEmailVerificationPage() {
    return location.hostname === "auth.openai.com" && location.pathname.startsWith("/email-verification");
  }
  async function fillOtpAndContinue(code) {
    const normalized = code.replace(/\D/g, "");
    if (!normalized) {
      return fail2("\u9A8C\u8BC1\u7801\u4E0D\u80FD\u4E3A\u7A7A");
    }
    const input = findOtpInput();
    if (!input) {
      return fail2("\u6CA1\u6709\u627E\u5230\u9A8C\u8BC1\u7801\u8F93\u5165\u6846");
    }
    setNativeValue2(input, normalized);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await waitForUiTick2();
    const button = findContinueButton();
    if (!button) {
      return fail2("\u6CA1\u6709\u627E\u5230\u9A8C\u8BC1\u7801\u7EE7\u7EED\u6309\u94AE");
    }
    if (button.disabled) {
      await waitForEnabled2(button, 2500);
    }
    if (button.disabled) {
      return fail2("\u9A8C\u8BC1\u7801\u7EE7\u7EED\u6309\u94AE\u4ECD\u7136\u4E0D\u53EF\u70B9\u51FB");
    }
    button.click();
    return ok2("\u5DF2\u586B\u5165\u9A8C\u8BC1\u7801\u5E76\u70B9\u51FB\u7EE7\u7EED");
  }
  function findOtpInput() {
    for (const selector of OTP_SELECTORS) {
      const input = document.querySelector(selector);
      if (input) {
        return input;
      }
    }
    const candidates = Array.from(document.querySelectorAll("input"));
    return candidates.find((input) => {
      const label = [
        input.placeholder,
        input.ariaLabel,
        input.name,
        input.id
      ].join(" ").toLowerCase();
      return label.includes("code") || label.includes("otp") || label.includes("\u9A8C\u8BC1");
    }) ?? null;
  }
  function findContinueButton() {
    const submit = document.querySelector('button[type="submit"]');
    if (submit) {
      return submit;
    }
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const text = (button.textContent || "").trim();
      return text === "\u7EE7\u7EED" || text.toLowerCase() === "continue";
    }) ?? null;
  }
  function setNativeValue2(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    descriptor?.set?.call(input, value);
  }
  function waitForUiTick2() {
    return new Promise((resolve) => window.setTimeout(resolve, 60));
  }
  function waitForEnabled2(button, timeoutMs) {
    const started = Date.now();
    return new Promise((resolve) => {
      const check = () => {
        if (!button.disabled || Date.now() - started >= timeoutMs) {
          resolve();
          return;
        }
        window.setTimeout(check, 100);
      };
      check();
    });
  }
  function ok2(message) {
    return { ok: true, message };
  }
  function fail2(message) {
    return { ok: false, message };
  }

  // src/features/register/openai-about-you-page.ts
  var NAME_SELECTORS = [
    'input[name="name"]',
    'input[name="fullName"]',
    'input[autocomplete="name"]',
    'input[type="text"]'
  ];
  var AGE_SELECTORS = [
    'input[name="age"]',
    'input[inputmode="numeric"]',
    'input[type="number"]',
    'input[type="text"]'
  ];
  var FIRST_NAMES = [
    "Arlen",
    "Brennan",
    "Calvin",
    "Darian",
    "Elliot",
    "Finley",
    "Gavin",
    "Harlan",
    "Jasper",
    "Kieran",
    "Landon",
    "Morgan",
    "Nolan",
    "Parker",
    "Rowan",
    "Sawyer",
    "Tristan",
    "Warren"
  ];
  function isAboutYouPage() {
    return location.hostname === "auth.openai.com" && location.pathname.startsWith("/about-you");
  }
  async function fillAboutYouAndCreate() {
    const nameInput = findNameInput();
    const ageInput = findAgeInput(nameInput);
    if (!nameInput) {
      return fail3("\u6CA1\u6709\u627E\u5230\u5168\u540D\u8F93\u5165\u6846");
    }
    if (!ageInput) {
      return fail3("\u6CA1\u6709\u627E\u5230\u5E74\u9F84\u8F93\u5165\u6846");
    }
    const name = randomName();
    const age = String(randomInt(25, 55));
    setNativeValue3(nameInput, name);
    nameInput.dispatchEvent(new Event("input", { bubbles: true }));
    nameInput.dispatchEvent(new Event("change", { bubbles: true }));
    setNativeValue3(ageInput, age);
    ageInput.dispatchEvent(new Event("input", { bubbles: true }));
    ageInput.dispatchEvent(new Event("change", { bubbles: true }));
    await waitForUiTick3();
    const button = findCreateButton();
    if (!button) {
      return fail3("\u6CA1\u6709\u627E\u5230\u5B8C\u6210\u8D26\u6237\u521B\u5EFA\u6309\u94AE");
    }
    if (button.disabled) {
      await waitForEnabled3(button, 2500);
    }
    if (button.disabled) {
      return fail3("\u5B8C\u6210\u8D26\u6237\u521B\u5EFA\u6309\u94AE\u4ECD\u7136\u4E0D\u53EF\u70B9\u51FB");
    }
    button.click();
    return ok3(`\u5DF2\u586B\u5199 ${name} / ${age} \u5E76\u70B9\u51FB\u521B\u5EFA`);
  }
  function findNameInput() {
    const byLabel = findInputByText(["\u5168\u540D", "\u540D\u5B57", "name", "full name"]);
    if (byLabel) {
      return byLabel;
    }
    for (const selector of NAME_SELECTORS) {
      const input = document.querySelector(selector);
      if (input && !looksLikeAgeInput(input)) {
        return input;
      }
    }
    return textInputs().find((input) => !looksLikeAgeInput(input)) ?? null;
  }
  function findAgeInput(nameInput) {
    const byLabel = findInputByText(["\u5E74\u9F84", "age"]);
    if (byLabel && byLabel !== nameInput) {
      return byLabel;
    }
    for (const selector of AGE_SELECTORS) {
      const inputs = Array.from(document.querySelectorAll(selector));
      const input = inputs.find((item) => item !== nameInput && looksLikeAgeInput(item));
      if (input) {
        return input;
      }
    }
    return textInputs().find((input) => input !== nameInput) ?? null;
  }
  function findInputByText(keys) {
    const inputs = textInputs();
    for (const input of inputs) {
      const haystack = [
        input.name,
        input.id,
        input.placeholder,
        input.ariaLabel,
        input.getAttribute("aria-labelledby") ? labelText(input.getAttribute("aria-labelledby") || "") : "",
        input.closest("label")?.textContent || "",
        input.parentElement?.textContent || ""
      ].join(" ").toLowerCase();
      if (keys.some((key) => haystack.includes(key.toLowerCase()))) {
        return input;
      }
    }
    return null;
  }
  function labelText(ids) {
    return ids.split(/\s+/).map((id) => document.getElementById(id)?.textContent || "").join(" ");
  }
  function textInputs() {
    return Array.from(document.querySelectorAll("input")).filter((input) => {
      const type = (input.type || "text").toLowerCase();
      return ["text", "number", "tel", ""].includes(type);
    });
  }
  function looksLikeAgeInput(input) {
    const text = [
      input.name,
      input.id,
      input.placeholder,
      input.ariaLabel,
      input.inputMode,
      input.type,
      input.parentElement?.textContent || ""
    ].join(" ").toLowerCase();
    return text.includes("age") || text.includes("\u5E74\u9F84") || text.includes("numeric") || input.type === "number";
  }
  function findCreateButton() {
    const submit = document.querySelector('button[type="submit"]');
    if (submit) {
      return submit;
    }
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const text = (button.textContent || "").trim().toLowerCase();
      return text.includes("\u5B8C\u6210\u5E10\u6237\u521B\u5EFA") || text.includes("\u5B8C\u6210\u8D26\u6237\u521B\u5EFA") || text.includes("create account") || text.includes("continue");
    }) ?? null;
  }
  function setNativeValue3(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    descriptor?.set?.call(input, value);
  }
  function waitForUiTick3() {
    return new Promise((resolve) => window.setTimeout(resolve, 80));
  }
  function waitForEnabled3(button, timeoutMs) {
    const started = Date.now();
    return new Promise((resolve) => {
      const check = () => {
        if (!button.disabled || Date.now() - started >= timeoutMs) {
          resolve();
          return;
        }
        window.setTimeout(check, 100);
      };
      check();
    });
  }
  function randomName() {
    return FIRST_NAMES[randomInt(0, FIRST_NAMES.length - 1)];
  }
  function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  function ok3(message) {
    return { ok: true, message };
  }
  function fail3(message) {
    return { ok: false, message };
  }

  // src/features/register/account-input.ts
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  function parseAccountInput(rawInput) {
    const raw = rawInput.trim();
    if (!raw) {
      return invalid("empty", "\u8BF7\u8F93\u5165\u90AE\u7BB1\u6216 Outlook \u8D26\u53F7\u884C");
    }
    const firstLine = raw.split(/\r?\n/).map((line) => line.trim()).find(Boolean) || "";
    if (firstLine.includes("----")) {
      const parts = firstLine.split("----").map((item) => item.trim());
      const email = parts[0] || "";
      if (!EMAIL_RE.test(email)) {
        return invalid("invalid", "Outlook \u884C\u91CC\u7684\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E");
      }
      if (parts.length < 4 || !parts[2] || !parts[3]) {
        return invalid("invalid", "Outlook \u884C\u9700\u8981 email----password----client_id----refresh_token");
      }
      return {
        ok: true,
        mode: "outlook-line",
        email,
        accountLine: firstLine,
        message: "Outlook API \u81EA\u52A8\u9A8C\u8BC1\u7801"
      };
    }
    if (!EMAIL_RE.test(firstLine)) {
      return invalid("invalid", "\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E");
    }
    return {
      ok: true,
      mode: "email",
      email: firstLine,
      accountLine: "",
      message: "\u5355\u90AE\u7BB1\u6A21\u5F0F\uFF0C\u9A8C\u8BC1\u7801\u624B\u52A8\u8F93\u5165"
    };
  }
  function invalid(mode, message) {
    return {
      ok: false,
      mode,
      email: "",
      accountLine: "",
      message
    };
  }

  // src/features/link-extractor/checkout.ts
  var ACCESS_TOKEN_RE = /"accessToken"\s*:\s*"([^"]+)"/;
  var ACCESS_TOKEN_LOOSE_RE = /"accessToken"\s*:\s*"?([A-Za-z0-9_.-]+)/;
  var JWT_RE = /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/;
  var DEFAULT_CHECKOUT_OPTIONS = {
    planName: "chatgptplusplan",
    uiMode: "hosted",
    region: "US",
    workspaceName: "MyTeam",
    seatQuantity: 5
  };
  function extractAccessToken(raw) {
    const text = String(raw || "").trim();
    if (!text) {
      throw new Error("\u8BF7\u8F93\u5165\u5305\u542B accessToken \u7684 JSON \u6216\u5B57\u7B26\u4E32");
    }
    const token = extractFromJson(text) || extractFromAccessTokenField(text) || extractFirstJwt(text);
    if (!token) {
      throw new Error("\u672A\u627E\u5230 accessToken");
    }
    if (token.split(".").length !== 3) {
      throw new Error("accessToken \u683C\u5F0F\u4E0D\u6B63\u786E");
    }
    return token;
  }
  function normalizeCheckoutOptions(value) {
    const source = isRecord(value) ? value : {};
    return {
      planName: normalizePlanName(source.planName),
      uiMode: normalizeUiMode(source.uiMode),
      region: normalizeRegion(source.region || source.country),
      workspaceName: String(source.workspaceName || source.workspace_name || DEFAULT_CHECKOUT_OPTIONS.workspaceName).trim() || DEFAULT_CHECKOUT_OPTIONS.workspaceName,
      seatQuantity: normalizeSeatQuantity(source.seatQuantity)
    };
  }
  function normalizePlanName(value) {
    return value === "chatgptplusplan" || value === "chatgptteamplan" ? value : DEFAULT_CHECKOUT_OPTIONS.planName;
  }
  function normalizeUiMode(value) {
    return value === "hosted" ? "hosted" : "custom";
  }
  function normalizeRegion(value) {
    const region = String(value || DEFAULT_CHECKOUT_OPTIONS.region).trim().toUpperCase();
    return region === "ID" || region === "DE" || region === "JP" || region === "US" ? region : DEFAULT_CHECKOUT_OPTIONS.region;
  }
  function normalizeSeatQuantity(value) {
    const quantity = Number(value || DEFAULT_CHECKOUT_OPTIONS.seatQuantity);
    if (!Number.isInteger(quantity) || quantity < 1) {
      throw new Error("team_plan_data.seat_quantity \u5FC5\u987B\u662F\u5927\u4E8E 0 \u7684\u6574\u6570");
    }
    return quantity;
  }
  function extractFromJson(text) {
    try {
      return findAccessToken(JSON.parse(text));
    } catch {
      return "";
    }
  }
  function findAccessToken(value, depth = 0) {
    if (!isRecord(value) || depth > 4) {
      return "";
    }
    if (typeof value.accessToken === "string") {
      return value.accessToken.trim();
    }
    for (const item of Object.values(value)) {
      const found = findAccessToken(item, depth + 1);
      if (found) {
        return found;
      }
    }
    return "";
  }
  function extractFromAccessTokenField(text) {
    const quoted = ACCESS_TOKEN_RE.exec(text);
    if (quoted?.[1]) {
      return quoted[1].trim();
    }
    const loose = ACCESS_TOKEN_LOOSE_RE.exec(text);
    if (!loose?.[1]) {
      return "";
    }
    const value = loose[1].trim().replace(/[",}\]\s]+$/, "");
    const jwt = JWT_RE.exec(value);
    return jwt?.[0]?.trim() || value;
  }
  function extractFirstJwt(text) {
    return JWT_RE.exec(text)?.[0]?.trim() || "";
  }
  function isRecord(value) {
    return Boolean(value && typeof value === "object");
  }

  // src/app/state.ts
  var DEFAULT_API_BASE = "http://127.0.0.1:8787";
  var STORAGE_KEY = "opx.registerAssist.state";
  var DEFAULT_REGISTER_STATE = {
    rawInput: "",
    email: "",
    accountLine: "",
    inputMode: "empty",
    autoOtp: false,
    apiBase: DEFAULT_API_BASE,
    otpRequestedAt: 0,
    updatedAt: 0
  };
  var DEFAULT_LINK_STATE = {
    checkoutOptions: DEFAULT_CHECKOUT_OPTIONS,
    updatedAt: 0
  };
  var DEFAULT_SMS_RELAY_STATE = {
    rawInput: "",
    history: [],
    updatedAt: 0
  };
  async function loadAppState() {
    const data = await browser.storage.local.get(STORAGE_KEY);
    return normalizeAppState(data[STORAGE_KEY]);
  }
  async function saveActiveTab(activeTab) {
    const current = await loadAppState();
    const next = normalizeAppState({ ...current, activeTab });
    await browser.storage.local.set({ [STORAGE_KEY]: next });
    return next;
  }
  async function savePanelCollapsed(panelCollapsed) {
    const current = await loadAppState();
    const next = normalizeAppState({ ...current, panelCollapsed });
    await browser.storage.local.set({ [STORAGE_KEY]: next });
    return next;
  }
  async function loadRegisterState() {
    return (await loadAppState()).register;
  }
  async function saveRegisterState(patch) {
    const current = await loadAppState();
    const register = normalizeRegisterState({
      ...current.register,
      ...patch,
      updatedAt: Date.now()
    });
    const next = normalizeAppState({ ...current, register });
    await browser.storage.local.set({ [STORAGE_KEY]: next });
    return next.register;
  }
  async function loadLinkExtractorState() {
    return (await loadAppState()).linkExtractor;
  }
  async function saveLinkExtractorState(patch) {
    const current = await loadAppState();
    const linkExtractor = normalizeLinkExtractorState({
      ...current.linkExtractor,
      ...patch,
      updatedAt: Date.now()
    });
    const next = normalizeAppState({ ...current, linkExtractor });
    await browser.storage.local.set({ [STORAGE_KEY]: next });
    return next.linkExtractor;
  }
  async function loadSmsRelayState() {
    return (await loadAppState()).smsRelay;
  }
  async function saveSmsRelayState(patch) {
    const current = await loadAppState();
    const smsRelay = normalizeSmsRelayState({
      ...current.smsRelay,
      ...patch,
      updatedAt: Date.now()
    });
    const next = normalizeAppState({ ...current, smsRelay });
    await browser.storage.local.set({ [STORAGE_KEY]: next });
    return next.smsRelay;
  }
  function isFeatureTab(value) {
    return value === "auto" || value === "register" || value === "link" || value === "address" || value === "sms";
  }
  function normalizeAppState(value) {
    const source = isRecord2(value) ? value : {};
    const registerSource = isRecord2(source.register) ? source.register : source;
    const linkSource = isRecord2(source.linkExtractor) ? source.linkExtractor : source;
    const smsRelaySource = isRecord2(source.smsRelay) ? source.smsRelay : DEFAULT_SMS_RELAY_STATE;
    return {
      activeTab: isFeatureTab(String(source.activeTab || "")) ? source.activeTab : "auto",
      panelCollapsed: Boolean(source.panelCollapsed),
      register: normalizeRegisterState(registerSource),
      linkExtractor: normalizeLinkExtractorState(linkSource),
      smsRelay: normalizeSmsRelayState(smsRelaySource)
    };
  }
  function normalizeRegisterState(value) {
    const source = isRecord2(value) ? value : {};
    return {
      rawInput: String(source.rawInput || DEFAULT_REGISTER_STATE.rawInput),
      email: String(source.email || DEFAULT_REGISTER_STATE.email),
      accountLine: String(source.accountLine || DEFAULT_REGISTER_STATE.accountLine),
      inputMode: normalizeInputMode(source.inputMode),
      autoOtp: Boolean(source.autoOtp),
      apiBase: String(source.apiBase || DEFAULT_REGISTER_STATE.apiBase),
      otpRequestedAt: Number(source.otpRequestedAt || DEFAULT_REGISTER_STATE.otpRequestedAt),
      updatedAt: Number(source.updatedAt || DEFAULT_REGISTER_STATE.updatedAt)
    };
  }
  function normalizeLinkExtractorState(value) {
    const source = isRecord2(value) ? value : {};
    return {
      checkoutOptions: normalizeCheckoutOptions(source.checkoutOptions || DEFAULT_LINK_STATE.checkoutOptions),
      updatedAt: Number(source.updatedAt || DEFAULT_LINK_STATE.updatedAt)
    };
  }
  function normalizeSmsRelayState(value) {
    const source = isRecord2(value) ? value : {};
    const history = Array.isArray(source.history) ? source.history.map(normalizeSmsCodeRecord).filter((item) => Boolean(item)) : DEFAULT_SMS_RELAY_STATE.history;
    return {
      rawInput: String(source.rawInput || DEFAULT_SMS_RELAY_STATE.rawInput),
      history,
      updatedAt: Number(source.updatedAt || DEFAULT_SMS_RELAY_STATE.updatedAt)
    };
  }
  function normalizeSmsCodeRecord(value) {
    if (!isRecord2(value)) {
      return null;
    }
    const phone = String(value.phone || "").trim();
    const code = String(value.code || "").trim();
    if (!phone || !code) {
      return null;
    }
    const receivedAt = Number(value.receivedAt || 0) || Date.now();
    return {
      id: String(value.id || `${phone}-${code}-${receivedAt}`),
      phone,
      code,
      message: String(value.message || "").trim(),
      receivedAt
    };
  }
  function normalizeInputMode(value) {
    return value === "email" || value === "outlook-line" || value === "invalid" ? value : "empty";
  }
  function isRecord2(value) {
    return Boolean(value && typeof value === "object");
  }

  // src/features/register/controller.ts
  var autoProfileStarted = false;
  function createRegisterController() {
    return {
      getPageState,
      loadState: loadRegisterState,
      saveInput: async (rawInput) => {
        const parsed = parseAccountInput(rawInput);
        return saveRegisterState({
          rawInput,
          email: parsed.email,
          accountLine: parsed.accountLine,
          inputMode: parsed.mode,
          autoOtp: parsed.mode === "outlook-line"
        });
      },
      fillEmailFromInput: async () => {
        const state = await loadRegisterState();
        const parsed = parseAccountInput(state.rawInput);
        if (!parsed.ok) {
          return fail4(parsed.message);
        }
        if (!isChatGptLoginPage()) {
          return fail4("\u5F53\u524D\u9875\u9762\u4E0D\u662F ChatGPT \u767B\u5F55\u9875");
        }
        await saveRegisterState({
          email: parsed.email,
          accountLine: parsed.accountLine,
          inputMode: parsed.mode,
          autoOtp: parsed.mode === "outlook-line",
          otpRequestedAt: Date.now()
        });
        return fillEmailAndContinue(parsed.email);
      },
      fillOtp: async (code) => {
        if (!isEmailVerificationPage()) {
          return fail4("\u5F53\u524D\u9875\u9762\u4E0D\u662F\u90AE\u7BB1\u9A8C\u8BC1\u7801\u9875");
        }
        return fillOtpAndContinue(code);
      },
      waitForOutlookOtp: async () => {
        if (!isEmailVerificationPage()) {
          return fail4("\u5F53\u524D\u9875\u9762\u4E0D\u662F\u90AE\u7BB1\u9A8C\u8BC1\u7801\u9875");
        }
        const state = await loadRegisterState();
        if (!state.accountLine) {
          return fail4("\u5F53\u524D\u8F93\u5165\u4E0D\u662F Outlook \u8D26\u53F7\u884C\uFF0C\u4E0D\u80FD\u81EA\u52A8\u63A5\u6536\u9A8C\u8BC1\u7801");
        }
        const response = await browser.runtime.sendMessage({
          type: "opx:wait-outlook-otp",
          accountLine: state.accountLine,
          apiBase: state.apiBase,
          since: state.otpRequestedAt || state.updatedAt || Date.now(),
          timeoutMs: 18e4,
          intervalMs: 5e3
        });
        if (!isActionResult(response)) {
          return fail4("Outlook API \u6CA1\u6709\u8FD4\u56DE\u6709\u6548\u7ED3\u679C");
        }
        if (!response.ok || !response.code) {
          return response;
        }
        const fillResult = await fillOtpAndContinue(response.code);
        return {
          ...fillResult,
          code: response.code,
          message: fillResult.ok ? `\u5DF2\u6536\u5230\u5E76\u63D0\u4EA4\u9A8C\u8BC1\u7801\uFF1A${response.code}` : fillResult.message
        };
      },
      fillProfileAndCreate: async () => {
        if (!isAboutYouPage()) {
          return fail4("\u5F53\u524D\u9875\u9762\u4E0D\u662F\u8D44\u6599\u586B\u5199\u9875");
        }
        return fillAboutYouAndCreate();
      },
      autoRunForCurrentPage: async () => {
        if (!isAboutYouPage() || autoProfileStarted) {
          return;
        }
        autoProfileStarted = true;
        await waitForPageReady();
        await fillAboutYouAndCreate();
      }
    };
  }
  function getPageState() {
    if (isChatGptLoginPage()) {
      return {
        kind: "login",
        label: "ChatGPT \u767B\u5F55\u9875",
        canFillEmail: true,
        canFillOtp: false,
        canFillProfile: false
      };
    }
    if (isEmailVerificationPage()) {
      return {
        kind: "email-verification",
        label: "\u90AE\u7BB1\u9A8C\u8BC1\u7801\u9875",
        canFillEmail: false,
        canFillOtp: true,
        canFillProfile: false
      };
    }
    if (isAboutYouPage()) {
      return {
        kind: "about-you",
        label: "\u8D44\u6599\u586B\u5199\u9875",
        canFillEmail: false,
        canFillOtp: false,
        canFillProfile: true
      };
    }
    return {
      kind: "unknown",
      label: "\u672A\u8BC6\u522B\u9875\u9762",
      canFillEmail: false,
      canFillOtp: false,
      canFillProfile: false
    };
  }
  function fail4(message) {
    return { ok: false, message };
  }
  function isActionResult(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }
  function waitForPageReady() {
    return new Promise((resolve) => window.setTimeout(resolve, 800));
  }

  // src/features/address-autofill/panel.ts
  init_state();

  // src/features/address-autofill/address-source.ts
  var ADDRESS_COUNTRY_OPTIONS = [
    { code: "US", label: "\u7F8E\u56FD", path: "/" },
    { code: "CA", label: "\u52A0\u62FF\u5927", path: "/ca-address" },
    { code: "AU", label: "\u6FB3\u5927\u5229\u4E9A", path: "/au-address" },
    { code: "JP", label: "\u65E5\u672C", path: "/jp-address" },
    { code: "TW", label: "\u53F0\u6E7E", path: "/tw-address" },
    { code: "KR", label: "\u97E9\u56FD", path: "/kr-address" },
    { code: "HK", label: "\u9999\u6E2F", path: "/hk-address" },
    { code: "GB", label: "\u82F1\u56FD", path: "/uk-address" },
    { code: "DE", label: "\u5FB7\u56FD", path: "/de-address" },
    { code: "SG", label: "\u65B0\u52A0\u5761", path: "/sg-address" },
    { code: "FR", label: "\u6CD5\u56FD", path: "/fr-address" },
    { code: "IT", label: "\u610F\u5927\u5229", path: "/it-address" },
    { code: "ES", label: "\u897F\u73ED\u7259", path: "/es-address" },
    { code: "NL", label: "\u8377\u5170", path: "/nl-address" },
    { code: "MY", label: "\u9A6C\u6765\u897F\u4E9A", path: "/my-address" },
    { code: "RU", label: "\u4FC4\u7F57\u65AF", path: "/ru-address" },
    { code: "CN", label: "\u4E2D\u56FD", path: "/cn-address" },
    { code: "TH", label: "\u6CF0\u56FD", path: "/th-address" },
    { code: "PH", label: "\u83F2\u5F8B\u5BBE", path: "/ph-address" },
    { code: "AR", label: "\u963F\u6839\u5EF7", path: "/ar-address" },
    { code: "TR", label: "\u571F\u8033\u5176", path: "/tr-address" },
    { code: "VN", label: "\u8D8A\u5357", path: "/vn-address" }
  ];

  // src/features/address-autofill/panel.ts
  init_pay_openai_autofill();

  // src/features/address-autofill/paypal-autofill.ts
  init_state();
  var LOG_PREFIX2 = "[OPX PayPal Autofill]";
  var PAYPAL_ADDRESS_SESSION_KEY = "opx.paypal.autofill.address";
  var PAYPAL_PENDING_MANUAL_KEY = "opx.paypal.autofill.pendingManual";
  var PAYPAL_FILLED_ATTR = "data-opx-paypal-filled";
  var PAYPAL_RANDOM_BUTTON_ID = "opx-paypal-random-fill";
  var MAX_AUTOFILL_ATTEMPTS_PER_PAGE = 3;
  var PAYPAL_COUNTRY_LABELS = {
    AR: "Argentina",
    AU: "Australia",
    CA: "Canada",
    CN: "China",
    DE: "Germany",
    ES: "Spain",
    FR: "France",
    GB: "United Kingdom",
    HK: "Hong Kong",
    IT: "Italy",
    JP: "Japan",
    KR: "South Korea",
    MY: "Malaysia",
    NL: "Netherlands",
    PH: "Philippines",
    RU: "Russia",
    SG: "Singapore",
    TH: "Thailand",
    TR: "Turkey",
    TW: "Taiwan",
    US: "United States",
    VN: "Vietnam"
  };
  var initialized2 = false;
  var running2 = false;
  var scheduledTimer2 = null;
  var pageAddress2 = null;
  var observer = null;
  var attemptKey = "";
  var attemptCount = 0;
  var manualFillKey = "";
  function initPaypalAutofill() {
    if (initialized2 || !isPaypalSignupPage()) {
      return;
    }
    initialized2 = true;
    installRandomFillButton();
    installStorageListener2();
    installObserver2();
    if (consumePendingManualFill()) {
      scheduleManualSessionAutofill(900);
    } else {
      scheduleAutofill2(800);
    }
  }
  async function fillPaypalAddressNow(address, force = false, allowRetry = true) {
    if (!isPaypalSignupPage()) {
      return { ok: false, filled: 0, message: "\u5F53\u524D\u4E0D\u662F PayPal \u6CE8\u518C\u652F\u4ED8\u9875", countryChanged: false };
    }
    const settings = await loadAddressAutofillSettings();
    const targetAddress = address || await getPageAddress2(settings);
    if (!targetAddress) {
      return { ok: false, filled: 0, message: "\u6CA1\u6709\u53EF\u7528\u5730\u5740\u8D44\u6599", countryChanged: false };
    }
    rememberSessionAddress(targetAddress);
    if (force && !allowRetry) {
      cancelScheduledAutofill();
    }
    if (force) {
      resetFilledMarks();
      resetAttempts();
    }
    const result = await fillPaypalSignupFields(targetAddress, allowRetry);
    noteAttempt(targetAddress, result.countryChanged, allowRetry);
    if (force && !allowRetry) {
      manualFillKey = pageAttemptKey(targetAddress);
      if (result.countryChanged) {
        markPendingManualFill();
        scheduleManualSessionAutofill(1600);
      } else {
        clearPendingManualFill();
      }
    }
    return {
      ok: result.filled > 0 || result.countryChanged,
      filled: result.filled,
      countryChanged: result.countryChanged,
      message: result.countryChanged ? `\u5DF2\u9009\u62E9 PayPal \u56FD\u5BB6\uFF1A${targetAddress.countryCode}\uFF0C\u7B49\u5F85\u9875\u9762\u91CD\u65B0\u52A0\u8F7D` : result.filled > 0 ? `\u5DF2\u586B\u5199 PayPal ${result.filled} \u9879` : "\u672A\u627E\u5230\u53EF\u586B\u5199\u7684 PayPal \u5B57\u6BB5"
    };
  }
  async function runAutofill2() {
    if (running2) {
      return;
    }
    if (manualFillKey && attemptKey === manualFillKey) {
      return;
    }
    running2 = true;
    try {
      const settings = await loadAddressAutofillSettings();
      if (!settings.payPalSignupEnabled) {
        console.info(`${LOG_PREFIX2} disabled`);
        return;
      }
      const result = await fillPaypalAddressNow();
      console.info(`${LOG_PREFIX2} ${result.message}`);
      if (!result.ok || reachedAttemptLimit()) {
        observer?.disconnect();
        observer = null;
      }
    } catch (error) {
      console.warn(`${LOG_PREFIX2} failed`, error);
    } finally {
      running2 = false;
    }
  }
  async function getPageAddress2(settings) {
    if (pageAddress2 && addressMatchesSettings(pageAddress2, settings)) {
      return pageAddress2;
    }
    const sessionAddress = loadSessionAddress();
    if (sessionAddress && addressMatchesSettings(sessionAddress, settings)) {
      pageAddress2 = sessionAddress;
      return pageAddress2;
    }
    const response = await browser.runtime.sendMessage({
      type: "opx:fetch-random-address",
      countryCode: settings.countryCode,
      city: settings.city
    });
    if (!isRandomAddressResponse2(response) || !response.ok || !response.address) {
      console.warn(`${LOG_PREFIX2} address fetch failed`, response);
      return null;
    }
    pageAddress2 = response.address;
    rememberSessionAddress(response.address);
    await saveAddressAutofillSettings({ lastAddress: response.address });
    return pageAddress2;
  }
  async function fillPaypalSignupFields(address, allowRetry) {
    let filled = 0;
    const countryChanged = selectCountry(address);
    if (countryChanged) {
      if (allowRetry) {
        scheduleAutofill2(1500);
      }
      return { filled: 1, countryChanged: true };
    }
    const email = await resolveEmail(address);
    const name = splitName(address.fullName);
    const expiry = parseExpiry(address.creditCard.expires);
    filled += fillText(PAYPAL_FIELDS.email, email, true);
    filled += fillPasswordField(email);
    renderPasswordEmailNote(email);
    filled += fillText(PAYPAL_FIELDS.phone, address.phone, true);
    filled += fillText(PAYPAL_FIELDS.cardNumber, address.creditCard.number, true);
    filled += fillText(PAYPAL_FIELDS.expiry, expiry.short, true);
    filled += fillText(PAYPAL_FIELDS.csc, address.creditCard.cvv, true);
    filled += fillText(PAYPAL_FIELDS.fullName, address.fullName, true);
    filled += fillText(PAYPAL_FIELDS.firstName, name.first, true);
    filled += fillText(PAYPAL_FIELDS.lastName, name.last, true);
    filled += fillText(PAYPAL_FIELDS.address1, address.line1, true);
    filled += fillText(PAYPAL_FIELDS.address2, address.line2, true);
    filled += fillText(PAYPAL_FIELDS.city, address.city, true);
    filled += fillSelectOrInput2(PAYPAL_FIELDS.state, address.state, [address.stateFull, address.state]);
    filled += fillText(PAYPAL_FIELDS.postalCode, address.postalCode, true);
    filled += fillBillingAddressGroup(address, name);
    filled += fillSelectOrInput2(PAYPAL_FIELDS.expiryMonth, expiry.month, [expiry.month]);
    filled += fillSelectOrInput2(PAYPAL_FIELDS.expiryYear, expiry.year4, [expiry.year4, expiry.year2]);
    return { filled, countryChanged: false };
  }
  function selectCountry(address) {
    const select = findSelect(PAYPAL_FIELDS.country);
    if (!select || !isVisible3(select)) {
      return false;
    }
    return setSelectOption2(select, address.countryCode, [
      address.countryCode,
      PAYPAL_COUNTRY_LABELS[address.countryCode] || "",
      address.countryLabel
    ]);
  }
  async function resolveEmail(address) {
    const register = await loadRegisterState();
    const parsed = parseAccountInput(register.rawInput);
    if (parsed.ok && isEmail(parsed.email)) {
      return parsed.email;
    }
    if (isEmail(register.email)) {
      return register.email;
    }
    if (isEmail(address.identity.temporaryMail)) {
      return address.identity.temporaryMail;
    }
    return createOutlookEmail(address);
  }
  function fillText(selectors, value, overwrite) {
    if (!value) {
      return 0;
    }
    const input = findTextControl(selectors);
    if (!input || !isVisible3(input)) {
      return 0;
    }
    return fillTextControl(input, value, overwrite);
  }
  function fillTextControl(input, value, overwrite) {
    if (!value || !isVisible3(input)) {
      return 0;
    }
    const currentValue = input.value.trim();
    if (input.getAttribute(PAYPAL_FILLED_ATTR) === "1" || equivalentValue(currentValue, value)) {
      input.setAttribute(PAYPAL_FILLED_ATTR, "1");
      return 0;
    }
    if (!overwrite && currentValue) {
      return 0;
    }
    setNativeValue5(input, value);
    input.setAttribute(PAYPAL_FILLED_ATTR, "1");
    return 1;
  }
  function fillPasswordField(value) {
    if (!value) {
      return 0;
    }
    const input = document.querySelector("input#password") || findTextControl(PAYPAL_FIELDS.password);
    if (!input || !isVisible3(input)) {
      return 0;
    }
    const currentValue = input.value.trim();
    if (equivalentValue(currentValue, value)) {
      return 0;
    }
    setNativeValue5(input, value);
    return 1;
  }
  function renderPasswordEmailNote(email) {
    const anchor = findPasswordDisclaimerAnchor();
    if (!anchor) {
      return;
    }
    fillPasswordField(email);
    const noteId = "opx-paypal-password-note";
    const text = `\u5F53\u524D\u5BC6\u7801\u548C\u90AE\u7BB1\u4E00\u81F4\uFF08${email}\uFF09`;
    let note = document.getElementById(noteId);
    if (!note) {
      note = document.createElement("div");
      note.id = noteId;
      Object.assign(note.style, {
        color: "#93e4bd",
        fontSize: "12px",
        lineHeight: "18px",
        margin: "4px 0 10px",
        padding: "6px 10px",
        border: "1px solid rgba(47, 209, 124, 0.36)",
        borderRadius: "6px",
        background: "rgba(15, 23, 42, 0.82)",
        display: "block"
      });
    }
    const parent = anchor.parentElement;
    if (!parent) {
      return;
    }
    parent.insertBefore(note, anchor);
    note.textContent = text;
  }
  function fillSelectOrInput2(selectors, preferredValue, preferredLabels) {
    if (!preferredValue && !preferredLabels.some(Boolean)) {
      return 0;
    }
    const select = findSelect(selectors);
    if (select && isVisible3(select)) {
      return setSelectOption2(select, preferredValue, preferredLabels) ? 1 : 0;
    }
    return fillText(selectors, preferredValue || preferredLabels.find(Boolean) || "", true);
  }
  function fillBillingAddressGroup(address, name) {
    const group = findBillingAddressGroup();
    if (!group) {
      return 0;
    }
    const fallbackControls = Array.from(group.querySelectorAll("input, textarea, select")).filter(
      (control) => (isTextControl2(control) || isSelectControl2(control)) && isVisible3(control) && !isIgnoredInput(control) && !isLikelyEmailPhoneOrCard(control)
    );
    let filled = 0;
    filled += fillGroupText(group, ["first name", "given name"], name.first, fallbackControls[0]);
    filled += fillGroupText(group, ["last name", "family name", "surname"], name.last, fallbackControls[1]);
    filled += fillGroupText(group, ["street address", "address line 1", "address 1"], address.line1, fallbackControls[2]);
    filled += fillGroupText(group, ["apt", "ste", "bldg", "address line 2", "address 2"], address.line2, fallbackControls[3]);
    filled += fillGroupText(group, ["city", "locality"], address.city, fallbackControls[4]);
    filled += fillGroupSelectOrInput(group, ["state", "province", "region"], address.state, [address.stateFull, address.state], fallbackControls[5]);
    filled += fillGroupText(group, ["zip", "postal code", "postcode"], address.postalCode, fallbackControls[6]);
    return filled;
  }
  function fillGroupText(group, needles, value, fallback) {
    const fallbackText = fallback && isTextControl2(fallback) ? fallback : null;
    const control = findControlInGroup(group, needles, isTextControl2) || fallbackText;
    return control ? fillTextControl(control, value, true) : 0;
  }
  function fillGroupSelectOrInput(group, needles, preferredValue, preferredLabels, fallback) {
    const fallbackSelect = fallback && isSelectControl2(fallback) ? fallback : null;
    const select = findControlInGroup(group, needles, isSelectControl2) || fallbackSelect;
    if (select) {
      return setSelectOption2(select, preferredValue, preferredLabels) ? 1 : 0;
    }
    const fallbackText = fallback && isTextControl2(fallback) ? fallback : null;
    const input = findControlInGroup(group, needles, isTextControl2) || fallbackText;
    return input ? fillTextControl(input, preferredValue || preferredLabels.find(Boolean) || "", true) : 0;
  }
  function findBillingAddressGroup() {
    return Array.from(document.querySelectorAll('fieldset, [role="group"], section, form > div')).find((element) => {
      const text = normalizedText2(element.textContent || "");
      return text.includes("billing address") && (text.includes("street address") || text.includes("address")) && (text.includes("first name") || text.includes("last name"));
    }) || null;
  }
  function findControlInGroup(group, needles, guard) {
    const normalizedNeedles = needles.map(normalizedText2).filter(Boolean);
    const controls = Array.from(group.querySelectorAll("input, textarea, select")).filter(guard);
    const candidates = controls.map((control) => ({
      control,
      score: scoreControlMatch(control, normalizedNeedles)
    })).filter((item) => item.score > 0 && isVisible3(item.control) && !isIgnoredInput(item.control)).sort((a, b) => b.score - a.score);
    return candidates[0]?.control || null;
  }
  function findTextControl(selectors) {
    for (const selector of selectors) {
      const element = querySelectorCandidate(selector);
      if (isTextControl2(element)) {
        return element;
      }
    }
    return findControlByNeedles(selectors, isTextControl2);
  }
  function findSelect(selectors) {
    for (const selector of selectors) {
      const element = querySelectorCandidate(selector);
      if (isSelectControl2(element)) {
        return element;
      }
    }
    return findControlByNeedles(selectors, isSelectControl2);
  }
  function querySelectorCandidate(selector) {
    if (!isCssSelectorCandidate(selector)) {
      return null;
    }
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  }
  function isCssSelectorCandidate(value) {
    const selector = value.trim();
    return /^[.#[]/.test(selector) || /^(input|select|textarea|button|label|form|fieldset|section|div)([#.[\s:]|$)/i.test(selector);
  }
  function findControlByNeedles(needles, guard) {
    const normalizedNeedles = needles.filter((item) => !item.includes("[") && !item.includes("#") && !item.includes(".")).map(normalizedText2).filter(Boolean);
    if (!normalizedNeedles.length) {
      return null;
    }
    const controls = Array.from(document.querySelectorAll("input, textarea, select")).filter(guard);
    const candidates = controls.map((control) => ({
      control,
      score: scoreControlMatch(control, normalizedNeedles)
    })).filter((item) => item.score > 0 && isVisible3(item.control) && !isIgnoredInput(item.control)).sort((a, b) => b.score - a.score);
    return candidates[0]?.control || null;
  }
  function scoreControlMatch(control, normalizedNeedles) {
    if (!isVisible3(control) || isIgnoredInput(control)) {
      return 0;
    }
    const directText = normalizedText2([
      control.id,
      control.name,
      "placeholder" in control ? control.placeholder : "",
      "autocomplete" in control ? control.autocomplete : "",
      control.getAttribute("aria-label"),
      labelledText(control),
      closestLabelText(control)
    ].join(" "));
    const nearbyText = normalizedText2([
      control.previousElementSibling?.textContent,
      control.nextElementSibling?.textContent,
      compactContainerText(control)
    ].join(" "));
    const broadText = normalizedText2(control.parentElement?.textContent || "");
    if (normalizedNeedles.some((needle) => directText.includes(needle))) {
      return 30;
    }
    if (normalizedNeedles.some((needle) => nearbyText.includes(needle))) {
      return 20;
    }
    if (broadText.length <= 120 && normalizedNeedles.some((needle) => broadText.includes(needle))) {
      return 5;
    }
    return 0;
  }
  function labelledText(control) {
    const labels = [];
    const labelledBy = control.getAttribute("aria-labelledby");
    if (labelledBy) {
      for (const id2 of labelledBy.split(/\s+/)) {
        const element = document.getElementById(id2);
        if (element?.textContent) {
          labels.push(element.textContent);
        }
      }
    }
    const id = control.id;
    if (id) {
      for (const label of Array.from(document.querySelectorAll(`label[for="${cssEscape2(id)}"]`))) {
        labels.push(label.textContent || "");
      }
    }
    return labels.join(" ");
  }
  function closestLabelText(control) {
    return control.closest("label")?.textContent || "";
  }
  function compactContainerText(control) {
    const container = control.closest("div, label, section");
    const text = container?.textContent || "";
    return text.length <= 160 ? text : "";
  }
  function resetFilledMarks() {
    for (const element of Array.from(document.querySelectorAll(`[${PAYPAL_FILLED_ATTR}]`))) {
      element.removeAttribute(PAYPAL_FILLED_ATTR);
    }
  }
  function noteAttempt(address, countryChanged, allowRetry) {
    const key = pageAttemptKey(address);
    if (attemptKey !== key) {
      attemptKey = key;
      attemptCount = 0;
    }
    attemptCount += 1;
    if (allowRetry && !countryChanged && attemptCount < MAX_AUTOFILL_ATTEMPTS_PER_PAGE) {
      scheduleAutofill2(1200);
    }
  }
  function reachedAttemptLimit() {
    return Boolean(attemptKey && attemptCount >= MAX_AUTOFILL_ATTEMPTS_PER_PAGE);
  }
  function resetAttempts() {
    attemptKey = "";
    attemptCount = 0;
    manualFillKey = "";
  }
  function pageAttemptKey(address) {
    return [
      location.origin,
      location.pathname,
      new URLSearchParams(location.search).get("token") || "",
      address.id
    ].join("|");
  }
  function equivalentValue(currentValue, targetValue) {
    if (!currentValue || !targetValue) {
      return false;
    }
    if (currentValue === targetValue) {
      return true;
    }
    return comparableValue(currentValue) === comparableValue(targetValue);
  }
  function comparableValue(value) {
    return value.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function cssEscape2(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
      return CSS.escape(value);
    }
    return value.replace(/"/g, '\\"');
  }
  function setSelectOption2(select, preferredValue, preferredLabels) {
    const normalizedPreferred = normalizedText2(preferredValue);
    const labelNeedles = preferredLabels.map(normalizedText2).filter(Boolean);
    const options = Array.from(select.options).filter((option2) => !option2.disabled && option2.value);
    const option = options.find((item) => normalizedText2(item.value) === normalizedPreferred) || options.find((item) => labelNeedles.some((needle) => normalizedText2(`${item.text} ${item.value}`).includes(needle)));
    if (!option || select.value === option.value) {
      return false;
    }
    select.value = option.value;
    emitChange2(select);
    return true;
  }
  function setNativeValue5(input, value) {
    input.focus();
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor?.set) {
      descriptor.set.call(input, value);
    } else {
      input.value = value;
    }
    emitChange2(input);
  }
  function emitChange2(element) {
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function installObserver2() {
    observer?.disconnect();
    observer = new MutationObserver(() => {
      installRandomFillButton();
      if (manualFillKey && attemptKey === manualFillKey) {
        return;
      }
      if (!reachedAttemptLimit()) {
        scheduleAutofill2(350);
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  function installRandomFillButton() {
    if (!isPaypalSignupPage() || document.getElementById(PAYPAL_RANDOM_BUTTON_ID)) {
      return;
    }
    const cardBrandAnchor = findPayPalHintAnchor();
    const cardFieldAnchor = findCardFieldAnchor();
    const widget = createRandomFillWidget();
    if (cardBrandAnchor?.parentElement) {
      widget.style.marginTop = "8px";
      widget.style.marginBottom = "12px";
      cardBrandAnchor.parentElement.insertBefore(widget, cardBrandAnchor.nextSibling);
      return;
    }
    if (cardFieldAnchor?.parentElement) {
      cardFieldAnchor.parentElement.insertBefore(widget, cardFieldAnchor);
    }
  }
  function createRandomFillWidget() {
    const wrapper = document.createElement("div");
    wrapper.id = PAYPAL_RANDOM_BUTTON_ID;
    wrapper.setAttribute("data-opx-paypal-random-fill", "1");
    Object.assign(wrapper.style, {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: "8px",
      margin: "10px 0 14px",
      minHeight: "32px"
    });
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "\u968F\u673A\u8F93\u5165";
    Object.assign(button.style, {
      appearance: "none",
      border: "0",
      borderRadius: "6px",
      background: "#10b981",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "13px",
      fontWeight: "700",
      lineHeight: "1",
      minHeight: "32px",
      padding: "0 14px",
      whiteSpace: "nowrap"
    });
    const status = document.createElement("span");
    Object.assign(status.style, {
      color: "#64748b",
      fontSize: "12px",
      lineHeight: "16px",
      minWidth: "0"
    });
    button.addEventListener("click", () => {
      void fetchFreshAddressAndFill(button, status);
    });
    wrapper.append(button, status);
    return wrapper;
  }
  async function fetchFreshAddressAndFill(button, status) {
    button.disabled = true;
    button.textContent = "\u83B7\u53D6\u4E2D...";
    Object.assign(button.style, {
      cursor: "wait",
      opacity: "0.72"
    });
    status.textContent = "\u6B63\u5728\u83B7\u53D6\u65B0\u8D44\u6599";
    try {
      const settings = await loadAddressAutofillSettings();
      const response = await browser.runtime.sendMessage({
        type: "opx:fetch-random-address",
        countryCode: settings.countryCode,
        city: settings.city
      });
      if (!isRandomAddressResponse2(response) || !response.ok || !response.address) {
        status.textContent = response?.message || "\u83B7\u53D6\u5931\u8D25";
        return;
      }
      pageAddress2 = response.address;
      rememberSessionAddress(response.address);
      await saveAddressAutofillSettings({ lastAddress: response.address });
      const result = await fillPaypalAddressNow(response.address, true, false);
      status.textContent = result.countryChanged ? "\u5DF2\u5207\u6362\u56FD\u5BB6\uFF0C\u5237\u65B0\u540E\u7EE7\u7EED\u586B\u5199" : result.ok ? `\u5DF2\u968F\u673A\u8F93\u5165 ${result.filled} \u9879` : result.message;
    } catch (error) {
      status.textContent = `\u5931\u8D25\uFF1A${errorMessage(error)}`;
    } finally {
      button.disabled = false;
      button.textContent = "\u968F\u673A\u8F93\u5165";
      Object.assign(button.style, {
        cursor: "pointer",
        opacity: "1"
      });
    }
  }
  function findCardFieldAnchor() {
    const cardInput = findTextControl(PAYPAL_FIELDS.cardNumber);
    return cardInput?.closest("div, label, section") || cardInput;
  }
  function findPayPalHintAnchor() {
    const exact = document.querySelector("div.css-ltr-cssveg > form > section.css-ltr-4jicje:nth-of-type(1) > p.css-ltr-6pd54h.css-ltr-16jt5za-text_body");
    if (exact && isVisible3(exact)) {
      return exact;
    }
    const candidates = Array.from(document.querySelectorAll("form section p, form p")).filter((element) => isVisible3(element)).map((element) => ({
      element,
      score: scoreHintAnchor(element)
    })).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);
    return candidates[0]?.element || null;
  }
  function findPasswordDisclaimerAnchor() {
    const exact = document.querySelector("section.css-ltr-h5yxuz:nth-of-type(3) > div.css-ltr-h5yxuz:nth-of-type(2) > div.css-ltr-1lvkl1r:nth-of-type(2) > p.css-ltr-abbmt5:nth-of-type(1)");
    if (exact && isVisible3(exact)) {
      return exact;
    }
    const passwordInput = document.querySelector("input#password") || findTextControl(PAYPAL_FIELDS.password);
    const passwordSection = passwordInput?.closest("section");
    const scope = passwordSection || document;
    const candidates = Array.from(scope.querySelectorAll("p")).filter((element) => isVisible3(element)).map((element) => ({
      element,
      score: scorePasswordDisclaimerAnchor(element, passwordInput)
    })).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);
    return candidates[0]?.element || null;
  }
  function scorePasswordDisclaimerAnchor(element, passwordInput) {
    const text = normalizedText2(element.textContent || "");
    if (!text) {
      return 0;
    }
    const keywords = [
      "by creating an account",
      "confirm you\u2019re at least 18 years old",
      "confirm you're at least 18 years old",
      "agree to the",
      "privacy statement"
    ];
    const hasDisclaimerText = keywords.some((keyword) => text.includes(normalizedText2(keyword)));
    if (!hasDisclaimerText) {
      return 0;
    }
    const afterPassword = passwordInput ? Boolean(passwordInput.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING) : false;
    return afterPassword ? 20 : 10;
  }
  function scoreHintAnchor(element) {
    const text = normalizedText2(element.textContent || "");
    if (!text) {
      return 0;
    }
    const keywords = [
      "we don\u2019t share your financial details with the merchant",
      "we don't share your financial details with the merchant",
      "financial details",
      "merchant"
    ];
    return keywords.some((keyword) => text.includes(normalizedText2(keyword))) ? 10 : 0;
  }
  function installStorageListener2() {
    browser.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") {
        return;
      }
      if (Object.keys(changes).some((key) => key.includes("settings"))) {
        pageAddress2 = null;
        resetAttempts();
        scheduleAutofill2(100);
      }
    });
  }
  function scheduleAutofill2(delayMs) {
    cancelScheduledAutofill();
    scheduledTimer2 = window.setTimeout(() => {
      scheduledTimer2 = null;
      void runAutofill2();
    }, delayMs);
  }
  function cancelScheduledAutofill() {
    if (scheduledTimer2) {
      window.clearTimeout(scheduledTimer2);
      scheduledTimer2 = null;
    }
  }
  function scheduleManualSessionAutofill(delayMs) {
    window.setTimeout(() => {
      const address = loadSessionAddress();
      if (!address) {
        clearPendingManualFill();
        return;
      }
      void fillPaypalAddressNow(address, true, false);
    }, delayMs);
  }
  function loadSessionAddress() {
    try {
      const raw = sessionStorage.getItem(PAYPAL_ADDRESS_SESSION_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
  function markPendingManualFill() {
    try {
      sessionStorage.setItem(PAYPAL_PENDING_MANUAL_KEY, "1");
    } catch {
    }
  }
  function consumePendingManualFill() {
    try {
      const pending = sessionStorage.getItem(PAYPAL_PENDING_MANUAL_KEY) === "1";
      if (pending) {
        sessionStorage.removeItem(PAYPAL_PENDING_MANUAL_KEY);
      }
      return pending;
    } catch {
      return false;
    }
  }
  function clearPendingManualFill() {
    try {
      sessionStorage.removeItem(PAYPAL_PENDING_MANUAL_KEY);
    } catch {
    }
  }
  function rememberSessionAddress(address) {
    try {
      sessionStorage.setItem(PAYPAL_ADDRESS_SESSION_KEY, JSON.stringify(address));
    } catch {
    }
  }
  function addressMatchesSettings(address, settings) {
    const countryMatches = settings.countryCode === "RANDOM" || address.countryCode === settings.countryCode;
    const cityMatches = !settings.city.trim() || normalizedText2(address.city) === normalizedText2(settings.city);
    return countryMatches && cityMatches;
  }
  function parseExpiry(value) {
    const parts = value.match(/\d+/g) || [];
    const month = (parts[0] || "").padStart(2, "0").slice(0, 2);
    const rawYear = parts[1] || "";
    const year4 = rawYear.length === 2 ? `20${rawYear}` : rawYear.slice(0, 4);
    const year2 = year4.slice(-2);
    return {
      month,
      year2,
      year4,
      short: month && year2 ? `${month}/${year2}` : value
    };
  }
  function splitName(fullName) {
    const compact = fullName.replace(/[^a-zA-Z]/g, "");
    if (compact && !fullName.includes(" ")) {
      return { first: compact.slice(0, Math.max(1, Math.floor(compact.length / 2))), last: compact.slice(Math.max(1, Math.floor(compact.length / 2))) || compact };
    }
    const parts = fullName.split(/\s+/).map((item) => item.trim()).filter(Boolean);
    return {
      first: parts[0] || compact || "Alex",
      last: parts.slice(1).join(" ") || "Walker"
    };
  }
  function createOutlookEmail(address) {
    const base = (address.identity.username || address.fullName || "outlookuser").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 18) || "outlookuser";
    const suffix = (address.id + address.fetchedAt).replace(/\D/g, "").slice(-6) || String(Date.now()).slice(-6);
    return `${base}${suffix}@outlook.com`;
  }
  function isPaypalSignupPage() {
    return location.hostname.endsWith("paypal.com") && location.pathname.startsWith("/checkoutweb/signup");
  }
  function isIgnoredInput(input) {
    if (input instanceof HTMLSelectElement || input instanceof HTMLTextAreaElement) {
      return false;
    }
    return ["hidden", "radio", "checkbox", "submit", "button"].includes((input.type || "").toLowerCase());
  }
  function isLikelyEmailPhoneOrCard(input) {
    const text = normalizedText2([
      input.id,
      input.name,
      "placeholder" in input ? input.placeholder : "",
      "autocomplete" in input ? input.autocomplete : "",
      input.getAttribute("aria-label"),
      labelledText(input)
    ].join(" "));
    return [
      "email",
      "phone",
      "mobile",
      "card",
      "credit",
      "expiry",
      "expiration",
      "cvv",
      "csc",
      "security code"
    ].some((needle) => text.includes(needle));
  }
  function isVisible3(element) {
    const htmlElement = element;
    if ("disabled" in htmlElement && Boolean(htmlElement.disabled)) {
      return false;
    }
    const style = window.getComputedStyle(htmlElement);
    const rect = htmlElement.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function isTextControl2(element) {
    return Boolean(element && (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement));
  }
  function isSelectControl2(element) {
    return Boolean(element && element instanceof HTMLSelectElement);
  }
  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }
  function normalizedText2(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }
  function isRandomAddressResponse2(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }
  var PAYPAL_FIELDS = {
    country: [
      "select#country",
      'select[name="country"]',
      'select[name="country.x"]',
      "country",
      "country or region"
    ],
    email: [
      "input#email",
      'input[name="email"]',
      'input[type="email"]',
      'input[autocomplete="email"]',
      "email"
    ],
    password: [
      "input#password",
      'input[name="password"]',
      'input[type="password"]',
      'input[autocomplete="new-password"]',
      "create password",
      "password"
    ],
    phone: [
      "input#phone",
      "input#phoneNumber",
      'input[name="phone"]',
      'input[name="phoneNumber"]',
      'input[type="tel"]',
      "phone number",
      "mobile"
    ],
    cardNumber: [
      "input#cardNumber",
      "input#card_number",
      'input[name="cardNumber"]',
      'input[name="card_number"]',
      'input[autocomplete="cc-number"]',
      "card number",
      "credit card number"
    ],
    expiry: [
      "input#expiryDate",
      "input#expirationDate",
      "input#cardExpiry",
      'input[name="expiryDate"]',
      'input[name="expirationDate"]',
      'input[name="cardExpiry"]',
      'input[autocomplete="cc-exp"]',
      "expiration",
      "expiry",
      "\u6709\u6548\u671F\u9650"
    ],
    expiryMonth: [
      "select#expMonth",
      "select#expiryMonth",
      'select[name="expMonth"]',
      'select[name="expiryMonth"]',
      "expiration month",
      "expiry month"
    ],
    expiryYear: [
      "select#expYear",
      "select#expiryYear",
      'select[name="expYear"]',
      'select[name="expiryYear"]',
      "expiration year",
      "expiry year"
    ],
    csc: [
      "input#cvv",
      "input#csc",
      "input#securityCode",
      'input[name="cvv"]',
      'input[name="csc"]',
      'input[name="securityCode"]',
      'input[autocomplete="cc-csc"]',
      "csc",
      "cvv",
      "security code"
    ],
    fullName: [
      "input#cardholderName",
      "input#nameOnCard",
      "input#fullName",
      'input[name="cardholderName"]',
      'input[name="nameOnCard"]',
      'input[name="fullName"]',
      'input[autocomplete="cc-name"]',
      "name on card",
      "full name"
    ],
    firstName: [
      "input#firstName",
      "input#billingFirstName",
      'input[name="firstName"]',
      'input[name="billingFirstName"]',
      'input[autocomplete="given-name"]',
      "first name"
    ],
    lastName: [
      "input#lastName",
      "input#billingLastName",
      'input[name="lastName"]',
      'input[name="billingLastName"]',
      'input[autocomplete="family-name"]',
      "last name"
    ],
    address1: [
      "input#address1",
      "input#addressLine1",
      "input#billingAddressLine1",
      "input#billingLine1",
      'input[name="address1"]',
      'input[name="addressLine1"]',
      'input[name="billingLine1"]',
      'input[autocomplete="address-line1"]',
      "address line 1",
      "street address"
    ],
    address2: [
      "input#address2",
      "input#addressLine2",
      "input#billingAddressLine2",
      "input#billingLine2",
      'input[name="address2"]',
      'input[name="addressLine2"]',
      'input[name="billingLine2"]',
      'input[autocomplete="address-line2"]',
      "address line 2"
    ],
    city: [
      "input#city",
      "input#billingLocality",
      "input#billingCity",
      'input[name="city"]',
      'input[name="billingCity"]',
      'input[autocomplete="address-level2"]',
      "city"
    ],
    state: [
      "select#state",
      "input#state",
      "select#billingAdministrativeArea",
      "input#billingAdministrativeArea",
      "select#billingState",
      "input#billingState",
      'select[name="state"]',
      'input[name="state"]',
      'select[name="billingState"]',
      'input[name="billingState"]',
      'select[autocomplete="address-level1"]',
      'input[autocomplete="address-level1"]',
      "state",
      "province"
    ],
    postalCode: [
      "input#zip",
      "input#postalCode",
      "input#billingPostalCode",
      "input#billingZip",
      'input[name="zip"]',
      'input[name="postalCode"]',
      'input[name="billingPostalCode"]',
      'input[name="billingZip"]',
      'input[autocomplete="postal-code"]',
      "zip code",
      "postal code"
    ]
  };

  // src/features/address-autofill/panel.ts
  function createAddressPanel(container) {
    const summary = document.createElement("div");
    summary.className = "opx-summary";
    const countrySelect = createCountrySelect();
    const cityInput = document.createElement("input");
    cityInput.className = "opx-input";
    cityInput.type = "text";
    cityInput.placeholder = "\u57CE\u5E02\u7559\u7A7A\u5373\u968F\u673A\uFF0C\u4F8B\u5982 Tokyo / Berlin / New York";
    cityInput.autocomplete = "off";
    const formGrid = document.createElement("div");
    formGrid.className = "opx-grid";
    formGrid.append(
      createField("\u5730\u5740\u56FD\u5BB6", countrySelect),
      createField("\u6307\u5B9A\u57CE\u5E02", cityInput)
    );
    const buttonRow = document.createElement("div");
    buttonRow.className = "opx-button-row opx-address-actions";
    const fetchButton = createButton("\u83B7\u53D6\u5730\u5740");
    buttonRow.append(fetchButton);
    const currentList = document.createElement("div");
    currentList.className = "opx-copy-list";
    const status = document.createElement("div");
    status.className = "opx-status";
    container.append(
      summary,
      formGrid,
      buttonRow,
      currentList,
      status
    );
    countrySelect.addEventListener("change", () => void saveScopeSettings("\u56FD\u5BB6\u5DF2\u4FDD\u5B58"));
    cityInput.addEventListener("change", () => void saveScopeSettings("\u57CE\u5E02\u5DF2\u4FDD\u5B58"));
    fetchButton.addEventListener("click", () => void fetchAddress());
    const update = async () => {
      const settings = await loadAddressAutofillSettings();
      renderSettings(settings);
    };
    void update();
    return { update };
    async function saveScopeSettings(message) {
      const current = await loadAddressAutofillSettings();
      const countryCode = countrySelect.value;
      const city = cityInput.value.trim();
      const scopeChanged = current.countryCode !== countryCode || current.city.trim() !== city;
      const settings = await saveAddressAutofillSettings({
        countryCode,
        city,
        lastAddress: scopeChanged ? null : current.lastAddress
      });
      renderSettings(settings);
      setStatus(status, message, "ok");
    }
    async function fetchAddress() {
      fetchButton.disabled = true;
      setStatus(status, "\u6B63\u5728\u83B7\u53D6\u968F\u673A\u5730\u5740...", "pending");
      try {
        const response = await browser.runtime.sendMessage({
          type: "opx:fetch-random-address",
          countryCode: countrySelect.value,
          city: cityInput.value.trim()
        });
        if (!isRandomAddressResponse3(response) || !response.ok || !response.address) {
          setStatus(status, response?.message || "\u83B7\u53D6\u5730\u5740\u5931\u8D25", "error");
          return;
        }
        const next = await saveAddressAutofillSettings({
          countryCode: countrySelect.value,
          city: cityInput.value.trim(),
          lastAddress: response.address
        });
        renderSettings(next);
        const autofillMessage = await fillCurrentPaymentPage(response.address);
        setStatus(status, autofillMessage ? `${response.message}\uFF1B${autofillMessage}` : response.message, "ok");
      } catch (error) {
        setStatus(status, `\u83B7\u53D6\u5730\u5740\u5931\u8D25\uFF1A${errorMessage2(error)}`, "error");
      } finally {
        fetchButton.disabled = false;
      }
    }
    async function fillCurrentPaymentPage(address) {
      if (location.hostname === "pay.openai.com") {
        return (await fillPayOpenAiAddressNow(address)).message;
      }
      if (location.hostname.endsWith("paypal.com")) {
        return (await fillPaypalAddressNow(address, true, false)).message;
      }
      return "";
    }
    function renderSettings(settings) {
      countrySelect.value = settings.countryCode;
      cityInput.value = settings.city;
      renderSummary(settings);
      renderAddress(settings.lastAddress);
    }
    function renderSummary(settings) {
      const countryLabel = countrySelect.selectedOptions[0]?.textContent || settings.countryCode;
      const cityLabel = settings.city || "\u968F\u673A\u57CE\u5E02";
      summary.textContent = `${countryLabel} \xB7 ${cityLabel}`;
    }
    function renderAddress(address) {
      currentList.textContent = "";
      if (!address) {
        currentList.append(createEmpty("\u6682\u65E0\u5730\u5740\uFF0C\u70B9\u51FB\u201C\u83B7\u53D6\u5730\u5740\u201D\u3002"));
        return;
      }
      for (const section of addressSections(address)) {
        currentList.append(createSection(section));
      }
    }
    function createCopyRow(label, value) {
      const row = document.createElement("button");
      row.className = "opx-copy-row";
      row.type = "button";
      row.title = "\u70B9\u51FB\u590D\u5236";
      const labelElement = document.createElement("span");
      labelElement.className = "opx-copy-label";
      labelElement.textContent = `${label}\uFF1A`;
      const valueElement = document.createElement("strong");
      valueElement.textContent = value;
      const feedbackElement = document.createElement("span");
      feedbackElement.className = "opx-copy-feedback";
      feedbackElement.textContent = "\u5DF2\u590D\u5236";
      feedbackElement.hidden = true;
      let feedbackTimer = null;
      row.append(labelElement, valueElement, feedbackElement);
      row.addEventListener("click", async () => {
        await navigator.clipboard.writeText(value);
        if (feedbackTimer) {
          window.clearTimeout(feedbackTimer);
        }
        row.classList.add("is-copied");
        feedbackElement.hidden = false;
        feedbackTimer = window.setTimeout(() => {
          row.classList.remove("is-copied");
          feedbackElement.hidden = true;
          feedbackTimer = null;
        }, 1400);
      });
      return row;
    }
    function createSection(section) {
      const body = document.createElement("div");
      body.className = "opx-copy-section-body";
      for (const item of section.items) {
        if (!item.value) {
          continue;
        }
        body.append(createCopyRow(item.label, item.value));
      }
      if (section.collapsed) {
        const details = document.createElement("details");
        details.className = "opx-accordion-section";
        const summaryElement = document.createElement("summary");
        summaryElement.textContent = section.title;
        details.append(summaryElement, body);
        return details;
      }
      const wrapper = document.createElement("section");
      wrapper.className = "opx-copy-section";
      const title = document.createElement("div");
      title.className = "opx-copy-section-title";
      title.textContent = section.title;
      wrapper.append(title, body);
      return wrapper;
    }
  }
  function addressSections(address) {
    return [
      {
        title: "\u5730\u5740\u8D44\u6599",
        items: [
          { label: "\u56FD\u5BB6", value: `${address.countryLabel || address.countryCode} / ${address.countryCode}` },
          { label: "\u59D3\u540D", value: address.fullName },
          { label: "\u7535\u8BDD", value: address.phone },
          { label: "\u5730\u57401", value: address.line1 },
          { label: "\u5730\u57402", value: address.line2 },
          { label: "\u57CE\u5E02", value: address.city },
          { label: "\u5DDE/\u7701", value: address.stateFull ? `${address.stateFull} / ${address.state}` : address.state },
          { label: "\u90AE\u7F16", value: address.postalCode }
        ]
      },
      {
        title: "\u4FE1\u7528\u5361\u8D44\u6599",
        items: [
          { label: "\u5361\u7C7B\u578B", value: address.creditCard.type },
          { label: "\u5361\u53F7", value: address.creditCard.number },
          { label: "CVV", value: address.creditCard.cvv },
          { label: "\u6709\u6548\u671F", value: address.creditCard.expires },
          { label: "\u540E\u56DB\u4F4D", value: address.creditCard.last4 }
        ]
      },
      {
        title: "\u8EAB\u4EFD\u8D44\u6599",
        collapsed: true,
        items: [
          { label: "\u6027\u522B", value: address.identity.gender },
          { label: "\u79F0\u8C13", value: address.identity.title },
          { label: "\u751F\u65E5", value: address.identity.birthday },
          { label: "\u7528\u6237\u540D", value: address.identity.username },
          { label: "\u5BC6\u7801", value: address.identity.password },
          { label: "\u4E34\u65F6\u90AE\u7BB1", value: address.identity.temporaryMail },
          { label: "\u7CFB\u7EDF", value: address.identity.system },
          { label: "\u7F51\u7AD9", value: address.identity.website },
          { label: "\u5B89\u5168\u95EE\u9898", value: address.identity.securityQuestion },
          { label: "\u5B89\u5168\u7B54\u6848", value: address.identity.securityAnswer }
        ]
      },
      {
        title: "\u5C31\u4E1A\u8D44\u6599",
        collapsed: true,
        items: [
          { label: "\u516C\u53F8", value: address.employment.companyName },
          { label: "\u804C\u4E1A", value: address.employment.occupation },
          { label: "\u5C31\u4E1A\u72B6\u6001", value: address.employment.employmentStatus },
          { label: "\u6708\u85AA", value: address.employment.monthlySalary },
          { label: "\u516C\u53F8\u89C4\u6A21", value: address.employment.companySize },
          { label: "\u6559\u80B2\u80CC\u666F", value: address.employment.educationalBackground }
        ]
      }
    ];
  }
  function createCountrySelect() {
    const select = document.createElement("select");
    select.className = "opx-select";
    const randomCountryOption = document.createElement("option");
    randomCountryOption.value = "RANDOM";
    randomCountryOption.textContent = "\u968F\u673A\u56FD\u5BB6";
    select.append(randomCountryOption);
    for (const country of ADDRESS_COUNTRY_OPTIONS) {
      const option = document.createElement("option");
      option.value = country.code;
      option.textContent = `${country.label} / ${country.code}`;
      select.append(option);
    }
    return select;
  }
  function createField(label, control) {
    const field = document.createElement("label");
    field.className = "opx-field";
    const caption = document.createElement("span");
    caption.className = "opx-label";
    caption.textContent = label;
    field.append(caption, control);
    return field;
  }
  function createButton(label, className = "opx-button") {
    const button = document.createElement("button");
    button.className = className;
    button.type = "button";
    button.textContent = label;
    return button;
  }
  function createEmpty(text) {
    const item = document.createElement("div");
    item.className = "opx-empty-inline";
    item.textContent = text;
    return item;
  }
  function setStatus(element, message, type) {
    element.textContent = message;
    element.dataset.type = type;
  }
  function errorMessage2(error) {
    return error instanceof Error ? error.message : String(error);
  }
  function isRandomAddressResponse3(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }

  // src/features/sms/parser.ts
  var MAX_CODE_LENGTH = 8;
  var MIN_CODE_LENGTH = 4;
  var MESSAGE_FIELD_NAMES = /* @__PURE__ */ new Set([
    "data",
    "message",
    "msg",
    "content",
    "text",
    "body",
    "sms",
    "otp",
    "code",
    "verifycode",
    "verificationcode",
    "captcha",
    "result",
    "value"
  ]);
  var IGNORE_FIELD_NAMES = /* @__PURE__ */ new Set([
    "status",
    "statuscode",
    "httpstatus",
    "ret",
    "errno",
    "errorcode"
  ]);
  var EMPTY_MESSAGE_PATTERN = /^(no\s*message|no\s*sms|empty|none|null|暂无|没有|未收到)$/i;
  var GENERIC_STATUS_PATTERN = /^(ok|success|successful|true|请求成功|成功)$/i;
  function parseSmsRelayTargets(input) {
    const targets = [];
    const errors = [];
    const seen = /* @__PURE__ */ new Set();
    const lines = input.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    lines.forEach((line, index) => {
      const separatorIndex = line.indexOf("----");
      if (separatorIndex < 0) {
        errors.push(`\u7B2C ${index + 1} \u884C\u7F3A\u5C11 ---- \u5206\u9694\u7B26`);
        return;
      }
      const phone = line.slice(0, separatorIndex).trim();
      const url = line.slice(separatorIndex + 4).trim();
      if (!phone || !url) {
        errors.push(`\u7B2C ${index + 1} \u884C\u53F7\u7801\u6216 API \u94FE\u63A5\u4E3A\u7A7A`);
        return;
      }
      if (!isHttpUrl(url)) {
        errors.push(`\u7B2C ${index + 1} \u884C API \u94FE\u63A5\u4E0D\u662F http/https \u5730\u5740`);
        return;
      }
      const key = `${phone}
${url}`;
      if (seen.has(key)) {
        return;
      }
      seen.add(key);
      targets.push({
        id: makeTargetId(phone, url),
        phone,
        url
      });
    });
    return { targets, errors };
  }
  function extractSmsCode(message) {
    const trimmed = message.trim();
    if (!trimmed || EMPTY_MESSAGE_PATTERN.test(trimmed)) {
      return "";
    }
    const matches = trimmed.match(new RegExp(`\\b\\d{${MIN_CODE_LENGTH},${MAX_CODE_LENGTH}}\\b`, "g"));
    return matches?.[0] || "";
  }
  function extractSmsPayload(payload) {
    const candidates = collectMessageCandidates(payload);
    const best = candidates.map((candidate) => ({
      ...candidate,
      code: extractSmsCode(candidate.text)
    })).filter((candidate) => candidate.text && !isEmptyMessage(candidate.text) && !isGenericStatusMessage(candidate.text)).sort((left, right) => scoreCandidate(right) - scoreCandidate(left))[0];
    if (best?.code) {
      return {
        code: best.code,
        message: best.text
      };
    }
    const fallback = candidates.map((candidate) => candidate.text).find((text) => text && !isEmptyMessage(text) && !isGenericStatusMessage(text));
    return {
      code: "",
      message: fallback || ""
    };
  }
  function collectMessageCandidates(payload) {
    const candidates = [];
    const seenObjects = /* @__PURE__ */ new WeakSet();
    visit(payload, "", 0);
    return candidates;
    function visit(value, key, depth) {
      if (value === null || value === void 0 || depth > 6) {
        return;
      }
      if (typeof value === "string") {
        addCandidate(value, key, depth);
        parseNestedJson(value, key, depth);
        return;
      }
      if (typeof value === "number") {
        if (isLikelyCodeField(key)) {
          addCandidate(String(value), key, depth);
        }
        return;
      }
      if (typeof value !== "object") {
        return;
      }
      if (seenObjects.has(value)) {
        return;
      }
      seenObjects.add(value);
      if (Array.isArray(value)) {
        value.forEach((item, index) => visit(item, key || String(index), depth + 1));
        return;
      }
      for (const [childKey, childValue] of Object.entries(value)) {
        if (isIgnoredField(childKey)) {
          continue;
        }
        visit(childValue, childKey, depth + 1);
      }
    }
    function addCandidate(value, key, depth) {
      const text = value.trim();
      if (!text || text.length > 600 || isIgnoredField(key)) {
        return;
      }
      candidates.push({
        text,
        key,
        depth,
        fromPreferredField: isPreferredMessageField(key)
      });
    }
    function parseNestedJson(value, key, depth) {
      const trimmed = value.trim();
      if (!trimmed || !/^[{[]/.test(trimmed)) {
        return;
      }
      try {
        visit(JSON.parse(trimmed), key, depth + 1);
      } catch {
      }
    }
  }
  function scoreCandidate(candidate) {
    let score = 0;
    if (candidate.code) {
      score += 100;
    }
    if (candidate.fromPreferredField) {
      score += 30;
    }
    if (hasSmsKeyword(candidate.text)) {
      score += 20;
    }
    if (isLikelyCodeField(candidate.key)) {
      score += 10;
    }
    if (isJsonLikeText(candidate.text)) {
      score -= 8;
    }
    score -= candidate.depth;
    return score;
  }
  function hasSmsKeyword(value) {
    return /code|验证码|驗證碼|verify|verification|security|otp|paypal|openai|chatgpt/i.test(value);
  }
  function isEmptyMessage(value) {
    return EMPTY_MESSAGE_PATTERN.test(value.trim());
  }
  function isGenericStatusMessage(value) {
    return GENERIC_STATUS_PATTERN.test(value.trim());
  }
  function isJsonLikeText(value) {
    return /^[{[]/.test(value.trim());
  }
  function isPreferredMessageField(key) {
    return MESSAGE_FIELD_NAMES.has(normalizeFieldName(key));
  }
  function isIgnoredField(key) {
    return IGNORE_FIELD_NAMES.has(normalizeFieldName(key));
  }
  function isLikelyCodeField(key) {
    const normalized = normalizeFieldName(key);
    return normalized === "otp" || normalized === "smscode" || normalized === "verifycode" || normalized === "verificationcode" || normalized === "captcha";
  }
  function normalizeFieldName(key) {
    return key.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function isHttpUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch {
      return false;
    }
  }
  function makeTargetId(phone, url) {
    return `${phone}|${url}`;
  }

  // src/features/sms/poller.ts
  async function fetchSmsRelayCode(target) {
    let response;
    try {
      response = await browser.runtime.sendMessage({
        type: "opx:fetch-sms-relay",
        url: target.url
      });
    } catch (error) {
      return {
        kind: "error",
        target,
        message: `\u8BF7\u6C42\u5931\u8D25\uFF1A${errorMessage3(error)}`
      };
    }
    if (!isSmsRelayFetchResponse(response) || !response.ok) {
      return {
        kind: "error",
        target,
        message: response?.message || "API \u8FD4\u56DE\u7ED3\u679C\u65E0\u6548"
      };
    }
    const extracted = extractSmsPayload({
      raw: response.raw,
      data: response.data,
      text: response.text,
      message: response.message
    });
    const message = extracted.message;
    const code = extracted.code;
    if (!code) {
      return {
        kind: "empty",
        target,
        message: message || response.data || response.message || "\u6682\u65E0\u77ED\u4FE1"
      };
    }
    return {
      kind: "code",
      target,
      code,
      message
    };
  }
  function isSmsRelayFetchResponse(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }
  function errorMessage3(error) {
    return error instanceof Error ? error.message : String(error);
  }

  // src/features/auto-orchestrator/orchestrator.ts
  var STORAGE_KEY2 = "opx.orchestrator.state";
  var LOG_PREFIX3 = "[OPX Auto]";
  var POLL_INTERVAL_MS = 2e3;
  var SMS_POLL_INTERVAL_MS = 5e3;
  var SMS_TIMEOUT_MS = 18e4;
  var running3 = false;
  var pollTimer = null;
  var listeners = [];
  var DEFAULT_STATE = {
    enabled: false,
    currentStep: "idle",
    statusMessage: "\u7B49\u5F85\u5F00\u59CB",
    startedAt: 0,
    completedSteps: [],
    lastError: "",
    generatedLink: "",
    updatedAt: 0
  };
  function onOrchestratorStateChange(fn) {
    listeners.push(fn);
    return () => {
      listeners = listeners.filter((item) => item !== fn);
    };
  }
  async function loadOrchestratorState() {
    const data = await browser.storage.local.get(STORAGE_KEY2);
    return normalizeState(data[STORAGE_KEY2]);
  }
  async function saveOrchestratorState(patch) {
    const current = await loadOrchestratorState();
    const next = normalizeState({ ...current, ...patch, updatedAt: Date.now() });
    await browser.storage.local.set({ [STORAGE_KEY2]: next });
    notifyListeners(next);
    return next;
  }
  async function startOrchestrator() {
    const registerState = await loadRegisterState();
    if (!registerState.rawInput.trim()) {
      await saveOrchestratorState({
        enabled: false,
        currentStep: "error",
        lastError: "\u8BF7\u5148\u5728\u6CE8\u518C tab \u8F93\u5165 Outlook \u8D26\u53F7\u884C",
        statusMessage: "\u8BF7\u5148\u8F93\u5165\u8D26\u53F7"
      });
      return;
    }
    await saveOrchestratorState({
      enabled: true,
      currentStep: "idle",
      statusMessage: "\u81EA\u52A8\u5316\u5DF2\u542F\u52A8\uFF0C\u6B63\u5728\u68C0\u6D4B\u9875\u9762...",
      startedAt: Date.now(),
      completedSteps: [],
      lastError: "",
      generatedLink: ""
    });
    beginPolling();
  }
  async function stopOrchestrator() {
    cancelPolling();
    await saveOrchestratorState({
      enabled: false,
      currentStep: "idle",
      statusMessage: "\u5DF2\u505C\u6B62"
    });
  }
  function beginPolling() {
    if (pollTimer) {
      return;
    }
    pollTimer = window.setInterval(() => void tick(), POLL_INTERVAL_MS);
    void tick();
  }
  async function resumeIfEnabled() {
    const state = await loadOrchestratorState();
    if (state.enabled && state.currentStep !== "done" && state.currentStep !== "error") {
      beginPolling();
    }
  }
  function cancelPolling() {
    if (pollTimer) {
      window.clearInterval(pollTimer);
      pollTimer = null;
    }
  }
  async function tick() {
    if (running3) {
      return;
    }
    running3 = true;
    try {
      const state = await loadOrchestratorState();
      if (!state.enabled) {
        cancelPolling();
        return;
      }
      await runStep(state);
    } catch (error) {
      console.warn(`${LOG_PREFIX3} tick error`, error);
      await saveOrchestratorState({
        currentStep: "error",
        lastError: errorMessage4(error),
        statusMessage: `\u51FA\u9519\uFF1A${errorMessage4(error)}`
      });
    } finally {
      running3 = false;
    }
  }
  async function runStep(state) {
    const hostname = location.hostname;
    const url = location.href;
    if (isChatGptLoginPage()) {
      if (state.completedSteps.includes("fill-email")) {
        await setStep("wait-otp", "\u5DF2\u586B\u8FC7\u90AE\u7BB1\uFF0C\u7B49\u5F85\u8DF3\u8F6C\u5230\u9A8C\u8BC1\u7801\u9875...");
        return;
      }
      await setStep("fill-email", "\u68C0\u6D4B\u5230\u767B\u5F55\u9875\uFF0C\u6B63\u5728\u586B\u5165\u90AE\u7BB1...");
      const controller = createRegisterController();
      const result = await controller.fillEmailFromInput();
      if (result.ok) {
        await markCompleted("fill-email", "\u90AE\u7BB1\u5DF2\u586B\u5165\uFF0C\u7B49\u5F85\u9A8C\u8BC1\u7801\u9875...");
      } else {
        await setStep("error", result.message, result.message);
      }
      return;
    }
    if (isEmailVerificationPage()) {
      if (state.completedSteps.includes("wait-otp")) {
        await setStep("fill-profile", "\u9A8C\u8BC1\u7801\u5DF2\u5904\u7406\uFF0C\u7B49\u5F85\u8D44\u6599\u9875...");
        return;
      }
      await setStep("wait-otp", "\u68C0\u6D4B\u5230\u9A8C\u8BC1\u7801\u9875\uFF0C\u6B63\u5728\u7B49\u5F85 Outlook \u9A8C\u8BC1\u7801...");
      const controller = createRegisterController();
      const result = await controller.waitForOutlookOtp();
      if (result.ok) {
        await markCompleted("wait-otp", `\u9A8C\u8BC1\u7801\u5DF2\u586B\u5165\uFF1A${result.code || ""}`);
      } else {
        await setStep("error", result.message, result.message);
      }
      return;
    }
    if (isAboutYouPage()) {
      if (state.completedSteps.includes("fill-profile")) {
        await setStep("fetch-session", "\u8D44\u6599\u5DF2\u586B\uFF0C\u7B49\u5F85\u8DF3\u8F6C\u5230 chatgpt.com...");
        return;
      }
      await setStep("fill-profile", "\u68C0\u6D4B\u5230\u8D44\u6599\u9875\uFF0C\u6B63\u5728\u586B\u5199...");
      const controller = createRegisterController();
      const result = await controller.fillProfileAndCreate();
      if (result.ok) {
        await markCompleted("fill-profile", "\u8D44\u6599\u5DF2\u586B\u5199\u5E76\u63D0\u4EA4");
      } else {
        await setStep("error", result.message, result.message);
      }
      return;
    }
    if (hostname === "chatgpt.com" && !url.includes("/auth") && !isChatGptLoginPage()) {
      if (state.completedSteps.includes("generate-link") && state.generatedLink) {
        await setStep("open-checkout", "\u6B63\u5728\u6253\u5F00\u652F\u4ED8\u94FE\u63A5...");
        window.location.href = state.generatedLink;
        return;
      }
      if (!state.completedSteps.includes("fetch-session")) {
        await setStep("fetch-session", "\u6B63\u5728\u8BFB\u53D6 ChatGPT session...");
        const sessionResponse = await browser.runtime.sendMessage({
          type: "opx:fetch-chatgpt-session"
        });
        if (!sessionResponse?.ok || !sessionResponse.session?.accessToken) {
          await setStep("fetch-session", sessionResponse?.message || "\u7B49\u5F85\u767B\u5F55\u5B8C\u6210...");
          return;
        }
        await markCompleted("fetch-session", `Session \u5DF2\u8BFB\u53D6\uFF1A${sessionResponse.session.email}`);
      }
      if (!state.completedSteps.includes("generate-link")) {
        await setStep("generate-link", "\u6B63\u5728\u751F\u6210 Plus \u8BA2\u9605\u94FE\u63A5...");
        const sessionResponse = await browser.runtime.sendMessage({
          type: "opx:fetch-chatgpt-session"
        });
        const token = sessionResponse?.session?.accessToken || "";
        if (!token) {
          await setStep("error", "\u65E0\u6CD5\u83B7\u53D6 accessToken", "\u65E0\u6CD5\u83B7\u53D6 accessToken");
          return;
        }
        const linkState = await loadLinkExtractorState();
        const linkResponse = await browser.runtime.sendMessage({
          type: "opx:create-checkout-link",
          raw: token,
          options: linkState.checkoutOptions
        });
        const link = linkResponse?.link || linkResponse?.url || "";
        if (!linkResponse?.ok || !link) {
          await setStep("error", linkResponse?.message || "\u751F\u6210\u94FE\u63A5\u5931\u8D25", linkResponse?.message || "");
          return;
        }
        await saveOrchestratorState({ generatedLink: link });
        await markCompleted("generate-link", `\u94FE\u63A5\u5DF2\u751F\u6210`);
        await setStep("open-checkout", "\u6B63\u5728\u8DF3\u8F6C\u5230\u652F\u4ED8\u9875...");
        window.location.href = link;
        return;
      }
      return;
    }
    if (hostname === "pay.openai.com") {
      if (!state.completedSteps.includes("open-checkout")) {
        await markCompleted("open-checkout", "\u5DF2\u5230\u8FBE\u652F\u4ED8\u9875");
      }
      await setStep("wait-payment-page", "\u652F\u4ED8\u9875\u5DF2\u5230\u8FBE\uFF0C\u6B63\u5728\u9009\u62E9 PayPal \u5E76\u586B\u5199\u5730\u5740...");
      const { initPayOpenAiAddressAutofill: initPayOpenAiAddressAutofill2, fillPayOpenAiAddressNow: fillPayOpenAiAddressNow2 } = await Promise.resolve().then(() => (init_pay_openai_autofill(), pay_openai_autofill_exports));
      try {
        initPayOpenAiAddressAutofill2();
      } catch {
      }
      await delay2(1500);
      const addressResponse = await browser.runtime.sendMessage({
        type: "opx:fetch-random-address",
        countryCode: "US",
        city: ""
      });
      if (addressResponse?.ok && addressResponse?.address) {
        const result = await fillPayOpenAiAddressNow2(addressResponse.address);
        if (result.ok) {
          await setStep("wait-payment-page", `\u652F\u4ED8\u9875\u5DF2\u586B\u5199 ${result.filled} \u9879\uFF0C\u7B49\u5F85\u8DF3\u8F6C PayPal...`);
        }
      }
      return;
    }
    if (hostname === "www.paypal.com" || hostname === "paypal.com") {
      if (!state.completedSteps.includes("wait-payment-page")) {
        await markCompleted("wait-payment-page", "\u5DF2\u8DF3\u8F6C PayPal");
      }
      if (isPaypalSmsVerificationPage()) {
        await setStep("wait-paypal-sms", "\u68C0\u6D4B\u5230 PayPal \u77ED\u4FE1\u9A8C\u8BC1\u9875\uFF0C\u6B63\u5728\u63A5\u7801...");
        const smsResult = await pollPaypalSms();
        if (smsResult.ok) {
          await markCompleted("wait-paypal-sms", `\u77ED\u4FE1\u9A8C\u8BC1\u7801\u5DF2\u586B\u5165\uFF1A${smsResult.code}`);
          await setStep("done", "\u5168\u6D41\u7A0B\u5B8C\u6210\uFF01");
          await saveOrchestratorState({ enabled: false });
          cancelPolling();
        } else {
          await setStep("wait-paypal-sms", smsResult.message);
        }
      } else {
        await setStep("wait-paypal-sms", "PayPal \u9875\u9762\u586B\u5199\u4E2D\uFF0C\u7B49\u5F85\u77ED\u4FE1\u9A8C\u8BC1...");
      }
      return;
    }
    if (hostname === "auth.openai.com") {
      await setStep(state.currentStep, "\u5728 auth.openai.com \u4E2D\u95F4\u9875\uFF0C\u7B49\u5F85\u8DF3\u8F6C...");
      return;
    }
  }
  async function setStep(step, message, errorMsg) {
    const patch = {
      currentStep: step,
      statusMessage: message
    };
    if (errorMsg) {
      patch.lastError = errorMsg;
    }
    await saveOrchestratorState(patch);
    console.info(`${LOG_PREFIX3} [${step}] ${message}`);
  }
  async function markCompleted(step, message) {
    const state = await loadOrchestratorState();
    const completed = [...state.completedSteps];
    if (!completed.includes(step)) {
      completed.push(step);
    }
    await saveOrchestratorState({
      completedSteps: completed,
      statusMessage: message
    });
    console.info(`${LOG_PREFIX3} [DONE] ${step}: ${message}`);
  }
  function isPaypalSmsVerificationPage() {
    const smsInput = document.querySelector(
      'input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="\u9A8C\u8BC1\u7801"], input[aria-label*="code" i], input[placeholder*="code" i]'
    );
    if (smsInput) {
      return true;
    }
    const bodyText = (document.body?.textContent || "").toLowerCase();
    return bodyText.includes("enter the code") || bodyText.includes("verification code") || bodyText.includes("\u8F93\u5165\u9A8C\u8BC1\u7801") || bodyText.includes("confirm your number");
  }
  async function pollPaypalSms() {
    const smsState = await loadSmsRelayState();
    const targets = parseSmsTargets(smsState.rawInput);
    if (!targets.length) {
      return { ok: false, code: "", message: "\u6CA1\u6709\u914D\u7F6E\u63A5\u7801 API \u94FE\u63A5\uFF0C\u8BF7\u5728\u63A5\u7801 tab \u8F93\u5165" };
    }
    const target = targets[0];
    const deadline = Date.now() + SMS_TIMEOUT_MS;
    while (Date.now() < deadline) {
      const result = await fetchSmsRelayCode(target);
      if (result.kind === "code" && result.code) {
        fillPaypalSmsCode(result.code);
        return { ok: true, code: result.code, message: `\u5DF2\u6536\u5230\u9A8C\u8BC1\u7801\uFF1A${result.code}` };
      }
      await delay2(SMS_POLL_INTERVAL_MS);
    }
    return { ok: false, code: "", message: "\u7B49\u5F85\u77ED\u4FE1\u9A8C\u8BC1\u7801\u8D85\u65F6" };
  }
  function fillPaypalSmsCode(code) {
    const smsInput = document.querySelector(
      'input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="\u9A8C\u8BC1\u7801"], input[aria-label*="code" i], input[placeholder*="code" i]'
    );
    if (!smsInput) {
      return;
    }
    const prototype = HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor?.set) {
      descriptor.set.call(smsInput, code);
    } else {
      smsInput.value = code;
    }
    smsInput.dispatchEvent(new Event("input", { bubbles: true }));
    smsInput.dispatchEvent(new Event("change", { bubbles: true }));
    setTimeout(() => {
      const submitButton = document.querySelector(
        'button[type="submit"], button[data-testid="submit"], button.primary'
      );
      if (submitButton && !submitButton.disabled) {
        submitButton.click();
      }
    }, 500);
  }
  function parseSmsTargets(rawInput) {
    const lines = rawInput.split("\n").map((line) => line.trim()).filter(Boolean);
    const targets = [];
    for (const line of lines) {
      const parts = line.split(/[\s|]+/);
      const url = parts.find((part) => part.startsWith("http"));
      const phone = parts.find((part) => /^\+?\d{7,}$/.test(part)) || "";
      if (url) {
        targets.push({
          id: `${phone || "auto"}-${Date.now()}`,
          phone,
          url
        });
      }
    }
    return targets;
  }
  function notifyListeners(state) {
    for (const fn of listeners) {
      try {
        fn(state);
      } catch {
      }
    }
  }
  function normalizeState(value) {
    if (!value || typeof value !== "object") {
      return { ...DEFAULT_STATE };
    }
    const source = value;
    return {
      enabled: Boolean(source.enabled),
      currentStep: isValidStep(source.currentStep) ? source.currentStep : "idle",
      statusMessage: String(source.statusMessage || DEFAULT_STATE.statusMessage),
      startedAt: Number(source.startedAt || 0),
      completedSteps: Array.isArray(source.completedSteps) ? source.completedSteps.filter(isValidStep) : [],
      lastError: String(source.lastError || ""),
      generatedLink: String(source.generatedLink || ""),
      updatedAt: Number(source.updatedAt || 0)
    };
  }
  function isValidStep(value) {
    return typeof value === "string" && [
      "idle",
      "fill-email",
      "wait-otp",
      "fill-profile",
      "fetch-session",
      "generate-link",
      "open-checkout",
      "wait-payment-page",
      "wait-paypal-sms",
      "done",
      "error"
    ].includes(value);
  }
  function errorMessage4(error) {
    return error instanceof Error ? error.message : String(error);
  }
  function delay2(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/features/auto-orchestrator/types.ts
  var STEP_LABELS = {
    "idle": "\u7B49\u5F85\u5F00\u59CB",
    "fill-email": "\u586B\u5165\u90AE\u7BB1",
    "wait-otp": "\u7B49\u5F85\u9A8C\u8BC1\u7801",
    "fill-profile": "\u586B\u5199\u8D44\u6599",
    "fetch-session": "\u8BFB\u53D6 Session",
    "generate-link": "\u751F\u6210\u8BA2\u9605\u94FE\u63A5",
    "open-checkout": "\u6253\u5F00\u652F\u4ED8\u9875",
    "wait-payment-page": "\u7B49\u5F85\u652F\u4ED8\u9875\u586B\u5199",
    "wait-paypal-sms": "\u7B49\u5F85 PayPal \u77ED\u4FE1\u9A8C\u8BC1",
    "done": "\u5168\u6D41\u7A0B\u5B8C\u6210",
    "error": "\u51FA\u9519"
  };

  // src/features/auto-orchestrator/panel.ts
  function createAutoPanel(container) {
    const wrapper = document.createElement("div");
    wrapper.className = "opx-auto-panel";
    const desc = document.createElement("div");
    desc.className = "opx-hint";
    desc.textContent = "\u4E00\u952E\u81EA\u52A8\u5316\uFF1A\u8F93\u5165 Outlook \u8D26\u53F7\u540E\u70B9\u51FB\u5F00\u59CB\uFF0C\u5168\u6D41\u7A0B\u81EA\u52A8\u6267\u884C\u3002";
    const buttonRow = document.createElement("div");
    buttonRow.className = "opx-button-row";
    buttonRow.style.marginTop = "12px";
    const startButton = document.createElement("button");
    startButton.className = "opx-button";
    startButton.type = "button";
    startButton.textContent = "\u4E00\u952E\u5F00\u59CB";
    const stopButton = document.createElement("button");
    stopButton.className = "opx-button opx-button-secondary";
    stopButton.type = "button";
    stopButton.textContent = "\u505C\u6B62";
    stopButton.disabled = true;
    const resetButton = document.createElement("button");
    resetButton.className = "opx-button opx-button-secondary";
    resetButton.type = "button";
    resetButton.textContent = "\u91CD\u7F6E";
    buttonRow.append(startButton, stopButton, resetButton);
    const statusBox = document.createElement("div");
    statusBox.className = "opx-status";
    statusBox.style.marginTop = "12px";
    statusBox.textContent = "\u7B49\u5F85\u5F00\u59CB";
    const stepsContainer = document.createElement("div");
    stepsContainer.className = "opx-steps-list";
    stepsContainer.style.marginTop = "12px";
    const allSteps = [
      "fill-email",
      "wait-otp",
      "fill-profile",
      "fetch-session",
      "generate-link",
      "open-checkout",
      "wait-payment-page",
      "wait-paypal-sms"
    ];
    const stepElements = {};
    for (const step of allSteps) {
      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:6px;padding:3px 0;font-size:12px;color:#94a3b8;";
      const icon = document.createElement("span");
      icon.style.cssText = "width:16px;text-align:center;";
      icon.textContent = "\u25CB";
      const label = document.createElement("span");
      label.textContent = STEP_LABELS[step];
      row.append(icon, label);
      stepsContainer.append(row);
      stepElements[step] = row;
    }
    const linkOutput = document.createElement("div");
    linkOutput.className = "opx-hint";
    linkOutput.style.marginTop = "8px";
    linkOutput.style.wordBreak = "break-all";
    wrapper.append(desc, buttonRow, statusBox, stepsContainer, linkOutput);
    container.append(wrapper);
    startButton.addEventListener("click", async () => {
      startButton.disabled = true;
      stopButton.disabled = false;
      await startOrchestrator();
    });
    stopButton.addEventListener("click", async () => {
      stopButton.disabled = true;
      startButton.disabled = false;
      await stopOrchestrator();
    });
    resetButton.addEventListener("click", async () => {
      await stopOrchestrator();
      startButton.disabled = false;
      stopButton.disabled = true;
      renderState({ ...DEFAULT_RENDER_STATE });
    });
    onOrchestratorStateChange((state) => {
      renderState(state);
    });
    function renderState(state) {
      startButton.disabled = state.enabled;
      stopButton.disabled = !state.enabled;
      statusBox.textContent = state.statusMessage;
      statusBox.dataset.type = state.currentStep === "error" ? "error" : state.currentStep === "done" ? "ok" : "pending";
      for (const step of allSteps) {
        const row = stepElements[step];
        const icon = row?.firstElementChild;
        if (!row || !icon) {
          continue;
        }
        if (state.completedSteps.includes(step)) {
          icon.textContent = "\u2714";
          row.style.color = "#10b981";
        } else if (state.currentStep === step) {
          icon.textContent = "\u25CF";
          row.style.color = "#f59e0b";
        } else {
          icon.textContent = "\u25CB";
          row.style.color = "#94a3b8";
        }
      }
      if (state.generatedLink) {
        linkOutput.textContent = `\u8BA2\u9605\u94FE\u63A5\uFF1A${state.generatedLink}`;
      } else {
        linkOutput.textContent = "";
      }
    }
    const update = async () => {
      const state = await loadOrchestratorState();
      renderState(state);
    };
    void update();
    return { update };
  }
  var DEFAULT_RENDER_STATE = {
    enabled: false,
    currentStep: "idle",
    statusMessage: "\u7B49\u5F85\u5F00\u59CB",
    startedAt: 0,
    completedSteps: [],
    lastError: "",
    generatedLink: "",
    updatedAt: 0
  };

  // src/features/link-extractor/panel.ts
  var REGION_OPTIONS = [
    ["ID", "\u5370\u5C3C / IDR"],
    ["DE", "\u5FB7\u56FD / EUR"],
    ["JP", "\u65E5\u672C / JPY"],
    ["US", "\u7F8E\u56FD / USD"]
  ];
  function createLinkExtractorPanel(container) {
    const linkSummary = document.createElement("div");
    linkSummary.className = "opx-summary";
    const sessionCard = document.createElement("div");
    sessionCard.className = "opx-session-card";
    const emailValue = createSessionRow("\u90AE\u7BB1", "\u672A\u8BFB\u53D6");
    const planValue = createSessionRow("\u5957\u9910", "\u672A\u8BFB\u53D6");
    const tokenValue = createSessionRow("Token", "\u672A\u8BFB\u53D6");
    sessionCard.append(emailValue.row, planValue.row, tokenValue.row);
    const refreshSessionButton = createButton2("\u8BFB\u53D6 ChatGPT session", "opx-button opx-button-secondary");
    const planSelect = createSelect([
      ["chatgptplusplan", "ChatGPT Plus"],
      ["chatgptteamplan", "ChatGPT Team"]
    ]);
    const uiModeSelect = createSelect([
      ["custom", "\u77ED\u94FE\u63A5 / custom"],
      ["hosted", "\u957F\u94FE\u63A5 / hosted"]
    ]);
    const regionSelect = createSelect(REGION_OPTIONS);
    const workspaceInput = createInput("Workspace \u540D\u79F0", "text");
    const seatsInput = createInput("\u5E2D\u4F4D\u6570\u91CF", "number");
    seatsInput.min = "2";
    seatsInput.step = "1";
    const mainGrid = document.createElement("div");
    mainGrid.className = "opx-grid";
    const planField = createField2("\u5957\u9910\u7C7B\u578B", planSelect);
    const uiModeField = createField2("\u94FE\u63A5\u5F62\u5F0F", uiModeSelect);
    const regionField = createField2("\u8BA1\u8D39\u533A\u57DF", regionSelect);
    mainGrid.append(planField, uiModeField, regionField);
    const teamOptions = document.createElement("div");
    teamOptions.className = "opx-team-options";
    const teamGrid = document.createElement("div");
    teamGrid.className = "opx-grid";
    teamGrid.append(
      createField2("Workspace", workspaceInput),
      createField2("\u5E2D\u4F4D", seatsInput)
    );
    teamOptions.append(teamGrid);
    const tokenInput = document.createElement("textarea");
    tokenInput.className = "opx-textarea opx-token-textarea";
    tokenInput.placeholder = "\u81EA\u52A8\u8BFB\u53D6\u6216\u624B\u52A8\u7C98\u8D34 ChatGPT session JSON / Access Token";
    tokenInput.autocomplete = "off";
    tokenInput.spellcheck = false;
    const tokenHint = document.createElement("div");
    tokenHint.className = "opx-hint";
    tokenHint.textContent = "\u5207\u5230\u63D0\u94FE\u63A5 tab \u4F1A\u8BFB\u53D6 /api/auth/session\uFF1Btoken \u53EA\u5728\u5F53\u524D\u9875\u9762\u5185\u4F7F\u7528\u3002";
    const generateLinkButton = createButton2("\u751F\u6210\u8BA2\u9605\u94FE\u63A5");
    const linkOutput = document.createElement("textarea");
    linkOutput.className = "opx-textarea opx-output";
    linkOutput.placeholder = "\u751F\u6210\u540E\u7684\u8BA2\u9605\u94FE\u63A5";
    linkOutput.readOnly = true;
    linkOutput.spellcheck = false;
    const linkButtonRow = document.createElement("div");
    linkButtonRow.className = "opx-button-row";
    const copyLinkButton = createButton2("\u590D\u5236\u94FE\u63A5", "opx-button opx-button-secondary");
    const openLinkButton = createButton2("\u6253\u5F00\u94FE\u63A5", "opx-button opx-button-secondary");
    const clearLinkButton = createButton2("\u6E05\u7A7A", "opx-button opx-button-secondary");
    linkButtonRow.append(copyLinkButton, openLinkButton, clearLinkButton);
    const linkStatus = document.createElement("div");
    linkStatus.className = "opx-status";
    linkStatus.textContent = "\u7B49\u5F85\u8BFB\u53D6 ChatGPT session\u3002";
    let generatedLink = "";
    let sessionAccessToken = "";
    let sessionFetchInFlight = false;
    let sessionFetchedOnce = false;
    const update = async () => {
      const saved = await loadLinkExtractorState();
      setCheckoutOptions(saved.checkoutOptions);
    };
    const onShow = async () => {
      await refreshSession();
    };
    const syncLinkOptions = async () => {
      try {
        const options = readCheckoutOptions();
        await saveLinkExtractorState({ checkoutOptions: options });
        setLinkSummary(options);
        setStatus2(linkStatus, "\u672C\u5730\u53C2\u6570\u5DF2\u66F4\u65B0", "ok");
      } catch (error) {
        setStatus2(linkStatus, errorMessage5(error), "error");
      }
    };
    for (const item of [planSelect, uiModeSelect, regionSelect, workspaceInput, seatsInput]) {
      item.addEventListener("change", () => void syncLinkOptions());
      item.addEventListener("input", () => void syncLinkOptions());
    }
    refreshSessionButton.addEventListener("click", () => void refreshSession());
    tokenInput.addEventListener("paste", () => window.setTimeout(() => normalizeTokenInput(false), 0));
    tokenInput.addEventListener("input", () => {
      sessionAccessToken = "";
      if (tokenInput.value.includes("accessToken") || tokenInput.value.length > 900) {
        normalizeTokenInput(false);
      }
    });
    generateLinkButton.addEventListener("click", async () => {
      setStatus2(linkStatus, "\u6B63\u5728\u751F\u6210\u8BA2\u9605\u94FE\u63A5...", "pending");
      const token = tokenInput.value.trim() ? normalizeTokenInput(true) : sessionAccessToken;
      if (!token) {
        setStatus2(linkStatus, "\u6CA1\u6709 accessToken\uFF0C\u8BF7\u5148\u8BFB\u53D6 session \u6216\u624B\u52A8\u7C98\u8D34\u3002", "error");
        return;
      }
      let options;
      try {
        options = readCheckoutOptions();
        await saveLinkExtractorState({ checkoutOptions: options });
      } catch (error) {
        setStatus2(linkStatus, errorMessage5(error), "error");
        return;
      }
      let response;
      try {
        response = await browser.runtime.sendMessage({
          type: "opx:create-checkout-link",
          raw: token,
          options
        });
      } catch (error) {
        setStatus2(linkStatus, `\u751F\u6210\u5931\u8D25\uFF1A${String(error)}`, "error");
        return;
      }
      const link = response?.link || response?.url || "";
      if (!isCheckoutLinkResponse(response) || !response.ok || !link) {
        setStatus2(linkStatus, response?.message || "\u751F\u6210\u5931\u8D25\uFF1A\u8FD4\u56DE\u7ED3\u679C\u65E0\u6548", "error");
        setGeneratedLink("");
        return;
      }
      setGeneratedLink(link);
      setStatus2(linkStatus, response.message, "ok");
    });
    copyLinkButton.addEventListener("click", async () => {
      if (!generatedLink) {
        return;
      }
      await navigator.clipboard.writeText(generatedLink);
      setStatus2(linkStatus, "\u5DF2\u590D\u5236\u94FE\u63A5", "ok");
    });
    openLinkButton.addEventListener("click", () => {
      if (generatedLink) {
        window.open(generatedLink, "_blank", "noopener,noreferrer");
      }
    });
    clearLinkButton.addEventListener("click", () => {
      tokenInput.value = "";
      sessionAccessToken = "";
      tokenHint.textContent = "\u5207\u5230\u63D0\u94FE\u63A5 tab \u4F1A\u8BFB\u53D6 /api/auth/session\uFF1Btoken \u53EA\u5728\u5F53\u524D\u9875\u9762\u5185\u4F7F\u7528\u3002";
      tokenHint.classList.remove("is-ok");
      setGeneratedLink("");
      setSessionRows("", "", "");
      setStatus2(linkStatus, "\u5DF2\u6E05\u7A7A", "ok");
      tokenInput.focus();
    });
    container.append(
      linkSummary,
      sessionCard,
      refreshSessionButton,
      mainGrid,
      teamOptions,
      tokenInput,
      tokenHint,
      generateLinkButton,
      createField2("\u8BA2\u9605\u94FE\u63A5", linkOutput),
      linkButtonRow,
      linkStatus
    );
    void update();
    setGeneratedLink("");
    return { update, onShow };
    async function refreshSession() {
      if (sessionFetchInFlight) {
        return;
      }
      sessionFetchInFlight = true;
      refreshSessionButton.disabled = true;
      setStatus2(linkStatus, "\u6B63\u5728\u8BFB\u53D6 https://chatgpt.com/api/auth/session ...", "pending");
      try {
        const response = await browser.runtime.sendMessage({
          type: "opx:fetch-chatgpt-session"
        });
        sessionFetchedOnce = true;
        if (!isChatGptSessionResponse(response)) {
          setStatus2(linkStatus, "session \u8FD4\u56DE\u7ED3\u679C\u65E0\u6548", "error");
          return;
        }
        const session = response.session;
        setSessionRows(session?.email || "", session?.planType || "", session?.accessToken || "");
        if (session?.accessToken) {
          sessionAccessToken = session.accessToken;
          tokenInput.value = session.accessToken;
          tokenHint.textContent = "\u5DF2\u4ECE ChatGPT session \u8BFB\u53D6 accessToken\u3002";
          tokenHint.classList.add("is-ok");
        }
        setStatus2(linkStatus, response.message, response.ok ? "ok" : "error");
      } catch (error) {
        setStatus2(linkStatus, `\u8BFB\u53D6 session \u5931\u8D25\uFF1A${String(error)}`, "error");
      } finally {
        refreshSessionButton.disabled = false;
        sessionFetchInFlight = false;
      }
    }
    function setCheckoutOptions(optionsInput) {
      const options = normalizeCheckoutOptions(optionsInput);
      planSelect.value = options.planName;
      uiModeSelect.value = options.uiMode;
      regionSelect.value = options.region;
      workspaceInput.value = options.workspaceName;
      seatsInput.value = String(options.seatQuantity);
      setLinkSummary(options);
    }
    function readCheckoutOptions() {
      return normalizeCheckoutOptions({
        planName: planSelect.value,
        uiMode: uiModeSelect.value,
        region: regionSelect.value,
        workspaceName: workspaceInput.value,
        seatQuantity: Number(seatsInput.value || 5)
      });
    }
    function setLinkSummary(options) {
      const planText = options.planName === "chatgptteamplan" ? `Team \xB7 ${options.seatQuantity} seats` : "Plus";
      const modeText = options.uiMode === "hosted" ? "\u957F\u94FE\u63A5 hosted" : "\u77ED\u94FE\u63A5 custom";
      const sessionText = sessionFetchedOnce ? "session \u5DF2\u8BF7\u6C42" : "session \u5F85\u8BFB\u53D6";
      linkSummary.textContent = `${planText} \xB7 ${modeText} \xB7 ${options.region} \xB7 ${sessionText}`;
      teamOptions.hidden = options.planName !== "chatgptteamplan";
      regionField.hidden = options.planName === "chatgptteamplan";
    }
    function normalizeTokenInput(showError) {
      try {
        const token = extractAccessToken(tokenInput.value);
        if (tokenInput.value.trim() !== token) {
          tokenInput.value = token;
        }
        tokenHint.textContent = "\u5DF2\u672C\u5730\u63D0\u53D6 accessToken\u3002";
        tokenHint.classList.add("is-ok");
        return token;
      } catch (error) {
        tokenHint.classList.remove("is-ok");
        if (showError) {
          setStatus2(linkStatus, errorMessage5(error), "error");
        }
        return "";
      }
    }
    function setGeneratedLink(link) {
      generatedLink = link;
      linkOutput.value = link;
      copyLinkButton.disabled = !link;
      openLinkButton.disabled = !link;
    }
    function setSessionRows(email, planType, accessToken) {
      emailValue.value.textContent = email || "\u672A\u8BFB\u53D6";
      planValue.value.textContent = planType || "\u672A\u8BFB\u53D6";
      tokenValue.value.textContent = accessToken ? "\u5DF2\u83B7\u53D6" : "\u672A\u83B7\u53D6";
    }
  }
  function createSessionRow(label, initialValue) {
    const row = document.createElement("div");
    row.className = "opx-session-row";
    const labelElement = document.createElement("span");
    labelElement.textContent = label;
    const value = document.createElement("strong");
    value.textContent = initialValue;
    row.append(labelElement, value);
    return { row, value };
  }
  function createButton2(label, className = "opx-button") {
    const button = document.createElement("button");
    button.className = className;
    button.type = "button";
    button.textContent = label;
    return button;
  }
  function createInput(placeholder, type) {
    const input = document.createElement("input");
    input.className = "opx-input";
    input.type = type;
    input.placeholder = placeholder;
    return input;
  }
  function createSelect(options) {
    const select = document.createElement("select");
    select.className = "opx-select";
    for (const [value, label] of options) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = label;
      select.append(option);
    }
    return select;
  }
  function createField2(label, control) {
    const field = document.createElement("label");
    field.className = "opx-field";
    const caption = document.createElement("span");
    caption.className = "opx-label";
    caption.textContent = label;
    field.append(caption, control);
    return field;
  }
  function setStatus2(element, message, type) {
    element.textContent = message;
    element.dataset.type = type;
  }
  function errorMessage5(error) {
    return error instanceof Error ? error.message : String(error);
  }
  function isCheckoutLinkResponse(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }
  function isChatGptSessionResponse(value) {
    return Boolean(
      value && typeof value === "object" && typeof value.ok === "boolean" && typeof value.message === "string"
    );
  }

  // src/features/register/panel.ts
  function createRegisterPanel(container, controller) {
    const accountInput = document.createElement("textarea");
    accountInput.className = "opx-textarea";
    accountInput.placeholder = "\u90AE\u7BB1\u6216 Outlook \u884C";
    accountInput.autocomplete = "off";
    accountInput.spellcheck = false;
    const inputHint = document.createElement("div");
    inputHint.className = "opx-hint";
    inputHint.textContent = "\u652F\u6301 user@example.com \u6216 email----password----client_id----refresh_token";
    const emailButton = createButton3("\u586B\u5165\u90AE\u7BB1\u5E76\u7EE7\u7EED");
    const otp = document.createElement("input");
    otp.className = "opx-input";
    otp.type = "text";
    otp.inputMode = "numeric";
    otp.placeholder = "\u9A8C\u8BC1\u7801";
    otp.autocomplete = "one-time-code";
    const otpButton = createButton3("\u586B\u5165\u9A8C\u8BC1\u7801\u5E76\u7EE7\u7EED");
    const autoOtpButton = createButton3("\u81EA\u52A8\u63A5\u6536\u5E76\u586B\u5165\u9A8C\u8BC1\u7801", "opx-button opx-button-secondary");
    const profileButton = createButton3("\u586B\u5199\u8D44\u6599\u5E76\u521B\u5EFA");
    const status = document.createElement("div");
    status.className = "opx-status";
    status.textContent = "\u7B49\u5F85\u64CD\u4F5C";
    const update = async () => {
      const page = controller.getPageState();
      const saved = await controller.loadState();
      if (accountInput.value !== saved.rawInput) {
        accountInput.value = saved.rawInput;
      }
      emailButton.disabled = !page.canFillEmail;
      otpButton.disabled = !page.canFillOtp;
      autoOtpButton.disabled = !page.canFillOtp || !saved.autoOtp;
      profileButton.disabled = !page.canFillProfile;
      inputHint.textContent = saved.autoOtp ? "Outlook \u884C\u6A21\u5F0F\uFF1A\u9A8C\u8BC1\u7801\u9875\u4F1A\u901A\u8FC7\u672C\u5730 API \u81EA\u52A8\u6536\u7801" : "\u5355\u90AE\u7BB1\u6A21\u5F0F\uFF1A\u9A8C\u8BC1\u7801\u9700\u8981\u624B\u52A8\u8F93\u5165";
    };
    accountInput.addEventListener("input", async () => {
      const saved = await controller.saveInput(accountInput.value);
      inputHint.textContent = saved.autoOtp ? "Outlook \u884C\u6A21\u5F0F\uFF1A\u9A8C\u8BC1\u7801\u9875\u4F1A\u901A\u8FC7\u672C\u5730 API \u81EA\u52A8\u6536\u7801" : "\u5355\u90AE\u7BB1\u6A21\u5F0F\uFF1A\u9A8C\u8BC1\u7801\u9700\u8981\u624B\u52A8\u8F93\u5165";
    });
    emailButton.addEventListener("click", async () => {
      setStatus3(status, "\u6B63\u5728\u63D0\u4EA4\u90AE\u7BB1...", "pending");
      await controller.saveInput(accountInput.value);
      setResult(status, await controller.fillEmailFromInput());
      await update();
    });
    otpButton.addEventListener("click", async () => {
      setStatus3(status, "\u6B63\u5728\u63D0\u4EA4\u9A8C\u8BC1\u7801...", "pending");
      setResult(status, await controller.fillOtp(otp.value));
      await update();
    });
    autoOtpButton.addEventListener("click", async () => {
      setStatus3(status, "\u7B49\u5F85 Outlook \u9A8C\u8BC1\u7801...", "pending");
      setResult(status, await controller.waitForOutlookOtp());
      await update();
    });
    profileButton.addEventListener("click", async () => {
      setStatus3(status, "\u6B63\u5728\u586B\u5199\u8D44\u6599...", "pending");
      setResult(status, await controller.fillProfileAndCreate());
      await update();
    });
    container.append(accountInput, inputHint, emailButton, otp, otpButton, autoOtpButton, profileButton, status);
    void update();
    return { update };
  }
  function createButton3(label, className = "opx-button") {
    const button = document.createElement("button");
    button.className = className;
    button.type = "button";
    button.textContent = label;
    return button;
  }
  function setResult(element, result) {
    setStatus3(element, result.message, result.ok ? "ok" : "error");
  }
  function setStatus3(element, message, type) {
    element.textContent = message;
    element.dataset.type = type;
  }

  // src/features/version-check/state.ts
  var STORAGE_KEY3 = "opx.versionCheck.state";
  var DEFAULT_STATE2 = {
    ignoredVersion: "",
    lastCheckedAt: 0,
    latest: null
  };
  async function loadVersionCheckState() {
    const data = await browser.storage.local.get(STORAGE_KEY3);
    return normalizeVersionCheckState(data[STORAGE_KEY3]);
  }
  async function saveVersionCheckState(patch) {
    const current = await loadVersionCheckState();
    const next = normalizeVersionCheckState({
      ...current,
      ...patch
    });
    await browser.storage.local.set({ [STORAGE_KEY3]: next });
    return next;
  }
  async function ignoreReleaseVersion(version) {
    return saveVersionCheckState({ ignoredVersion: normalizeVersion(version) });
  }
  function normalizeVersionCheckState(value) {
    const source = isRecord4(value) ? value : {};
    return {
      ignoredVersion: normalizeVersion(source.ignoredVersion),
      lastCheckedAt: Number(source.lastCheckedAt || DEFAULT_STATE2.lastCheckedAt),
      latest: normalizeReleaseVersionInfo(source.latest)
    };
  }
  function normalizeReleaseVersionInfo(value) {
    if (!isRecord4(value)) {
      return null;
    }
    const version = normalizeVersion(value.version);
    const htmlUrl = String(value.htmlUrl || "").trim();
    if (!version || !htmlUrl) {
      return null;
    }
    return {
      version,
      tagName: String(value.tagName || version).trim(),
      name: String(value.name || value.tagName || version).trim(),
      body: String(value.body || "").trim(),
      htmlUrl,
      downloadUrl: String(value.downloadUrl || htmlUrl).trim(),
      publishedAt: String(value.publishedAt || "").trim()
    };
  }
  function normalizeVersion(value) {
    return String(value || "").trim().replace(/^v/i, "");
  }
  function isRecord4(value) {
    return Boolean(value && typeof value === "object");
  }

  // src/features/version-check/github.ts
  var LATEST_RELEASE_API = "https://api.github.com/repos/suyancc/openai-plus-vxt/releases/latest";
  var CHECK_INTERVAL_MS = 30 * 60 * 1e3;
  async function checkLatestVersion(force = false) {
    const currentVersion = normalizeVersion2(browser.runtime.getManifest().version);
    const state = await loadVersionCheckState();
    if (!force && state.latest && Date.now() - state.lastCheckedAt < CHECK_INTERVAL_MS) {
      return buildResult(currentVersion, state.latest, state.ignoredVersion);
    }
    try {
      const response = await fetch(LATEST_RELEASE_API, {
        headers: {
          Accept: "application/vnd.github+json"
        },
        cache: "no-store"
      });
      if (response.status === 404) {
        await saveVersionCheckState({ latest: null, lastCheckedAt: Date.now() });
        return {
          currentVersion,
          latest: null,
          updateAvailable: false,
          ignored: false,
          error: "\u5F53\u524D\u4ED3\u5E93\u8FD8\u6CA1\u6709 GitHub Release"
        };
      }
      if (!response.ok) {
        throw new Error(`GitHub API ${response.status}`);
      }
      const release = await response.json();
      const latest = normalizeRelease(release);
      await saveVersionCheckState({ latest, lastCheckedAt: Date.now() });
      return buildResult(currentVersion, latest, state.ignoredVersion);
    } catch (error) {
      return {
        currentVersion,
        latest: state.latest,
        updateAvailable: Boolean(state.latest && compareVersions(state.latest.version, currentVersion) > 0),
        ignored: Boolean(state.latest && state.ignoredVersion === state.latest.version),
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
  function compareVersions(left, right) {
    const a = normalizeVersion2(left).split(".").map(toNumber);
    const b = normalizeVersion2(right).split(".").map(toNumber);
    const length = Math.max(a.length, b.length);
    for (let index = 0; index < length; index += 1) {
      const diff = (a[index] || 0) - (b[index] || 0);
      if (diff !== 0) {
        return diff > 0 ? 1 : -1;
      }
    }
    return 0;
  }
  function buildResult(currentVersion, latest, ignoredVersion) {
    const updateAvailable = Boolean(latest && compareVersions(latest.version, currentVersion) > 0);
    const ignored = Boolean(latest && ignoredVersion === latest.version);
    return {
      currentVersion,
      latest,
      updateAvailable,
      ignored
    };
  }
  function normalizeRelease(release) {
    const tagName = String(release.tag_name || "").trim();
    const version = normalizeVersion2(tagName);
    const htmlUrl = String(release.html_url || "").trim();
    if (!version || !htmlUrl) {
      return null;
    }
    const assetUrl = release.assets?.find((asset) => {
      const name = String(asset.name || "").toLowerCase();
      return name.endsWith(".zip") && name.includes("chrome");
    })?.browser_download_url || release.assets?.find((asset) => String(asset.name || "").toLowerCase().endsWith(".zip"))?.browser_download_url;
    return {
      version,
      tagName,
      name: String(release.name || tagName).trim(),
      body: String(release.body || "").trim(),
      htmlUrl,
      downloadUrl: String(assetUrl || htmlUrl).trim(),
      publishedAt: String(release.published_at || "").trim()
    };
  }
  function normalizeVersion2(value) {
    return value.trim().replace(/^v/i, "");
  }
  function toNumber(value) {
    const parsed = Number.parseInt(value.replace(/\D.*$/, ""), 10);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  // src/features/settings/panel.ts
  init_state();
  var TG_GROUP_URL = "https://t.me/fuck_open";
  function createSettingsDialog(options = {}) {
    const overlay = document.createElement("div");
    overlay.className = "opx-settings-overlay";
    overlay.hidden = true;
    const dialog = document.createElement("section");
    dialog.className = "opx-settings-dialog";
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-label", "\u63D2\u4EF6\u8BBE\u7F6E");
    const header = document.createElement("div");
    header.className = "opx-settings-header";
    const titleGroup = document.createElement("div");
    titleGroup.className = "opx-settings-title";
    const title = document.createElement("strong");
    title.textContent = "\u8BBE\u7F6E";
    const version = document.createElement("span");
    version.className = "opx-version-badge";
    version.textContent = `v${browser.runtime.getManifest().version}`;
    const closeButton = createIconButton("\xD7", "\u5173\u95ED\u8BBE\u7F6E");
    titleGroup.append(title, version);
    header.append(titleGroup, closeButton);
    const payOpenAiCheckbox = document.createElement("input");
    payOpenAiCheckbox.type = "checkbox";
    payOpenAiCheckbox.className = "opx-checkbox";
    const payPalSignupCheckbox = document.createElement("input");
    payPalSignupCheckbox.type = "checkbox";
    payPalSignupCheckbox.className = "opx-checkbox";
    const payOpenAiItem = createSettingItem(
      payOpenAiCheckbox,
      "OpenAI \u652F\u4ED8\u9875\u81EA\u52A8\u586B\u5199",
      "\u7528\u4E8E pay.openai.com/c/pay \u9875\u9762\uFF0C\u586B\u5199\u59D3\u540D\u3001\u56FD\u5BB6\u3001\u5730\u5740\u3001\u90AE\u7F16\u3001\u7535\u8BDD\u5E76\u52FE\u9009\u6761\u6B3E\u3002"
    );
    const payPalSignupItem = createSettingItem(
      payPalSignupCheckbox,
      "PayPal \u6CE8\u518C\u9875\u81EA\u52A8\u586B\u5199",
      "\u7528\u4E8E paypal.com/checkoutweb/signup \u9875\u9762\uFF0C\u586B\u5199\u56FD\u5BB6\u3001\u90AE\u7BB1\u3001\u5361\u8D44\u6599\u3001\u59D3\u540D\u3001\u5730\u5740\u548C\u5BC6\u7801\u63D0\u793A\u3002"
    );
    const checkUpdateButton = document.createElement("button");
    checkUpdateButton.className = "opx-external-link-button";
    checkUpdateButton.type = "button";
    checkUpdateButton.title = "\u7ACB\u5373\u68C0\u67E5 GitHub Release \u6700\u65B0\u7248\u672C";
    checkUpdateButton.textContent = "\u68C0\u6D4B\u66F4\u65B0";
    const tgGroupButton = document.createElement("button");
    tgGroupButton.className = "opx-external-link-button";
    tgGroupButton.type = "button";
    tgGroupButton.title = "\u6253\u5F00 TG \u7FA4\u7EC4";
    tgGroupButton.append(createTelegramIcon(), document.createTextNode("TG \u7FA4\u7EC4\uFF1At.me/fuck_open"));
    const hint = document.createElement("div");
    hint.className = "opx-hint";
    hint.textContent = "\u56FD\u5BB6\u3001\u57CE\u5E02\u548C\u83B7\u53D6\u5730\u5740\u5728\u201C\u5730\u5740\u201Dtab \u4E2D\u64CD\u4F5C\u3002";
    const status = document.createElement("div");
    status.className = "opx-status";
    dialog.append(header, payOpenAiItem, payPalSignupItem, checkUpdateButton, tgGroupButton, hint, status);
    overlay.append(dialog);
    closeButton.addEventListener("click", close);
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) {
        close();
      }
    });
    payOpenAiCheckbox.addEventListener("change", async () => {
      await saveAddressAutofillSettings({ payOpenAiEnabled: payOpenAiCheckbox.checked });
      setStatus4(status, "\u8BBE\u7F6E\u5DF2\u4FDD\u5B58", "ok");
    });
    payPalSignupCheckbox.addEventListener("change", async () => {
      await saveAddressAutofillSettings({ payPalSignupEnabled: payPalSignupCheckbox.checked });
      setStatus4(status, "\u8BBE\u7F6E\u5DF2\u4FDD\u5B58", "ok");
    });
    tgGroupButton.addEventListener("click", () => {
      window.open(TG_GROUP_URL, "_blank", "noopener,noreferrer");
    });
    checkUpdateButton.addEventListener("click", async () => {
      checkUpdateButton.disabled = true;
      setStatus4(status, "\u6B63\u5728\u68C0\u6D4B GitHub \u6700\u65B0\u7248\u672C...", "pending");
      try {
        const result = await checkLatestVersion(true);
        await options.onVersionChecked?.();
        if (result.latest && result.updateAvailable) {
          setStatus4(status, `\u53D1\u73B0\u65B0\u7248\u672C v${result.latest.version}\uFF0C\u9876\u90E8\u5DF2\u663E\u793A\u66F4\u65B0\u63D0\u793A`, "ok");
        } else if (result.latest) {
          setStatus4(status, `\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\u672C v${result.currentVersion}`, "ok");
        } else {
          setStatus4(status, result.error || "\u6682\u672A\u627E\u5230\u53EF\u7528 Release", "pending");
        }
      } catch (error) {
        setStatus4(status, error instanceof Error ? error.message : String(error), "error");
      } finally {
        checkUpdateButton.disabled = false;
      }
    });
    const update = async () => {
      const settings = await loadAddressAutofillSettings();
      payOpenAiCheckbox.checked = settings.payOpenAiEnabled;
      payPalSignupCheckbox.checked = settings.payPalSignupEnabled;
      const enabledCount = Number(settings.payOpenAiEnabled) + Number(settings.payPalSignupEnabled);
      setStatus4(status, enabledCount > 0 ? `\u5DF2\u5F00\u542F ${enabledCount} \u9879\u81EA\u52A8\u586B\u5199` : "\u81EA\u52A8\u586B\u5199\u672A\u5F00\u542F", enabledCount > 0 ? "ok" : "pending");
    };
    return {
      element: overlay,
      open: () => {
        overlay.hidden = false;
        void update();
      },
      update
    };
    function close() {
      overlay.hidden = true;
    }
  }
  function createSettingItem(checkbox, title, description) {
    const item = document.createElement("div");
    item.className = "opx-setting-item";
    const label = document.createElement("label");
    label.className = "opx-check-row";
    const titleElement = document.createElement("span");
    titleElement.textContent = title;
    label.append(checkbox, titleElement);
    const descriptionElement = document.createElement("div");
    descriptionElement.className = "opx-setting-description";
    descriptionElement.textContent = description;
    item.append(label, descriptionElement);
    return item;
  }
  function createTelegramIcon() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.classList.add("opx-telegram-icon");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("fill", "currentColor");
    path.setAttribute("d", "M21.9 4.3 18.7 19c-.2 1-.8 1.2-1.6.8l-4.6-3.4-2.2 2.1c-.2.2-.4.4-.9.4l.3-4.7 8.5-7.7c.4-.3-.1-.5-.6-.2L7.1 12.9 2.6 11.5c-1-.3-1-1 0-1.4L20.2 3.3c.8-.3 1.5.2 1.7 1Z");
    svg.append(path);
    return svg;
  }
  function createIconButton(label, title) {
    const button = document.createElement("button");
    button.className = "opx-icon-button";
    button.type = "button";
    button.textContent = label;
    button.title = title;
    button.setAttribute("aria-label", title);
    return button;
  }
  function setStatus4(element, message, type) {
    element.textContent = message;
    element.dataset.type = type;
  }

  // src/features/sms/panel.ts
  var POLL_INTERVAL_MS2 = 3e3;
  function createSmsPanel(container) {
    const summary = document.createElement("div");
    summary.className = "opx-summary";
    const input = document.createElement("textarea");
    input.className = "opx-textarea opx-sms-input";
    input.placeholder = "+14642649811----https://xxxx.com/xxx\n\u6BCF\u884C\u4E00\u4E2A\u53F7\u7801\u548C API \u94FE\u63A5";
    input.autocomplete = "off";
    input.spellcheck = false;
    const buttonRow = document.createElement("div");
    buttonRow.className = "opx-button-row opx-sms-actions";
    const saveButton = createButton4("\u4FDD\u5B58\u5E76\u5F00\u59CB");
    const pollNowButton = createButton4("\u7ACB\u5373\u83B7\u53D6", "opx-button opx-button-secondary");
    const clearHistoryButton = createButton4("\u6E05\u7A7A\u5386\u53F2", "opx-button opx-button-secondary");
    buttonRow.append(saveButton, pollNowButton, clearHistoryButton);
    const targetTitle = createTitle("\u5F53\u524D\u53F7\u7801");
    const targetList = document.createElement("div");
    targetList.className = "opx-sms-targets";
    const historyTitle = createTitle("\u9A8C\u8BC1\u7801\u5386\u53F2");
    const historyTable = document.createElement("div");
    historyTable.className = "opx-sms-table";
    const status = document.createElement("div");
    status.className = "opx-status";
    const runtimeById = /* @__PURE__ */ new Map();
    let currentState = null;
    let pollTimer2 = null;
    let lastSavedInput = "";
    let inputSaveTimer = null;
    let inputFocused = false;
    container.append(
      summary,
      createField3("\u63A5\u7801\u4FE1\u606F", input),
      buttonRow,
      targetTitle,
      targetList,
      historyTitle,
      historyTable,
      status
    );
    input.addEventListener("input", () => {
      scheduleInputSave();
      renderTargetsFromInput();
    });
    input.addEventListener("focus", () => {
      inputFocused = true;
    });
    input.addEventListener("blur", () => {
      inputFocused = false;
      void persistInputNow();
    });
    saveButton.addEventListener("click", async () => {
      await persistInputNow();
      renderTargetsFromInput();
      await pollAllTargets();
    });
    pollNowButton.addEventListener("click", async () => {
      await persistInputNow();
      renderTargetsFromInput();
      await pollAllTargets();
    });
    clearHistoryButton.addEventListener("click", async () => {
      const next = await saveSmsRelayState({ history: [] });
      currentState = next;
      renderHistory(next.history);
      setStatus5(status, "\u9A8C\u8BC1\u7801\u5386\u53F2\u5DF2\u6E05\u7A7A\uFF0C\u8F93\u5165\u5185\u5BB9\u5DF2\u4FDD\u7559\u3002", "ok");
    });
    const update = async () => {
      const state = await loadSmsRelayState();
      currentState = state;
      if (!inputFocused && input.value !== state.rawInput) {
        input.value = state.rawInput;
        lastSavedInput = state.rawInput;
        renderTargetsFromInput();
      }
      renderHistory(state.history);
      renderSummary();
    };
    const onShow = async () => {
      await update();
      ensurePolling();
    };
    void update();
    return { update, onShow };
    function scheduleInputSave() {
      if (inputSaveTimer) {
        window.clearTimeout(inputSaveTimer);
      }
      inputSaveTimer = window.setTimeout(() => void persistInputNow(), 450);
    }
    async function persistInputNow() {
      if (inputSaveTimer) {
        window.clearTimeout(inputSaveTimer);
        inputSaveTimer = null;
      }
      const rawInput = input.value;
      if (rawInput === lastSavedInput) {
        return;
      }
      currentState = await saveSmsRelayState({ rawInput });
      lastSavedInput = rawInput;
      renderSummary();
    }
    function ensurePolling() {
      if (pollTimer2 !== null) {
        return;
      }
      pollTimer2 = window.setInterval(() => void pollAllTargets(), POLL_INTERVAL_MS2);
    }
    function renderTargetsFromInput() {
      const parsed = parseSmsRelayTargets(input.value);
      const nextIds = new Set(parsed.targets.map((target) => target.id));
      for (const [id] of runtimeById) {
        if (!nextIds.has(id)) {
          runtimeById.delete(id);
        }
      }
      for (const target of parsed.targets) {
        const current = runtimeById.get(target.id);
        if (current) {
          current.target = target;
        } else {
          runtimeById.set(target.id, {
            target,
            status: "waiting",
            message: "\u7B49\u5F85\u83B7\u53D6",
            code: "",
            lastCheckedAt: 0,
            inFlight: false
          });
        }
      }
      targetList.textContent = "";
      if (!parsed.targets.length) {
        targetList.append(createEmpty2(parsed.errors[0] || "\u6682\u65E0\u53F7\u7801\uFF0C\u6309\u6BCF\u884C\u201C\u53F7\u7801----API\u94FE\u63A5\u201D\u8F93\u5165\u3002"));
      } else {
        for (const target of parsed.targets) {
          const runtime = runtimeById.get(target.id);
          if (runtime) {
            targetList.append(createTargetRow(runtime));
          }
        }
      }
      if (parsed.errors.length) {
        setStatus5(status, parsed.errors.join("\uFF1B"), "error");
      } else if (parsed.targets.length) {
        setStatus5(status, `\u5DF2\u52A0\u8F7D ${parsed.targets.length} \u4E2A\u63A5\u7801\u94FE\u63A5\uFF0C\u6BCF 3 \u79D2\u81EA\u52A8\u83B7\u53D6\u3002`, "pending");
      } else {
        setStatus5(status, "\u8F93\u5165\u5185\u5BB9\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002", "pending");
      }
      renderSummary();
    }
    function renderSummary() {
      const parsed = parseSmsRelayTargets(input.value);
      const historyCount = currentState?.history.length || 0;
      const foundCount = [...runtimeById.values()].filter((item) => item.code).length;
      summary.textContent = `${parsed.targets.length} \u4E2A\u63A5\u7801\u94FE\u63A5 \xB7 ${foundCount} \u4E2A\u5F53\u524D\u9A8C\u8BC1\u7801 \xB7 ${historyCount} \u6761\u5386\u53F2`;
    }
    async function pollAllTargets() {
      const parsed = parseSmsRelayTargets(input.value);
      if (!parsed.targets.length || parsed.errors.length) {
        return;
      }
      await persistInputNow();
      await Promise.all(parsed.targets.map((target) => pollTarget(target)));
      renderTargetsFromInput();
      renderHistory(currentState?.history || []);
    }
    async function pollTarget(target) {
      const runtime = runtimeById.get(target.id);
      if (!runtime || runtime.inFlight) {
        return;
      }
      runtime.inFlight = true;
      runtime.status = runtime.code ? "found" : "waiting";
      runtime.message = "\u6B63\u5728\u83B7\u53D6...";
      renderTargetsFromInput();
      const result = await fetchSmsRelayCode(target);
      runtime.inFlight = false;
      runtime.lastCheckedAt = Date.now();
      if (result.kind === "code") {
        runtime.status = "found";
        runtime.code = result.code;
        runtime.message = result.message;
        await appendCodeHistory(target.phone, result.code, result.message);
        setStatus5(status, `${target.phone} \u6536\u5230\u9A8C\u8BC1\u7801 ${result.code}`, "ok");
        return;
      }
      if (result.kind === "error") {
        runtime.status = "error";
        runtime.message = result.message;
        setStatus5(status, `${target.phone} \u83B7\u53D6\u5931\u8D25\uFF1A${result.message}`, "error");
        return;
      }
      runtime.status = "waiting";
      runtime.message = result.message;
    }
    async function appendCodeHistory(phone, code, message) {
      const state = currentState || await loadSmsRelayState();
      const exists = state.history.some((item) => item.phone === phone && item.code === code && item.message === message);
      if (exists) {
        currentState = state;
        return;
      }
      const record = {
        id: `${phone}-${code}-${Date.now()}`,
        phone,
        code,
        message,
        receivedAt: Date.now()
      };
      const nextHistory = [record, ...state.history].slice(0, 80);
      currentState = await saveSmsRelayState({ history: nextHistory });
    }
    function createTargetRow(runtime) {
      const row = document.createElement("div");
      row.className = "opx-sms-target-row";
      row.dataset.status = runtime.status;
      const main = document.createElement("div");
      main.className = "opx-sms-target-main";
      const phone = document.createElement("strong");
      phone.textContent = runtime.target.phone;
      const detail = document.createElement("span");
      detail.textContent = runtime.code ? runtime.message : runtime.message || "\u7B49\u5F85\u83B7\u53D6";
      main.append(phone, detail);
      const codeButton = document.createElement("button");
      codeButton.className = "opx-sms-code-chip";
      codeButton.type = "button";
      codeButton.textContent = runtime.code || (runtime.inFlight ? "..." : "\u7B49\u5F85");
      codeButton.disabled = !runtime.code;
      codeButton.title = runtime.code ? "\u70B9\u51FB\u590D\u5236\u9A8C\u8BC1\u7801" : "\u5C1A\u672A\u6536\u5230\u9A8C\u8BC1\u7801";
      codeButton.addEventListener("click", () => void copyCode(runtime.code, codeButton));
      row.append(main, codeButton);
      return row;
    }
    function renderHistory(history) {
      historyTable.textContent = "";
      const header = document.createElement("div");
      header.className = "opx-sms-table-row opx-sms-table-head";
      header.append(createCell("\u53F7\u7801"), createCell("\u9A8C\u8BC1\u7801"), createCell("\u65F6\u95F4"));
      historyTable.append(header);
      if (!history.length) {
        const empty = document.createElement("div");
        empty.className = "opx-empty-inline";
        empty.textContent = "\u6682\u65E0\u9A8C\u8BC1\u7801\u5386\u53F2\u3002";
        historyTable.append(empty);
        return;
      }
      for (const item of history) {
        const row = document.createElement("div");
        row.className = "opx-sms-table-row";
        const codeButton = document.createElement("button");
        codeButton.className = "opx-sms-code-chip";
        codeButton.type = "button";
        codeButton.textContent = item.code;
        codeButton.title = item.message || "\u70B9\u51FB\u590D\u5236\u9A8C\u8BC1\u7801";
        codeButton.addEventListener("click", () => void copyCode(item.code, codeButton));
        row.append(
          createCell(item.phone),
          wrapCell(codeButton),
          createCell(formatTime(item.receivedAt))
        );
        historyTable.append(row);
      }
    }
    async function copyCode(code, button) {
      if (!code) {
        return;
      }
      await navigator.clipboard.writeText(code);
      const original = button.textContent || code;
      button.textContent = "\u5DF2\u590D\u5236";
      button.classList.add("is-copied");
      window.setTimeout(() => {
        button.textContent = original;
        button.classList.remove("is-copied");
      }, 1200);
    }
  }
  function createField3(label, control) {
    const field = document.createElement("label");
    field.className = "opx-field";
    const caption = document.createElement("span");
    caption.className = "opx-label";
    caption.textContent = label;
    field.append(caption, control);
    return field;
  }
  function createButton4(label, className = "opx-button") {
    const button = document.createElement("button");
    button.className = className;
    button.type = "button";
    button.textContent = label;
    return button;
  }
  function createTitle(text) {
    const title = document.createElement("div");
    title.className = "opx-section-title";
    title.textContent = text;
    return title;
  }
  function createEmpty2(text) {
    const item = document.createElement("div");
    item.className = "opx-empty-inline";
    item.textContent = text;
    return item;
  }
  function createCell(text) {
    const cell = document.createElement("div");
    cell.className = "opx-sms-table-cell";
    cell.textContent = text;
    return cell;
  }
  function wrapCell(content) {
    const cell = document.createElement("div");
    cell.className = "opx-sms-table-cell";
    cell.append(content);
    return cell;
  }
  function setStatus5(element, message, type) {
    element.textContent = message;
    element.dataset.type = type;
  }
  function formatTime(value) {
    if (!value) {
      return "-";
    }
    return new Date(value).toLocaleTimeString("zh-CN", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  }

  // src/features/version-check/panel.ts
  function createVersionNotice() {
    const notice = document.createElement("section");
    notice.className = "opx-version-notice";
    notice.hidden = true;
    const title = document.createElement("div");
    title.className = "opx-version-notice-title";
    const body = document.createElement("div");
    body.className = "opx-version-notice-body";
    const actions = document.createElement("div");
    actions.className = "opx-version-notice-actions";
    const downloadButton = document.createElement("button");
    downloadButton.className = "opx-mini-button";
    downloadButton.type = "button";
    downloadButton.textContent = "\u4E0B\u8F7D\u66F4\u65B0";
    const releaseButton = document.createElement("button");
    releaseButton.className = "opx-mini-button opx-mini-button-secondary";
    releaseButton.type = "button";
    releaseButton.textContent = "\u66F4\u65B0\u8BF4\u660E";
    const ignoreButton = document.createElement("button");
    ignoreButton.className = "opx-mini-button opx-mini-button-secondary";
    ignoreButton.type = "button";
    ignoreButton.textContent = "\u5FFD\u7565";
    actions.append(downloadButton, releaseButton, ignoreButton);
    notice.append(title, body, actions);
    let latest = null;
    downloadButton.addEventListener("click", () => {
      if (latest?.downloadUrl) {
        window.open(latest.downloadUrl, "_blank", "noopener,noreferrer");
      }
    });
    releaseButton.addEventListener("click", () => {
      if (latest?.htmlUrl) {
        window.open(latest.htmlUrl, "_blank", "noopener,noreferrer");
      }
    });
    ignoreButton.addEventListener("click", async () => {
      if (!latest) {
        return;
      }
      await ignoreReleaseVersion(latest.version);
      notice.hidden = true;
    });
    const update = async (force = false) => {
      const result = await checkLatestVersion(force);
      latest = result.latest;
      renderResult(result, notice, title, body);
    };
    return {
      element: notice,
      update
    };
  }
  function renderResult(result, notice, title, body) {
    if (!result.latest || !result.updateAvailable || result.ignored) {
      notice.hidden = true;
      return;
    }
    title.textContent = `\u53D1\u73B0\u65B0\u7248\u672C v${result.latest.version}`;
    body.textContent = buildBody(result.currentVersion, result.latest);
    notice.hidden = false;
  }
  function buildBody(currentVersion, latest) {
    const notes = latest.body.split(/\r?\n/).map((line) => line.replace(/^#+\s*/, "").trim()).filter(Boolean).slice(0, 2).join(" / ");
    const prefix = `\u5F53\u524D v${currentVersion}\uFF0C\u6700\u65B0 ${latest.tagName || `v${latest.version}`}`;
    return notes ? `${prefix}\u3002${notes}` : prefix;
  }

  // src/app/styles.ts
  var PANEL_STYLES = `
:host {
  all: initial;
  color-scheme: light dark;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.opx-shell {
  position: fixed;
  top: 72px;
  right: 0;
  z-index: 2147483647;
  display: flex;
  align-items: flex-start;
  max-height: calc(100vh - 88px);
}

.opx-panel {
  box-sizing: border-box;
  width: min(320px, calc(100vw - 42px));
  max-height: calc(100vh - 88px);
  margin-right: 18px;
  padding: 10px;
  border: 1px solid rgba(54, 211, 153, 0.28);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.32);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-color: rgba(47, 209, 124, 0.55) rgba(15, 23, 42, 0.72);
  scrollbar-width: thin;
}

.opx-panel::-webkit-scrollbar {
  width: 8px;
}

.opx-panel::-webkit-scrollbar-track {
  background: rgba(15, 23, 42, 0.72);
  border-radius: 999px;
}

.opx-panel::-webkit-scrollbar-thumb {
  background: rgba(47, 209, 124, 0.55);
  border-radius: 999px;
}

.opx-collapse-toggle {
  box-sizing: border-box;
  width: 32px;
  min-height: 64px;
  margin: 8px 0 0 0;
  padding: 8px 6px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-right: 0;
  border-radius: 8px 0 0 8px;
  background: #0b1220;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 14px;
  writing-mode: vertical-rl;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.28);
}

.opx-shell.is-collapsed .opx-panel {
  display: none;
}

.opx-shell.is-collapsed .opx-collapse-toggle {
  margin-right: 0;
  border-radius: 8px 0 0 8px;
  background: #102019;
}

.opx-topbar {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 34px;
  gap: 6px;
  align-items: stretch;
  margin-bottom: 8px;
}

.opx-tabs {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 4px;
  margin-bottom: 0;
  padding: 3px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 8px;
  background: rgba(15, 23, 42, 0.8);
}

.opx-tab {
  height: 30px;
  min-width: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 650;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-tab.is-active {
  background: #2fd17c;
  color: #04130a;
}

.opx-icon-button {
  box-sizing: border-box;
  width: 34px;
  height: 36px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-radius: 8px;
  background: #111827;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 17px;
  font-weight: 700;
  line-height: 1;
}

.opx-icon-button:hover {
  border-color: rgba(47, 209, 124, 0.74);
  color: #bbf7d0;
}

.opx-state {
  margin: 0 0 8px;
  color: #93e4bd;
  font-size: 12px;
  line-height: 16px;
}

.opx-version-notice {
  display: grid;
  gap: 7px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.42);
  border-radius: 7px;
  background: rgba(47, 209, 124, 0.1);
  color: #dcfce7;
}

.opx-version-notice[hidden] {
  display: none;
}

.opx-version-notice-title {
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 800;
  line-height: 16px;
}

.opx-version-notice-body {
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

.opx-version-notice-actions {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 54px;
  gap: 5px;
}

.opx-mini-button {
  box-sizing: border-box;
  min-width: 0;
  height: 28px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 11px;
  font-weight: 750;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-mini-button-secondary {
  border: 1px solid rgba(47, 209, 124, 0.34);
  background: rgba(15, 23, 42, 0.72);
  color: #93e4bd;
}

.opx-view {
  display: block;
}

.opx-view[hidden] {
  display: none;
}

.opx-empty-view {
  min-height: 84px;
  display: grid;
  place-items: center;
  border: 1px dashed rgba(148, 163, 184, 0.28);
  border-radius: 8px;
  color: #94a3b8;
  font-size: 13px;
}

.opx-input,
.opx-select,
.opx-textarea {
  box-sizing: border-box;
  width: 100%;
  height: 36px;
  margin: 0 0 8px;
  padding: 0 10px;
  border: 1px solid rgba(148, 163, 184, 0.32);
  border-radius: 6px;
  background: #111827;
  color: #e5f7ef;
  font: inherit;
  font-size: 13px;
  outline: none;
}

.opx-select {
  appearance: none;
}

.opx-textarea {
  min-height: 72px;
  max-height: 140px;
  padding: 9px 10px;
  resize: vertical;
  line-height: 18px;
}

.opx-input:focus,
.opx-select:focus,
.opx-textarea:focus {
  border-color: #2fd17c;
}

.opx-hint {
  margin: -2px 0 8px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-hint.is-ok {
  color: #86efac;
}

.opx-summary {
  margin: 0 0 8px;
  padding: 7px 8px;
  border: 1px solid rgba(47, 209, 124, 0.28);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.08);
  color: #bbf7d0;
  font-size: 11px;
  line-height: 15px;
  word-break: break-word;
  white-space: pre-line;
}

.opx-session-card {
  display: grid;
  gap: 5px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-session-row {
  display: grid;
  grid-template-columns: 42px minmax(0, 1fr);
  gap: 6px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-session-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  word-break: break-word;
}

.opx-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 8px;
}

.opx-team-options[hidden] {
  display: none;
}

.opx-field {
  display: block;
  min-width: 0;
}

.opx-label {
  display: block;
  margin: 0 0 4px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 14px;
}

.opx-token-textarea {
  min-height: 92px;
}

.opx-output {
  min-height: 58px;
  resize: vertical;
}

.opx-button-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 6px;
}

.opx-address-actions {
  grid-template-columns: minmax(0, 1fr);
}

.opx-button {
  box-sizing: border-box;
  width: 100%;
  height: 34px;
  margin: 0 0 10px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
}

.opx-button-secondary {
  background: #182235;
  color: #93e4bd;
  border: 1px solid rgba(47, 209, 124, 0.36);
}

.opx-button:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}

.opx-status {
  min-height: 18px;
  color: #cbd5e1;
  font-size: 12px;
  line-height: 18px;
  word-break: break-word;
}

.opx-status[data-type="ok"] {
  color: #86efac;
}

.opx-status[data-type="error"] {
  color: #fca5a5;
}

.opx-settings-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: grid;
  place-items: start center;
  padding: 22px 10px;
  background: rgba(2, 6, 23, 0.58);
}

.opx-settings-overlay[hidden] {
  display: none;
}

.opx-settings-dialog {
  box-sizing: border-box;
  width: min(300px, calc(100vw - 52px));
  max-height: calc(100vh - 44px);
  overflow-y: auto;
  padding: 10px;
  border: 1px solid rgba(47, 209, 124, 0.38);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 20px 52px rgba(0, 0, 0, 0.42);
}

.opx-settings-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 0 0 10px;
  color: #bbf7d0;
  font-size: 14px;
  line-height: 18px;
}

.opx-settings-title {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}

.opx-version-badge {
  padding: 1px 6px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.08);
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 16px;
}

.opx-settings-header .opx-icon-button {
  width: 28px;
  height: 28px;
  font-size: 18px;
}

.opx-settings-dialog .opx-grid {
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
}

.opx-setting-item {
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.22);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.54);
}

.opx-setting-item .opx-check-row {
  margin-bottom: 4px;
}

.opx-setting-description {
  margin-left: 26px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-external-link-button {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  width: 100%;
  min-height: 34px;
  margin: 0 0 8px;
  padding: 8px 10px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.1);
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  text-align: left;
}

.opx-telegram-icon {
  flex: 0 0 auto;
  width: 14px;
  height: 14px;
}

.opx-external-link-button:hover {
  border-color: rgba(47, 209, 124, 0.7);
  background: rgba(47, 209, 124, 0.16);
  color: #dcfce7;
}

.opx-external-link-button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-check-row {
  display: grid;
  grid-template-columns: 18px minmax(0, 1fr);
  gap: 8px;
  align-items: center;
  margin: 0 0 10px;
  color: #e5f7ef;
  cursor: pointer;
  font-size: 12px;
  line-height: 16px;
}

.opx-checkbox {
  width: 16px;
  height: 16px;
  accent-color: #2fd17c;
}

.opx-address-summary {
  min-height: 68px;
}

.opx-settings-buttons {
  margin-top: 2px;
}

.opx-section-title {
  margin: 10px 0 6px;
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
}

.opx-copy-list {
  display: grid;
  gap: 5px;
}

.opx-copy-section {
  display: grid;
  gap: 5px;
  margin: 5px 0 1px;
}

.opx-copy-section-title {
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
}

.opx-copy-section-body {
  display: grid;
  gap: 5px;
}

.opx-accordion-section {
  overflow: hidden;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.56);
}

.opx-accordion-section summary {
  padding: 7px 8px;
  color: #93e4bd;
  cursor: pointer;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
  list-style-position: inside;
}

.opx-accordion-section .opx-copy-section-body {
  padding: 0 6px 6px;
}

.opx-copy-row,
.opx-empty-inline {
  box-sizing: border-box;
  width: 100%;
  min-height: 30px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
  color: #cbd5e1;
  font: inherit;
  font-size: 11px;
  line-height: 15px;
  text-align: left;
  word-break: break-word;
}

.opx-copy-row {
  cursor: pointer;
}

.opx-copy-row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 4px;
  align-items: start;
}

.opx-copy-row:hover {
  border-color: rgba(47, 209, 124, 0.48);
  color: #e5f7ef;
}

.opx-copy-row.is-copied {
  border-color: rgba(47, 209, 124, 0.72);
  background: rgba(47, 209, 124, 0.12);
}

.opx-copy-label {
  color: #94a3b8;
  white-space: nowrap;
}

.opx-copy-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  overflow-wrap: anywhere;
}

.opx-copy-feedback {
  align-self: start;
  padding: 1px 5px;
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.16);
  color: #86efac !important;
  font-size: 10px;
  font-weight: 700;
  line-height: 14px;
  white-space: nowrap;
}

.opx-copy-feedback[hidden] {
  display: none;
}

.opx-empty-inline {
  color: #94a3b8;
  border-style: dashed;
}

.opx-sms-input {
  min-height: 88px;
}

.opx-sms-actions {
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.86fr) minmax(0, 0.86fr);
}

.opx-sms-targets {
  display: grid;
  gap: 6px;
}

.opx-sms-target-row {
  box-sizing: border-box;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  min-height: 44px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-sms-target-row[data-status="found"] {
  border-color: rgba(47, 209, 124, 0.5);
  background: rgba(47, 209, 124, 0.1);
}

.opx-sms-target-row[data-status="error"] {
  border-color: rgba(248, 113, 113, 0.42);
  background: rgba(127, 29, 29, 0.2);
}

.opx-sms-target-main {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.opx-sms-target-main strong,
.opx-sms-target-main span {
  min-width: 0;
  overflow-wrap: anywhere;
}

.opx-sms-target-main strong {
  color: #e5f7ef;
  font-size: 12px;
  line-height: 16px;
}

.opx-sms-target-main span {
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-sms-code-chip {
  box-sizing: border-box;
  min-width: 56px;
  max-width: 92px;
  min-height: 28px;
  padding: 4px 8px;
  border: 1px solid rgba(47, 209, 124, 0.44);
  border-radius: 999px;
  background: #182235;
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-sms-code-chip:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-sms-code-chip.is-copied {
  background: #2fd17c;
  color: #04130a;
}

.opx-sms-table {
  display: grid;
  gap: 5px;
}

.opx-sms-table-row {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(64px, 0.8fr) 62px;
  gap: 6px;
  align-items: center;
  min-height: 32px;
  padding: 5px 6px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.58);
}

.opx-sms-table-head {
  min-height: 24px;
  background: transparent;
  border-color: transparent;
  color: #93e4bd;
  font-weight: 700;
}

.opx-sms-table-cell {
  min-width: 0;
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

@media (max-height: 640px) {
  .opx-shell {
    top: 12px;
    max-height: calc(100vh - 24px);
  }

  .opx-panel {
    max-height: calc(100vh - 24px);
  }
}
`;

  // src/app/panel.ts
  function createPanel(root, registerController) {
    root.innerHTML = "";
    const style = document.createElement("style");
    style.textContent = PANEL_STYLES;
    const shell = document.createElement("div");
    shell.className = "opx-shell";
    const collapseButton = document.createElement("button");
    collapseButton.className = "opx-collapse-toggle";
    collapseButton.type = "button";
    collapseButton.textContent = "\u6536\u8D77";
    collapseButton.title = "\u6536\u8D77\u4FA7\u8FB9\u680F";
    collapseButton.setAttribute("aria-expanded", "true");
    const panel = document.createElement("aside");
    panel.className = "opx-panel";
    const topbar = document.createElement("div");
    topbar.className = "opx-topbar";
    const tabs = document.createElement("div");
    tabs.className = "opx-tabs";
    const registerTab = createTab("register", "\u6CE8\u518C");
    const linkTab = createTab("link", "\u63D0\u94FE\u63A5");
    const addressTab = createTab("address", "\u5730\u5740");
    const smsTab = createTab("sms", "\u63A5\u7801");
    const autoTab = createTab("auto", "\u4E00\u952E");
    tabs.append(autoTab, registerTab, linkTab, addressTab, smsTab);
    const settingsButton = document.createElement("button");
    settingsButton.className = "opx-icon-button";
    settingsButton.type = "button";
    settingsButton.textContent = "\u2699";
    settingsButton.title = "\u6253\u5F00\u8BBE\u7F6E";
    settingsButton.setAttribute("aria-label", "\u6253\u5F00\u8BBE\u7F6E");
    const state = document.createElement("div");
    state.className = "opx-state";
    const registerView = createView();
    const linkView = createView();
    const addressView = createView();
    const smsView = createView();
    const autoView = createView();
    const handles = {
      auto: createAutoPanel(autoView),
      register: createRegisterPanel(registerView, registerController),
      link: createLinkExtractorPanel(linkView),
      address: createAddressPanel(addressView),
      sms: createSmsPanel(smsView)
    };
    const versionNotice = createVersionNotice();
    const settingsDialog = createSettingsDialog({
      onVersionChecked: () => versionNotice.update(true)
    });
    let activeTab = "auto";
    const setCollapsed = (collapsed) => {
      shell.classList.toggle("is-collapsed", collapsed);
      collapseButton.textContent = collapsed ? "\u5C55\u5F00" : "\u6536\u8D77";
      collapseButton.title = collapsed ? "\u5C55\u5F00\u4FA7\u8FB9\u680F" : "\u6536\u8D77\u4FA7\u8FB9\u680F";
      collapseButton.setAttribute("aria-expanded", collapsed ? "false" : "true");
    };
    const setActiveTab = async (tab) => {
      if (!isFeatureTab(tab)) {
        return;
      }
      activeTab = tab;
      await saveActiveTab(tab);
      renderActiveTab();
      await handles[tab].onShow?.();
      await updateState();
    };
    const renderActiveTab = () => {
      for (const item of [autoTab, registerTab, linkTab, addressTab, smsTab]) {
        item.classList.toggle("is-active", item.dataset.tab === activeTab);
      }
      autoView.hidden = activeTab !== "auto";
      registerView.hidden = activeTab !== "register";
      linkView.hidden = activeTab !== "link";
      addressView.hidden = activeTab !== "address";
      smsView.hidden = activeTab !== "sms";
    };
    const updateState = async () => {
      const saved = await loadAppState();
      activeTab = saved.activeTab;
      setCollapsed(saved.panelCollapsed);
      renderActiveTab();
      state.textContent = getStateLabel(activeTab, registerController);
      await handles[activeTab].update();
    };
    registerTab.addEventListener("click", () => void setActiveTab("register"));
    linkTab.addEventListener("click", () => void setActiveTab("link"));
    addressTab.addEventListener("click", () => void setActiveTab("address"));
    smsTab.addEventListener("click", () => void setActiveTab("sms"));
    autoTab.addEventListener("click", () => void setActiveTab("auto"));
    settingsButton.addEventListener("click", () => settingsDialog.open());
    collapseButton.addEventListener("click", () => {
      const collapsed = !shell.classList.contains("is-collapsed");
      setCollapsed(collapsed);
      void savePanelCollapsed(collapsed);
    });
    topbar.append(tabs, settingsButton);
    panel.append(topbar, versionNotice.element, state, autoView, registerView, linkView, addressView, smsView, settingsDialog.element);
    shell.append(collapseButton, panel);
    root.append(style, shell);
    window.setInterval(() => void updateState(), 1e3);
    window.setTimeout(() => void versionNotice.update(), 800);
    void updateState().then(() => {
      void handles[activeTab].onShow?.();
    });
  }
  function getStateLabel(activeTab, registerController) {
    if (activeTab === "auto") {
      return "\u4E00\u952E\u81EA\u52A8\u5316";
    }
    if (activeTab === "register") {
      return registerController.getPageState().label;
    }
    if (activeTab === "link") {
      return "\u63D0\u94FE\u63A5\uFF1AChatGPT session";
    }
    if (activeTab === "address") {
      return "\u5730\u5740\uFF1A\u968F\u673A\u8D44\u6599";
    }
    return "\u63A5\u7801\uFF1A\u77ED\u4FE1\u9A8C\u8BC1\u7801";
  }
  function createView() {
    const view = document.createElement("section");
    view.className = "opx-view";
    return view;
  }
  function createTab(tab, label) {
    const button = document.createElement("button");
    button.className = "opx-tab";
    button.type = "button";
    button.dataset.tab = tab;
    button.textContent = label;
    return button;
  }

  // src/app/index.ts
  var ROOT_ID = "opx-assistant-root";
  function mountAssistant() {
    if (document.getElementById(ROOT_ID)) {
      return;
    }
    const host = document.createElement("div");
    host.id = ROOT_ID;
    document.documentElement.append(host);
    const shadow = host.attachShadow({ mode: "open" });
    const registerController = createRegisterController();
    createPanel(shadow, registerController);
    void registerController.autoRunForCurrentPage();
  }

  // entrypoints/content.ts
  init_pay_openai_autofill();
  var CONTENT_LOADED_KEY = "__opx_assistant_content_loaded__";
  var content_default = defineContentScript({
    matches: [
      "https://chatgpt.com/*",
      "https://auth.openai.com/*",
      "https://pay.openai.com/*",
      "https://www.paypal.com/*",
      "https://paypal.com/*"
    ],
    runAt: "document_idle",
    registration: "manifest",
    main() {
      const scope = globalThis;
      if (scope[CONTENT_LOADED_KEY]) {
        return;
      }
      scope[CONTENT_LOADED_KEY] = true;
      mountAssistant();
      try {
        initPayOpenAiAddressAutofill();
      } catch (error) {
        console.warn("[OPX] pay autofill init failed", error);
      }
      try {
        initPaypalAutofill();
      } catch (error) {
        console.warn("[OPX] PayPal autofill init failed", error);
      }
      try {
        void resumeIfEnabled();
      } catch (error) {
        console.warn("[OPX] orchestrator resume failed", error);
      }
    }
  });
})();
})();
