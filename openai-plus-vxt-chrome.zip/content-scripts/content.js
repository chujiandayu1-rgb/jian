var content=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=[`input#email`,`input[name="email"]`,`input[type="email"]`,`input[autocomplete="email"]`],r=[`button[type="submit"]`,`form button:not([type="button"])`];function i(){if(location.hostname!==`chatgpt.com`&&location.hostname!==`auth.openai.com`)return!1;if(location.pathname.startsWith(`/auth/login`))return!0;let e=document.querySelector(`input#email, input[name="email"], input[type="email"], input[autocomplete="email"]`);return!!(e&&a(e)||location.hostname===`auth.openai.com`&&document.querySelector(`input[name="email"], input[type="email"]`))}function a(e){let t=e,n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.display!==`none`&&n.visibility!==`hidden`&&r.width>0&&r.height>0}async function o(e){let t=c(n);if(!t)return p(`没有找到邮箱输入框`);l(t,e),t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),await u();let r=s();return r?(r.disabled&&await d(r,2500),r.disabled?p(`继续按钮仍然不可点击`):(r.click(),f(`已填入邮箱并点击继续`))):p(`没有找到继续按钮`)}function s(){for(let e of r){let t=document.querySelector(e);if(t)return t}return Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim();return t===`继续`||t.toLowerCase()===`continue`})??null}function c(e){for(let t of e){let e=document.querySelector(t);if(e)return e}return null}function l(e,t){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set?.call(e,t)}function u(){return new Promise(e=>window.setTimeout(e,60))}function d(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function f(e){return{ok:!0,message:e}}function p(e){return{ok:!1,message:e}}var m=[`input[name="code"]`,`input[name="otp"]`,`input[autocomplete="one-time-code"]`,`input[inputmode="numeric"]`,`input[type="text"]`];function h(){if(location.hostname!==`auth.openai.com`||!location.pathname.startsWith(`/email-verification`))return!1;let e=(document.body?.textContent||``).toLowerCase();return!(e.includes(`已验证`)||e.includes(`verified`)||e.includes(`email verified`))}async function g(e){let t=e.replace(/\D/g,``);if(!t)return C(`验证码不能为空`);let n=y();if(!n)return C(`没有找到验证码输入框`);if(await _(n,t),await v(200),!n.value)return C(`验证码未写入输入框（React 框架兼容问题）`);let r=b();return r?(r.disabled&&await x(r,3e3),r.disabled?C(`验证码继续按钮仍然不可点击`):(r.click(),S(`已填入验证码并点击继续`))):C(`没有找到验证码继续按钮`)}async function _(e,t){if(e.focus(),e.dispatchEvent(new FocusEvent(`focus`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusin`,{bubbles:!0})),await v(100),e.select(),document.execCommand(`selectAll`),document.execCommand(`delete`),await v(50),!document.execCommand(`insertText`,!1,t)||e.value!==t){let n=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),`value`)?.set||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))}await v(100),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function v(e){return new Promise(t=>window.setTimeout(t,e))}function y(){for(let e of m){let t=document.querySelector(e);if(t)return t}return Array.from(document.querySelectorAll(`input`)).find(e=>{let t=[e.placeholder,e.ariaLabel,e.name,e.id].join(` `).toLowerCase();return t.includes(`code`)||t.includes(`otp`)||t.includes(`验证`)})??null}function b(){return document.querySelector(`button[type="submit"]`)||(Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim();return t===`继续`||t.toLowerCase()===`continue`})??null)}function x(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function S(e){return{ok:!0,message:e}}function C(e){return{ok:!1,message:e}}var w=[`input[name="name"]`,`input[name="fullName"]`,`input[autocomplete="name"]`,`input[type="text"]`],T=[`input[name="age"]`,`input[inputmode="numeric"]`,`input[type="number"]`,`input[type="text"]`],E=[`Arlen`,`Brennan`,`Calvin`,`Darian`,`Elliot`,`Finley`,`Gavin`,`Harlan`,`Jasper`,`Kieran`,`Landon`,`Morgan`,`Nolan`,`Parker`,`Rowan`,`Sawyer`,`Tristan`,`Warren`];function D(){return location.hostname===`auth.openai.com`&&location.pathname.startsWith(`/about-you`)}async function O(){let e=ee(),t=te(e);if(!e)return de(`没有找到全名输入框`);if(!t)return de(`没有找到年龄输入框`);let n=ce(),r=String(le(25,55));if(await k(e,n),await A(300),await k(t,r),await A(300),!e.value&&!t.value)return de(`资料填写失败：值未写入输入框`);let i=oe();return i?(i.disabled&&await se(i,3e3),i.disabled?de(`完成账户创建按钮仍然不可点击`):(i.click(),ue(`已填写 ${n} / ${r} 并点击创建`))):de(`没有找到完成账户创建按钮`)}async function k(e,t){if(e.focus(),e.dispatchEvent(new FocusEvent(`focus`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusin`,{bubbles:!0})),await A(100),e.select(),document.execCommand(`selectAll`),document.execCommand(`delete`),await A(50),!document.execCommand(`insertText`,!1,t)||e.value!==t){let n=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),`value`)?.set||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))}await A(100),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`blur`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`focusout`,{bubbles:!0}))}function A(e){return new Promise(t=>window.setTimeout(t,e))}function ee(){let e=ne([`全名`,`名字`,`name`,`full name`]);if(e)return e;for(let e of w){let t=document.querySelector(e);if(t&&!ae(t))return t}return ie().find(e=>!ae(e))??null}function te(e){let t=ne([`年龄`,`age`]);if(t&&t!==e)return t;for(let t of T){let n=Array.from(document.querySelectorAll(t)).find(t=>t!==e&&ae(t));if(n)return n}return ie().find(t=>t!==e)??null}function ne(e){let t=ie();for(let n of t){let t=[n.name,n.id,n.placeholder,n.ariaLabel,n.getAttribute(`aria-labelledby`)?re(n.getAttribute(`aria-labelledby`)||``):``,n.closest(`label`)?.textContent||``,n.parentElement?.textContent||``].join(` `).toLowerCase();if(e.some(e=>t.includes(e.toLowerCase())))return n}return null}function re(e){return e.split(/\s+/).map(e=>document.getElementById(e)?.textContent||``).join(` `)}function ie(){return Array.from(document.querySelectorAll(`input`)).filter(e=>{let t=(e.type||`text`).toLowerCase();return[`text`,`number`,`tel`,``].includes(t)})}function ae(e){let t=[e.name,e.id,e.placeholder,e.ariaLabel,e.inputMode,e.type,e.parentElement?.textContent||``].join(` `).toLowerCase();return t.includes(`age`)||t.includes(`年龄`)||t.includes(`numeric`)||e.type===`number`}function oe(){return document.querySelector(`button[type="submit"]`)||(Array.from(document.querySelectorAll(`button`)).find(e=>{let t=(e.textContent||``).trim().toLowerCase();return t.includes(`完成帐户创建`)||t.includes(`完成账户创建`)||t.includes(`create account`)||t.includes(`continue`)})??null)}function se(e,t){let n=Date.now();return new Promise(r=>{let i=()=>{if(!e.disabled||Date.now()-n>=t){r();return}window.setTimeout(i,100)};i()})}function ce(){return E[le(0,E.length-1)]}function le(e,t){return Math.floor(Math.random()*(t-e+1))+e}function ue(e){return{ok:!0,message:e}}function de(e){return{ok:!1,message:e}}var fe=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;function pe(e){let t=e.trim();if(!t)return me(`empty`,`请输入邮箱或 Outlook 账号行`);let n=t.split(/\r?\n/).map(e=>e.trim()).find(Boolean)||``;if(n.includes(`----`)){let e=n.split(`----`).map(e=>e.trim()),t=e[0]||``;return fe.test(t)?e.length<4||!e[2]||!e[3]?me(`invalid`,`Outlook 行需要 email----password----client_id----refresh_token`):{ok:!0,mode:`outlook-line`,email:t,accountLine:n,message:`Outlook API 自动验证码`}:me(`invalid`,`Outlook 行里的邮箱格式不正确`)}return fe.test(n)?{ok:!0,mode:`email`,email:n,accountLine:``,message:`单邮箱模式，验证码手动输入`}:me(`invalid`,`邮箱格式不正确`)}function me(e,t){return{ok:!1,mode:e,email:``,accountLine:``,message:t}}var he=/"accessToken"\s*:\s*"([^"]+)"/,ge=/"accessToken"\s*:\s*"?([A-Za-z0-9_.-]+)/,_e=/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/,j={planName:`chatgptplusplan`,uiMode:`hosted`,region:`US`,workspaceName:`MyTeam`,seatQuantity:5};function ve(e){let t=String(e||``).trim();if(!t)throw Error(`请输入包含 accessToken 的 JSON 或字符串`);let n=we(t)||Ee(t)||De(t);if(!n)throw Error(`未找到 accessToken`);if(n.split(`.`).length!==3)throw Error(`accessToken 格式不正确`);return n}function ye(e){let t=Oe(e)?e:{};return{planName:be(t.planName),uiMode:xe(t.uiMode),region:Se(t.region||t.country),workspaceName:String(t.workspaceName||t.workspace_name||j.workspaceName).trim()||j.workspaceName,seatQuantity:Ce(t.seatQuantity)}}function be(e){return e===`chatgptplusplan`||e===`chatgptteamplan`?e:j.planName}function xe(e){return e===`hosted`?`hosted`:`custom`}function Se(e){let t=String(e||j.region).trim().toUpperCase();return t===`ID`||t===`DE`||t===`JP`||t===`US`?t:j.region}function Ce(e){let t=Number(e||j.seatQuantity);if(!Number.isInteger(t)||t<1)throw Error(`team_plan_data.seat_quantity 必须是大于 0 的整数`);return t}function we(e){try{return Te(JSON.parse(e))}catch{return``}}function Te(e,t=0){if(!Oe(e)||t>4)return``;if(typeof e.accessToken==`string`)return e.accessToken.trim();for(let n of Object.values(e)){let e=Te(n,t+1);if(e)return e}return``}function Ee(e){let t=he.exec(e);if(t?.[1])return t[1].trim();let n=ge.exec(e);if(!n?.[1])return``;let r=n[1].trim().replace(/[",}\]\s]+$/,``);return _e.exec(r)?.[0]?.trim()||r}function De(e){return _e.exec(e)?.[0]?.trim()||``}function Oe(e){return!!(e&&typeof e==`object`)}var ke=`http://127.0.0.1:8787`,Ae=`opx.registerAssist.state`,je={rawInput:``,email:``,accountLine:``,inputMode:`empty`,autoOtp:!1,apiBase:ke,otpRequestedAt:0,updatedAt:0},Me={checkoutOptions:j,updatedAt:0},Ne={rawInput:``,history:[],updatedAt:0};async function M(){return Ue((await t.storage.local.get(Ae))[Ae])}async function Pe(e){let n=Ue({...await M(),activeTab:e});return await t.storage.local.set({[Ae]:n}),n}async function Fe(e){let n=Ue({...await M(),panelCollapsed:e});return await t.storage.local.set({[Ae]:n}),n}async function Ie(){return(await M()).register}async function Le(e){let n=await M(),r=We({...n.register,...e,updatedAt:Date.now()}),i=Ue({...n,register:r});return await t.storage.local.set({[Ae]:i}),i.register}async function Re(){return(await M()).linkExtractor}async function ze(e){let n=await M(),r=Ge({...n.linkExtractor,...e,updatedAt:Date.now()}),i=Ue({...n,linkExtractor:r});return await t.storage.local.set({[Ae]:i}),i.linkExtractor}async function Be(){return(await M()).smsRelay}async function Ve(e){let n=await M(),r=Ke({...n.smsRelay,...e,updatedAt:Date.now()}),i=Ue({...n,smsRelay:r});return await t.storage.local.set({[Ae]:i}),i.smsRelay}function He(e){return e===`auto`||e===`register`||e===`link`||e===`address`||e===`sms`}function Ue(e){let t=N(e)?e:{},n=N(t.register)?t.register:t,r=N(t.linkExtractor)?t.linkExtractor:t,i=N(t.smsRelay)?t.smsRelay:Ne;return{activeTab:He(String(t.activeTab||``))?t.activeTab:`auto`,panelCollapsed:!!t.panelCollapsed,register:We(n),linkExtractor:Ge(r),smsRelay:Ke(i)}}function We(e){let t=N(e)?e:{};return{rawInput:String(t.rawInput||je.rawInput),email:String(t.email||je.email),accountLine:String(t.accountLine||je.accountLine),inputMode:Je(t.inputMode),autoOtp:!!t.autoOtp,apiBase:String(t.apiBase||je.apiBase),otpRequestedAt:Number(t.otpRequestedAt||je.otpRequestedAt),updatedAt:Number(t.updatedAt||je.updatedAt)}}function Ge(e){let t=N(e)?e:{};return{checkoutOptions:ye(t.checkoutOptions||Me.checkoutOptions),updatedAt:Number(t.updatedAt||Me.updatedAt)}}function Ke(e){let t=N(e)?e:{},n=Array.isArray(t.history)?t.history.map(qe).filter(e=>!!e):Ne.history;return{rawInput:String(t.rawInput||Ne.rawInput),history:n,updatedAt:Number(t.updatedAt||Ne.updatedAt)}}function qe(e){if(!N(e))return null;let t=String(e.phone||``).trim(),n=String(e.code||``).trim();if(!t||!n)return null;let r=Number(e.receivedAt||0)||Date.now();return{id:String(e.id||`${t}-${n}-${r}`),phone:t,code:n,message:String(e.message||``).trim(),receivedAt:r}}function Je(e){return e===`email`||e===`outlook-line`||e===`invalid`?e:`empty`}function N(e){return!!(e&&typeof e==`object`)}var Ye=!1;function Xe(){return{getPageState:Ze,loadState:Ie,saveInput:async e=>{let t=pe(e);return Le({rawInput:e,email:t.email,accountLine:t.accountLine,inputMode:t.mode,autoOtp:t.mode===`outlook-line`})},saveApiBase:async e=>Le({apiBase:e.trim()}),fillEmailFromInput:async()=>{let e=pe((await Ie()).rawInput);return e.ok?i()?(await Le({email:e.email,accountLine:e.accountLine,inputMode:e.mode,autoOtp:e.mode===`outlook-line`,otpRequestedAt:Date.now()}),o(e.email)):P(`当前页面不是 ChatGPT 登录页`):P(e.message)},fillOtp:async e=>h()?g(e):P(`当前页面不是邮箱验证码页`),waitForOutlookOtp:async()=>{if(!h())return P(`当前页面不是邮箱验证码页`);let e=await Ie();if(!e.accountLine)return P(`当前输入不是 Outlook 账号行，不能自动接收验证码`);let n=await t.runtime.sendMessage({type:`opx:wait-outlook-otp`,accountLine:e.accountLine,apiBase:e.apiBase,since:e.otpRequestedAt||e.updatedAt||Date.now(),timeoutMs:18e4,intervalMs:5e3});if(!Qe(n))return P(`Outlook API 没有返回有效结果`);if(!n.ok||!n.code)return n;let r=await g(n.code);return{...r,code:n.code,message:r.ok?`已收到并提交验证码：${n.code}`:r.message}},fillProfileAndCreate:async()=>D()?O():P(`当前页面不是资料填写页`),autoRunForCurrentPage:async()=>{!D()||Ye||(Ye=!0,await $e(),await O())}}}function Ze(){return i()?{kind:`login`,label:`ChatGPT 登录页`,canFillEmail:!0,canFillOtp:!1,canFillProfile:!1}:h()?{kind:`email-verification`,label:`邮箱验证码页`,canFillEmail:!1,canFillOtp:!0,canFillProfile:!1}:D()?{kind:`about-you`,label:`资料填写页`,canFillEmail:!1,canFillOtp:!1,canFillProfile:!0}:{kind:`unknown`,label:`未识别页面`,canFillEmail:!1,canFillOtp:!1,canFillProfile:!1}}function P(e){return{ok:!1,message:e}}function Qe(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function $e(){return new Promise(e=>window.setTimeout(e,800))}var et=`opx.extension.settings`,F={payOpenAiEnabled:!0,payPalSignupEnabled:!0,countryCode:`US`,city:``,lastAddress:null,updatedAt:0},tt={addressAutofill:F,updatedAt:0},nt=new Set([`RANDOM`,`US`,`CA`,`AU`,`JP`,`TW`,`KR`,`HK`,`GB`,`DE`,`SG`,`FR`,`IT`,`ES`,`NL`,`MY`,`RU`,`CN`,`TH`,`PH`,`AR`,`TR`,`VN`]);async function rt(){return it((await t.storage.local.get(et))[et])}async function I(e){let n=await rt(),r=at({...n.addressAutofill,...e,updatedAt:Date.now()}),i=it({...n,addressAutofill:r,updatedAt:Date.now()});return await t.storage.local.set({[et]:i}),i.addressAutofill}async function L(){return(await rt()).addressAutofill}function it(e){let t=ut(e)?e:{};return{addressAutofill:at(t.addressAutofill),updatedAt:Number(t.updatedAt||tt.updatedAt)}}function at(e){let t=ut(e)?e:{};return{payOpenAiEnabled:t.payOpenAiEnabled===void 0?F.payOpenAiEnabled:!!t.payOpenAiEnabled,payPalSignupEnabled:t.payPalSignupEnabled===void 0?F.payPalSignupEnabled:!!t.payPalSignupEnabled,countryCode:dt(t.countryCode||t.country),city:String(t.city||t.region||F.city),lastAddress:ot(t.lastAddress),updatedAt:Number(t.updatedAt||F.updatedAt)}}function ot(e){if(!ut(e))return null;let t=String(e.line1||``).trim(),n=String(e.city||``).trim(),r=String(e.countryCode||e.country||`US`).trim().toUpperCase(),i=String(e.state||``).trim(),a=r===`US`?i.toUpperCase():i,o=String(e.postalCode||``).trim();return!t||!n||!a||!o?null:{id:String(e.id||`${Date.now()}`),fullName:String(e.fullName||``).trim(),line1:t,line2:String(e.line2||``).trim(),city:n,state:a,stateFull:String(e.stateFull||``).trim(),postalCode:o,countryCode:r,countryLabel:String(e.countryLabel||``).trim(),countryPath:String(e.countryPath||``).trim(),phone:String(e.phone||``).trim(),identity:st(e.identity),employment:ct(e.employment),creditCard:lt(e.creditCard),source:e.source===`fallback`?`fallback`:`meiguodizhi`,fetchedAt:Number(e.fetchedAt||0)}}function st(e){let t=ut(e)?e:{};return{gender:String(t.gender||``).trim(),title:String(t.title||``).trim(),birthday:String(t.birthday||``).trim(),username:String(t.username||``).trim(),password:String(t.password||``).trim(),temporaryMail:String(t.temporaryMail||``).trim(),system:String(t.system||``).trim(),userAgent:String(t.userAgent||``).trim(),website:String(t.website||``).trim(),securityQuestion:String(t.securityQuestion||``).trim(),securityAnswer:String(t.securityAnswer||``).trim()}}function ct(e){let t=ut(e)?e:{};return{educationalBackground:String(t.educationalBackground||``).trim(),occupation:String(t.occupation||``).trim(),employmentStatus:String(t.employmentStatus||``).trim(),monthlySalary:String(t.monthlySalary||``).trim(),companySize:String(t.companySize||``).trim(),companyName:String(t.companyName||``).trim()}}function lt(e){let t=ut(e)?e:{},n=String(t.number||``).replace(/\D/g,``),r=String(t.last4||n.slice(-4)||``).replace(/\D/g,``).slice(-4);return{type:String(t.type||``).trim(),number:n,cvv:String(t.cvv||``).trim(),expires:String(t.expires||``).trim(),last4:r,maskedNumber:String(t.maskedNumber||(r?`**** **** **** ${r}`:``)).trim()}}function ut(e){return!!(e&&typeof e==`object`)}function dt(e){let t=String(e||F.countryCode).trim().toUpperCase();return nt.has(t)?t:F.countryCode}var ft=[{code:`US`,label:`美国`,path:`/`},{code:`CA`,label:`加拿大`,path:`/ca-address`},{code:`AU`,label:`澳大利亚`,path:`/au-address`},{code:`JP`,label:`日本`,path:`/jp-address`},{code:`TW`,label:`台湾`,path:`/tw-address`},{code:`KR`,label:`韩国`,path:`/kr-address`},{code:`HK`,label:`香港`,path:`/hk-address`},{code:`GB`,label:`英国`,path:`/uk-address`},{code:`DE`,label:`德国`,path:`/de-address`},{code:`SG`,label:`新加坡`,path:`/sg-address`},{code:`FR`,label:`法国`,path:`/fr-address`},{code:`IT`,label:`意大利`,path:`/it-address`},{code:`ES`,label:`西班牙`,path:`/es-address`},{code:`NL`,label:`荷兰`,path:`/nl-address`},{code:`MY`,label:`马来西亚`,path:`/my-address`},{code:`RU`,label:`俄罗斯`,path:`/ru-address`},{code:`CN`,label:`中国`,path:`/cn-address`},{code:`TH`,label:`泰国`,path:`/th-address`},{code:`PH`,label:`菲律宾`,path:`/ph-address`},{code:`AR`,label:`阿根廷`,path:`/ar-address`},{code:`TR`,label:`土耳其`,path:`/tr-address`},{code:`VN`,label:`越南`,path:`/vn-address`}],R=`[OPX Pay Autofill]`,pt=!1,mt=!1,ht=null,gt=null,_t=``;function vt(){pt||location.hostname!==`pay.openai.com`||(pt=!0,It(),Ft(),Lt(800))}async function yt(){if(!mt){mt=!0;try{let e=await L();if(!e.payOpenAiEnabled){console.info(`${R} disabled`);return}let t=await xt(e);if(!t){console.info(`${R} no address available`);return}let n=await bt(t);console.info(`${R} ${n.message}`,{city:t.city,state:t.state,postalCode:t.postalCode,country:t.countryCode,source:t.source})}catch(e){console.warn(`${R} failed`,e)}finally{mt=!1}}}async function bt(e){if(location.hostname!==`pay.openai.com`)return{ok:!1,filled:0,message:`当前不是 pay.openai.com 页面`};wt(),await Wt(450),await Ut(3e3);let t=await Ct(e);return{ok:t>0,filled:t,message:t>0?`已填写 OpenAI 支付页 ${t} 项`:`未找到可填写的 OpenAI 支付字段`}}async function xt(e){let t=`${e.countryCode}|${e.city}`;return gt&&_t===t?gt:(gt=await St(e),_t=t,gt)}async function St(e){let n=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});return!Gt(n)||!n.ok||!n.address?(console.warn(`${R} address fetch failed`,n),null):(await I({lastAddress:n.address}),n.address)}async function Ct(e){let t=0;return t+=z(`#billingName`,e.fullName,!0),t+=Et(`#billingCountry`,e.countryCode,[e.countryLabel,e.countryCode]),document.querySelector(`#billingCountry`)&&await Wt(550),t+=z(`#billingAddressLine1`,e.line1,!0),Ht(),await Wt(300),t+=z(`#billingAddressLine2`,e.line2,!0),t+=z(`#billingLocality`,e.city,!0),t+=Ot(`#billingAdministrativeArea`,e.state,[e.stateFull,e.state]),t+=z(`#billingPostalCode`,e.postalCode,!0),t+=z(`#phoneNumber`,e.phone,!1),t+=Tt(`billing address-line1`,e.line1),Ht(),await Wt(300),t+=Tt(`billing address-line2`,e.line2),t+=Tt(`billing address-level2`,e.city),t+=Tt(`billing postal-code`,e.postalCode),t+=kt(`billing address-level1`,e.state,[e.stateFull,e.state]),t+=Dt(`billing country`,e.countryCode,[e.countryLabel,e.countryCode]),t+=Mt(),t}function wt(){let e=document.querySelector(`#payment-method-accordion-item-title-paypal`);if(e?.checked||e?.getAttribute(`aria-checked`)===`true`)return!0;let t=document.querySelector(`#payment-method-label-paypal`);if(t&&B(t))return Pt(t),console.info(`${R} 已点击 PayPal label`),!0;let n=document.querySelector(`button[data-testid="paypal-accordion-item-button"]`);if(n&&B(n))return Pt(n),console.info(`${R} 已点击 PayPal button`),!0;if(e){let t=e.closest(`.PaymentMethodFormAccordionItemTitle, .flex-container.direction-row.align-items-center, label, [role="radio"]`);return t&&B(t)?(Pt(t),console.info(`${R} 已点击 PayPal radio 容器`),!0):(Pt(e),console.info(`${R} 已点击 PayPal radio`),!0)}let r=Array.from(document.querySelectorAll(`div, span, label`)).filter(B).find(e=>V(e.textContent)===`paypal`);return r?(Pt(r),console.info(`${R} 通过文本匹配点击了 PayPal`),!0):(console.warn(`${R} 未找到 PayPal 选项`),!1)}function z(e,t,n){if(!t)return 0;let r=document.querySelector(e);return!zt(r)||!B(r)||Rt(r)||!n&&r.value.trim()||r.value===t?0:(jt(r,t),1)}function Tt(e,t){let n=`input[autocomplete="${Vt(e)}"], textarea[autocomplete="${Vt(e)}"]`,r=document.querySelector(n);return!zt(r)||!B(r)||r.value===t||Rt(r)?0:(jt(r,t),1)}function Et(e,t,n){let r=document.querySelector(e);return!Bt(r)||!B(r)?0:At(r,t,n)}function Dt(e,t,n){let r=document.querySelector(`select[autocomplete="${Vt(e)}"]`);return!Bt(r)||!B(r)?0:At(r,t,n)}function Ot(e,t,n){let r=document.querySelector(e);return Bt(r)?B(r)?At(r,t,n):0:zt(r)?z(e,t,!0):0}function kt(e,t,n){let r=document.querySelector(`select[autocomplete="${Vt(e)}"]`);return Bt(r)?B(r)?At(r,t,n):0:Tt(e,t||n[0]||``)}function At(e,t,n){let r=Array.from(e.options).filter(e=>!e.disabled&&e.value),i=V(t),a=n.map(e=>V(e)).filter(Boolean),o=r.find(e=>V(e.value)===i)||r.find(e=>a.some(t=>V(`${e.text} ${e.value}`).includes(t)));return!o||e.value===o.value?0:(e.value=o.value,Nt(e),1)}function jt(e,t){let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`);r?.set?r.set.call(e,t):e.value=t,Nt(e)}function Mt(){let e=0,t=Array.from(document.querySelectorAll(`input[type="checkbox"]`)).filter(B).filter(e=>!e.checked).filter(e=>{let t=V([e.id,e.name,e.getAttribute(`aria-label`),e.closest(`label`)?.textContent,e.parentElement?.textContent].join(` `));return t.includes(`terms`)||t.includes(`consent`)||t.includes(`使用条款`)||t.includes(`隐私政策`)||t.includes(`取消`)||e.id===`termsOfServiceConsentCheckbox`});for(let n of t)n.click(),e+=1;return e}function Nt(e){e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function Pt(e){e.scrollIntoView({block:`center`,inline:`center`});for(let t of[`pointerdown`,`mousedown`,`pointerup`,`mouseup`,`click`]){let n=t.startsWith(`pointer`)?PointerEvent:MouseEvent;e.dispatchEvent(new n(t,{bubbles:!0,cancelable:!0,composed:!0,button:0,buttons:+!!t.endsWith(`down`),pointerId:1,pointerType:`mouse`}))}e.click()}function Ft(){new MutationObserver(()=>Lt(250)).observe(document.documentElement,{childList:!0,subtree:!0})}function It(){t.storage.onChanged.addListener((e,t)=>{t===`local`&&Object.keys(e).some(e=>e.includes(`settings`))&&(gt=null,_t=``,Lt(100))})}function Lt(e){ht&&window.clearTimeout(ht),ht=window.setTimeout(()=>{ht=null,yt()},e)}function B(e){let t=e;if(`disabled`in t&&t.disabled)return!1;let n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.visibility!==`hidden`&&n.display!==`none`&&r.width>0&&r.height>0}function Rt(e){let t=V([e.getAttribute(`aria-label`),e.getAttribute(`placeholder`),e.getAttribute(`autocomplete`),e.getAttribute(`name`),e.getAttribute(`id`)].join(` `));return[`cc-number`,`card number`,`credit card`,`security code`,`cvc`,`cvv`,`expiry`,`expiration`].some(e=>t.includes(e))}function zt(e){return!!(e&&(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))}function Bt(e){return!!(e&&e instanceof HTMLSelectElement)}function V(e){return String(e||``).replace(/\s+/g,` `).trim().toLowerCase()}function Vt(e){return typeof CSS<`u`&&typeof CSS.escape==`function`?CSS.escape(e):e.replace(/"/g,`\\"`)}function Ht(){let e=document.activeElement;e&&(e.dispatchEvent(new KeyboardEvent(`keydown`,{key:`Escape`,code:`Escape`,bubbles:!0})),e.dispatchEvent(new KeyboardEvent(`keyup`,{key:`Escape`,code:`Escape`,bubbles:!0})),e.blur());let t=document.querySelectorAll(`.pac-container`);for(let e of Array.from(t))e.style.display=`none`;let n=document.querySelectorAll(`a, button, span, div`);for(let e of Array.from(n)){let t=V(e.textContent||``);if((t.includes(`enter address manually`)||t.includes(`手动输入地址`)||t.includes(`manual`))&&B(e)){e.click();break}}}async function Ut(e){let t=Date.now()+e,n=[`#billingName`,`#billingAddressLine1`,`#billingCountry`,`input[autocomplete="billing address-line1"]`,`input[name="billingName"]`];for(;Date.now()<t;){for(let e of n){let t=document.querySelector(e);if(t&&B(t))return!0}await Wt(300)}return!1}function Wt(e){return new Promise(t=>window.setTimeout(t,e))}function Gt(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var Kt=`[OPX PayPal Autofill]`,qt=`opx.paypal.autofill.address`,Jt=`opx.paypal.autofill.pendingManual`,Yt=`data-opx-paypal-filled`,Xt=`opx-paypal-random-fill`,Zt=3,Qt={AR:`Argentina`,AU:`Australia`,CA:`Canada`,CN:`China`,DE:`Germany`,ES:`Spain`,FR:`France`,GB:`United Kingdom`,HK:`Hong Kong`,IT:`Italy`,JP:`Japan`,KR:`South Korea`,MY:`Malaysia`,NL:`Netherlands`,PH:`Philippines`,RU:`Russia`,SG:`Singapore`,TH:`Thailand`,TR:`Turkey`,TW:`Taiwan`,US:`United States`,VN:`Vietnam`},$t=!1,en=!1,tn=null,H=null,nn=null,rn=``,an=0,on=``;function sn(){$t||!fr()||($t=!0,Wn(),Qn(),Un(),ir()?tr(900):$n(800))}async function cn(e,t=!1,n=!0){if(!fr())return{ok:!1,filled:0,message:`当前不是 PayPal 注册支付页`,countryChanged:!1};let r=await L(),i=e||await un(r);if(!i)return{ok:!1,filled:0,message:`没有可用地址资料`,countryChanged:!1};or(i),t&&!n&&er(),t&&(Mn(),Fn());let a=await dn(i,n);return Nn(i,a.countryChanged,n),t&&!n&&(on=In(i),a.countryChanged?(rr(),tr(1600)):ar()),{ok:a.filled>0||a.countryChanged,filled:a.filled,countryChanged:a.countryChanged,message:a.countryChanged?`已选择 PayPal 国家：${i.countryCode}，等待页面重新加载`:a.filled>0?`已填写 PayPal ${a.filled} 项`:`未找到可填写的 PayPal 字段`}}async function ln(){if(!en&&!(on&&rn===on)){en=!0;try{if(!(await L()).payPalSignupEnabled){console.info(`${Kt} disabled`);return}let e=await cn();console.info(`${Kt} ${e.message}`),(!e.ok||Pn())&&(nn?.disconnect(),nn=null)}catch(e){console.warn(`${Kt} failed`,e)}finally{en=!1}}}async function un(e){if(H&&sr(H,e))return H;let n=nr();if(n&&sr(n,e))return H=n,H;let r=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});return!yr(r)||!r.ok||!r.address?(console.warn(`${Kt} address fetch failed`,r),null):(H=r.address,or(r.address),await I({lastAddress:r.address}),H)}async function dn(e,t){let n=0;if(fn(e))return t&&$n(1500),{filled:1,countryChanged:!0};let r=await pn(e),i=lr(e.fullName),a=cr(e.creditCard.expires);return n+=U(q.email,r,!0),n+=hn(r),gn(r),n+=U(q.phone,e.phone,!0),n+=U(q.cardNumber,e.creditCard.number,!0),n+=U(q.expiry,a.short,!0),n+=U(q.csc,e.creditCard.cvv,!0),n+=U(q.fullName,e.fullName,!0),n+=U(q.firstName,i.first,!0),n+=U(q.lastName,i.last,!0),n+=U(q.address1,e.line1,!0),n+=U(q.address2,e.line2,!0),n+=U(q.city,e.city,!0),n+=_n(q.state,e.state,[e.stateFull,e.state]),n+=U(q.postalCode,e.postalCode,!0),n+=vn(e,i),n+=_n(q.expiryMonth,a.month,[a.month]),n+=_n(q.expiryYear,a.year4,[a.year4,a.year2]),n>0&&setTimeout(()=>pr(),800),{filled:n,countryChanged:!1}}function fn(e){let t=wn(q.country);return!t||!W(t)?!1:Bn(t,e.countryCode,[e.countryCode,Qt[e.countryCode]||``,e.countryLabel])}async function pn(e){let t=await Ie(),n=pe(t.rawInput);return n.ok&&_r(n.email)?n.email:_r(t.email)?t.email:_r(e.identity.temporaryMail)?e.identity.temporaryMail:ur(e)}function U(e,t,n){if(!t)return 0;let r=Cn(e);return!r||!W(r)?0:mn(r,t,n)}function mn(e,t,n){if(!t||!W(e))return 0;let r=e.value.trim();return e.getAttribute(Yt)===`1`||Ln(r,t)?(e.setAttribute(Yt,`1`),0):!n&&r?0:(Vn(e,t),e.setAttribute(Yt,`1`),1)}function hn(e){if(!e)return 0;let t=document.querySelector(`input#password`)||Cn(q.password);if(!t||!W(t))return 0;let n=dr(e);return Ln(t.value.trim(),n)?0:(Vn(t,n),1)}function gn(e){let t=Yn();if(!t)return;let n=dr(e);hn(n);let r=`opx-paypal-password-note`,i=`当前密码：${n}`,a=document.getElementById(r);a||(a=document.createElement(`div`),a.id=r,Object.assign(a.style,{color:`#93e4bd`,fontSize:`12px`,lineHeight:`18px`,margin:`4px 0 10px`,padding:`6px 10px`,border:`1px solid rgba(47, 209, 124, 0.36)`,borderRadius:`6px`,background:`rgba(15, 23, 42, 0.82)`,display:`block`}));let o=t.parentElement;o&&(o.insertBefore(a,t),a.textContent=i)}function _n(e,t,n){if(!t&&!n.some(Boolean))return 0;let r=wn(e);return r&&W(r)?+!!Bn(r,t,n):U(e,t||n.find(Boolean)||``,!0)}function vn(e,t){let n=xn();if(!n)return 0;let r=Array.from(n.querySelectorAll(`input, textarea, select`)).filter(e=>(G(e)||gr(e))&&W(e)&&!mr(e)&&!hr(e)),i=0;return i+=yn(n,[`first name`,`given name`],t.first,r[0]),i+=yn(n,[`last name`,`family name`,`surname`],t.last,r[1]),i+=yn(n,[`street address`,`address line 1`,`address 1`],e.line1,r[2]),i+=yn(n,[`apt`,`ste`,`bldg`,`address line 2`,`address 2`],e.line2,r[3]),i+=yn(n,[`city`,`locality`],e.city,r[4]),i+=bn(n,[`state`,`province`,`region`],e.state,[e.stateFull,e.state],r[5]),i+=yn(n,[`zip`,`postal code`,`postcode`],e.postalCode,r[6]),i}function yn(e,t,n,r){let i=r&&G(r)?r:null,a=Sn(e,t,G)||i;return a?mn(a,n,!0):0}function bn(e,t,n,r,i){let a=i&&gr(i)?i:null,o=Sn(e,t,gr)||a;if(o)return+!!Bn(o,n,r);let s=i&&G(i)?i:null,c=Sn(e,t,G)||s;return c?mn(c,n||r.find(Boolean)||``,!0):0}function xn(){return Array.from(document.querySelectorAll(`fieldset, [role="group"], section, form > div`)).find(e=>{let t=K(e.textContent||``);return t.includes(`billing address`)&&(t.includes(`street address`)||t.includes(`address`))&&(t.includes(`first name`)||t.includes(`last name`))})||null}function Sn(e,t,n){let r=t.map(K).filter(Boolean);return Array.from(e.querySelectorAll(`input, textarea, select`)).filter(n).map(e=>({control:e,score:On(e,r)})).filter(e=>e.score>0&&W(e.control)&&!mr(e.control)).sort((e,t)=>t.score-e.score)[0]?.control||null}function Cn(e){for(let t of e){let e=Tn(t);if(G(e))return e}return Dn(e,G)}function wn(e){for(let t of e){let e=Tn(t);if(gr(e))return e}return Dn(e,gr)}function Tn(e){if(!En(e))return null;try{return document.querySelector(e)}catch{return null}}function En(e){let t=e.trim();return/^[.#[]/.test(t)||/^(input|select|textarea|button|label|form|fieldset|section|div)([#.[\s:]|$)/i.test(t)}function Dn(e,t){let n=e.filter(e=>!e.includes(`[`)&&!e.includes(`#`)&&!e.includes(`.`)).map(K).filter(Boolean);return n.length&&Array.from(document.querySelectorAll(`input, textarea, select`)).filter(t).map(e=>({control:e,score:On(e,n)})).filter(e=>e.score>0&&W(e.control)&&!mr(e.control)).sort((e,t)=>t.score-e.score)[0]?.control||null}function On(e,t){if(!W(e)||mr(e))return 0;let n=K([e.id,e.name,`placeholder`in e?e.placeholder:``,`autocomplete`in e?e.autocomplete:``,e.getAttribute(`aria-label`),kn(e),An(e)].join(` `)),r=K([e.previousElementSibling?.textContent,e.nextElementSibling?.textContent,jn(e)].join(` `)),i=K(e.parentElement?.textContent||``);return t.some(e=>n.includes(e))?30:t.some(e=>r.includes(e))?20:i.length<=120&&t.some(e=>i.includes(e))?5:0}function kn(e){let t=[],n=e.getAttribute(`aria-labelledby`);if(n)for(let e of n.split(/\s+/)){let n=document.getElementById(e);n?.textContent&&t.push(n.textContent)}let r=e.id;if(r)for(let e of Array.from(document.querySelectorAll(`label[for="${zn(r)}"]`)))t.push(e.textContent||``);return t.join(` `)}function An(e){return e.closest(`label`)?.textContent||``}function jn(e){let t=e.closest(`div, label, section`)?.textContent||``;return t.length<=160?t:``}function Mn(){for(let e of Array.from(document.querySelectorAll(`[${Yt}]`)))e.removeAttribute(Yt)}function Nn(e,t,n){let r=In(e);rn!==r&&(rn=r,an=0),an+=1,n&&!t&&an<Zt&&$n(1200)}function Pn(){return!!(rn&&an>=Zt)}function Fn(){rn=``,an=0,on=``}function In(e){return[location.origin,location.pathname,new URLSearchParams(location.search).get(`token`)||``,e.id].join(`|`)}function Ln(e,t){return!e||!t?!1:e===t?!0:Rn(e)===Rn(t)}function Rn(e){return e.toLowerCase().replace(/[^a-z0-9]/g,``)}function zn(e){return typeof CSS<`u`&&typeof CSS.escape==`function`?CSS.escape(e):e.replace(/"/g,`\\"`)}function Bn(e,t,n){let r=K(t),i=n.map(K).filter(Boolean),a=Array.from(e.options).filter(e=>!e.disabled&&e.value),o=a.find(e=>K(e.value)===r)||a.find(e=>i.some(t=>K(`${e.text} ${e.value}`).includes(t)));return!o||e.value===o.value?!1:(e.value=o.value,Hn(e),!0)}function Vn(e,t){e.focus();let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`);r?.set?r.set.call(e,t):e.value=t,Hn(e)}function Hn(e){e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function Un(){nn?.disconnect(),nn=new MutationObserver(()=>{Wn(),!(on&&rn===on)&&(Pn()||$n(350))}),nn.observe(document.documentElement,{childList:!0,subtree:!0})}function Wn(){if(!fr()||document.getElementById(Xt))return;let e=Jn(),t=qn(),n=Gn();if(e?.parentElement){n.style.marginTop=`8px`,n.style.marginBottom=`12px`,e.parentElement.insertBefore(n,e.nextSibling);return}t?.parentElement&&t.parentElement.insertBefore(n,t)}function Gn(){let e=document.createElement(`div`);e.id=Xt,e.setAttribute(`data-opx-paypal-random-fill`,`1`),Object.assign(e.style,{display:`flex`,alignItems:`center`,justifyContent:`flex-end`,gap:`8px`,margin:`10px 0 14px`,minHeight:`32px`});let t=document.createElement(`button`);t.type=`button`,t.textContent=`随机输入`,Object.assign(t.style,{appearance:`none`,border:`0`,borderRadius:`6px`,background:`#10b981`,color:`#ffffff`,cursor:`pointer`,fontSize:`13px`,fontWeight:`700`,lineHeight:`1`,minHeight:`32px`,padding:`0 14px`,whiteSpace:`nowrap`});let n=document.createElement(`span`);return Object.assign(n.style,{color:`#64748b`,fontSize:`12px`,lineHeight:`16px`,minWidth:`0`}),t.addEventListener(`click`,()=>{Kn(t,n)}),e.append(t,n),e}async function Kn(e,n){e.disabled=!0,e.textContent=`获取中...`,Object.assign(e.style,{cursor:`wait`,opacity:`0.72`}),n.textContent=`正在获取新资料`;try{let e=await L(),r=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:e.countryCode,city:e.city});if(!yr(r)||!r.ok||!r.address){n.textContent=r?.message||`获取失败`;return}H=r.address,or(r.address),await I({lastAddress:r.address});let i=await cn(r.address,!0,!1);n.textContent=i.countryChanged?`已切换国家，刷新后继续填写`:i.ok?`已随机输入 ${i.filled} 项`:i.message}catch(e){n.textContent=`失败：${vr(e)}`}finally{e.disabled=!1,e.textContent=`随机输入`,Object.assign(e.style,{cursor:`pointer`,opacity:`1`})}}function qn(){let e=Cn(q.cardNumber);return e?.closest(`div, label, section`)||e}function Jn(){let e=document.querySelector(`div.css-ltr-cssveg > form > section.css-ltr-4jicje:nth-of-type(1) > p.css-ltr-6pd54h.css-ltr-16jt5za-text_body`);return e&&W(e)?e:Array.from(document.querySelectorAll(`form section p, form p`)).filter(e=>W(e)).map(e=>({element:e,score:Zn(e)})).filter(e=>e.score>0).sort((e,t)=>t.score-e.score)[0]?.element||null}function Yn(){let e=document.querySelector(`section.css-ltr-h5yxuz:nth-of-type(3) > div.css-ltr-h5yxuz:nth-of-type(2) > div.css-ltr-1lvkl1r:nth-of-type(2) > p.css-ltr-abbmt5:nth-of-type(1)`);if(e&&W(e))return e;let t=document.querySelector(`input#password`)||Cn(q.password),n=t?.closest(`section`)||document;return Array.from(n.querySelectorAll(`p`)).filter(e=>W(e)).map(e=>({element:e,score:Xn(e,t)})).filter(e=>e.score>0).sort((e,t)=>t.score-e.score)[0]?.element||null}function Xn(e,t){let n=K(e.textContent||``);return!n||![`by creating an account`,`confirm you’re at least 18 years old`,`confirm you're at least 18 years old`,`agree to the`,`privacy statement`].some(e=>n.includes(K(e)))?0:t&&t.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING?20:10}function Zn(e){let t=K(e.textContent||``);return t&&[`we don’t share your financial details with the merchant`,`we don't share your financial details with the merchant`,`financial details`,`merchant`].some(e=>t.includes(K(e)))?10:0}function Qn(){t.storage.onChanged.addListener((e,t)=>{t===`local`&&Object.keys(e).some(e=>e.includes(`settings`))&&(H=null,Fn(),$n(100))})}function $n(e){er(),tn=window.setTimeout(()=>{tn=null,ln()},e)}function er(){tn&&=(window.clearTimeout(tn),null)}function tr(e){window.setTimeout(()=>{let e=nr();if(!e){ar();return}cn(e,!0,!1)},e)}function nr(){try{let e=sessionStorage.getItem(qt);return e?JSON.parse(e):null}catch{return null}}function rr(){try{sessionStorage.setItem(Jt,`1`)}catch{}}function ir(){try{let e=sessionStorage.getItem(Jt)===`1`;return e&&sessionStorage.removeItem(Jt),e}catch{return!1}}function ar(){try{sessionStorage.removeItem(Jt)}catch{}}function or(e){try{sessionStorage.setItem(qt,JSON.stringify(e))}catch{}}function sr(e,t){let n=t.countryCode===`RANDOM`||e.countryCode===t.countryCode,r=!t.city.trim()||K(e.city)===K(t.city);return n&&r}function cr(e){let t=e.match(/\d+/g)||[],n=(t[0]||``).padStart(2,`0`).slice(0,2),r=t[1]||``,i=r.length===2?`20${r}`:r.slice(0,4),a=i.slice(-2);return{month:n,year2:a,year4:i,short:n&&a?`${n}/${a}`:e}}function lr(e){let t=e.replace(/[^a-zA-Z]/g,``);if(t&&!e.includes(` `))return{first:t.slice(0,Math.max(1,Math.floor(t.length/2))),last:t.slice(Math.max(1,Math.floor(t.length/2)))||t};let n=e.split(/\s+/).map(e=>e.trim()).filter(Boolean);return{first:n[0]||t||`Alex`,last:n.slice(1).join(` `)||`Walker`}}function ur(e){return`${(e.identity.username||e.fullName||`outlookuser`).toLowerCase().replace(/[^a-z0-9]/g,``).slice(0,18)||`outlookuser`}${(e.id+e.fetchedAt).replace(/\D/g,``).slice(-6)||String(Date.now()).slice(-6)}@outlook.com`}function dr(e){let t=/[a-zA-Z]/.test(e),n=/\d/.test(e);if(t&&n&&e.length>=8)return e;let r=e.replace(/@.*$/,``).replace(/[^a-zA-Z0-9]/g,``)||`Paypal`;for(/[a-zA-Z]/.test(r)||(r=`Pp`+r),/\d/.test(r)||(r+=`2024`);r.length<8;)r+=`x1`;return r.charAt(0).toUpperCase()+r.slice(1)}function fr(){return location.hostname.endsWith(`paypal.com`)&&location.pathname.startsWith(`/checkoutweb/signup`)}function pr(){let e=Array.from(document.querySelectorAll(`button[type="submit"], button`));for(let t of e){if(!W(t)||t.disabled)continue;let e=K(t.textContent||``);if(e.includes(`agree and create account`)||e.includes(`同意并创建账户`)||e.includes(`同意并创建帐户`)||e.includes(`create account`)||e.includes(`创建账户`)||e.includes(`创建帐户`)){t.click(),console.info(`${Kt} 已点击创建帐户按钮`);return}}}function mr(e){return e instanceof HTMLSelectElement||e instanceof HTMLTextAreaElement?!1:[`hidden`,`radio`,`checkbox`,`submit`,`button`].includes((e.type||``).toLowerCase())}function hr(e){let t=K([e.id,e.name,`placeholder`in e?e.placeholder:``,`autocomplete`in e?e.autocomplete:``,e.getAttribute(`aria-label`),kn(e)].join(` `));return[`email`,`phone`,`mobile`,`card`,`credit`,`expiry`,`expiration`,`cvv`,`csc`,`security code`].some(e=>t.includes(e))}function W(e){let t=e;if(`disabled`in t&&t.disabled)return!1;let n=window.getComputedStyle(t),r=t.getBoundingClientRect();return n.visibility!==`hidden`&&n.display!==`none`&&r.width>0&&r.height>0}function G(e){return!!(e&&(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))}function gr(e){return!!(e&&e instanceof HTMLSelectElement)}function _r(e){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)}function K(e){return String(e||``).replace(/\s+/g,` `).trim().toLowerCase()}function vr(e){return e instanceof Error?e.message:String(e)}function yr(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var q={country:[`select#country`,`select[name="country"]`,`select[name="country.x"]`,`country`,`country or region`],email:[`input#email`,`input[name="email"]`,`input[type="email"]`,`input[autocomplete="email"]`,`email`],password:[`input#password`,`input[name="password"]`,`input[type="password"]`,`input[autocomplete="new-password"]`,`create password`,`password`],phone:[`input#phone`,`input#phoneNumber`,`input[name="phone"]`,`input[name="phoneNumber"]`,`input[type="tel"]`,`phone number`,`mobile`],cardNumber:[`input#cardNumber`,`input#card_number`,`input[name="cardNumber"]`,`input[name="card_number"]`,`input[autocomplete="cc-number"]`,`card number`,`credit card number`],expiry:[`input#expiryDate`,`input#expirationDate`,`input#cardExpiry`,`input[name="expiryDate"]`,`input[name="expirationDate"]`,`input[name="cardExpiry"]`,`input[autocomplete="cc-exp"]`,`expiration`,`expiry`,`有效期限`],expiryMonth:[`select#expMonth`,`select#expiryMonth`,`select[name="expMonth"]`,`select[name="expiryMonth"]`,`expiration month`,`expiry month`],expiryYear:[`select#expYear`,`select#expiryYear`,`select[name="expYear"]`,`select[name="expiryYear"]`,`expiration year`,`expiry year`],csc:[`input#cvv`,`input#csc`,`input#securityCode`,`input[name="cvv"]`,`input[name="csc"]`,`input[name="securityCode"]`,`input[autocomplete="cc-csc"]`,`csc`,`cvv`,`security code`],fullName:[`input#cardholderName`,`input#nameOnCard`,`input#fullName`,`input[name="cardholderName"]`,`input[name="nameOnCard"]`,`input[name="fullName"]`,`input[autocomplete="cc-name"]`,`name on card`,`full name`],firstName:[`input#firstName`,`input#billingFirstName`,`input[name="firstName"]`,`input[name="billingFirstName"]`,`input[autocomplete="given-name"]`,`first name`],lastName:[`input#lastName`,`input#billingLastName`,`input[name="lastName"]`,`input[name="billingLastName"]`,`input[autocomplete="family-name"]`,`last name`],address1:[`input#address1`,`input#addressLine1`,`input#billingAddressLine1`,`input#billingLine1`,`input[name="address1"]`,`input[name="addressLine1"]`,`input[name="billingLine1"]`,`input[autocomplete="address-line1"]`,`address line 1`,`street address`],address2:[`input#address2`,`input#addressLine2`,`input#billingAddressLine2`,`input#billingLine2`,`input[name="address2"]`,`input[name="addressLine2"]`,`input[name="billingLine2"]`,`input[autocomplete="address-line2"]`,`address line 2`],city:[`input#city`,`input#billingLocality`,`input#billingCity`,`input[name="city"]`,`input[name="billingCity"]`,`input[autocomplete="address-level2"]`,`city`],state:[`select#state`,`input#state`,`select#billingAdministrativeArea`,`input#billingAdministrativeArea`,`select#billingState`,`input#billingState`,`select[name="state"]`,`input[name="state"]`,`select[name="billingState"]`,`input[name="billingState"]`,`select[autocomplete="address-level1"]`,`input[autocomplete="address-level1"]`,`state`,`province`],postalCode:[`input#zip`,`input#postalCode`,`input#billingPostalCode`,`input#billingZip`,`input[name="zip"]`,`input[name="postalCode"]`,`input[name="billingPostalCode"]`,`input[name="billingZip"]`,`input[autocomplete="postal-code"]`,`zip code`,`postal code`]};function br(e){let n=document.createElement(`div`);n.className=`opx-summary`;let r=Sr(),i=document.createElement(`input`);i.className=`opx-input`,i.type=`text`,i.placeholder=`城市留空即随机，例如 Tokyo / Berlin / New York`,i.autocomplete=`off`;let a=document.createElement(`div`);a.className=`opx-grid`,a.append(Cr(`地址国家`,r),Cr(`指定城市`,i));let o=document.createElement(`div`);o.className=`opx-button-row opx-address-actions`;let s=wr(`获取地址`);o.append(s);let c=document.createElement(`div`);c.className=`opx-copy-list`;let l=document.createElement(`div`);l.className=`opx-status`,e.append(n,a,o,c,l),r.addEventListener(`change`,()=>void d(`国家已保存`)),i.addEventListener(`change`,()=>void d(`城市已保存`)),s.addEventListener(`click`,()=>void f());let u=async()=>{m(await L())};return u(),{update:u};async function d(e){let t=await L(),n=r.value,a=i.value.trim();m(await I({countryCode:n,city:a,lastAddress:t.countryCode!==n||t.city.trim()!==a?null:t.lastAddress})),Er(l,e,`ok`)}async function f(){s.disabled=!0,Er(l,`正在获取随机地址...`,`pending`);try{let e=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:r.value,city:i.value.trim()});if(!Or(e)||!e.ok||!e.address){Er(l,e?.message||`获取地址失败`,`error`);return}m(await I({countryCode:r.value,city:i.value.trim(),lastAddress:e.address}));let n=await p(e.address);Er(l,n?`${e.message}；${n}`:e.message,`ok`)}catch(e){Er(l,`获取地址失败：${Dr(e)}`,`error`)}finally{s.disabled=!1}}async function p(e){return location.hostname===`pay.openai.com`?(await bt(e)).message:location.hostname.endsWith(`paypal.com`)?(await cn(e,!0,!1)).message:``}function m(e){r.value=e.countryCode,i.value=e.city,h(e),g(e.lastAddress)}function h(e){n.textContent=`${r.selectedOptions[0]?.textContent||e.countryCode} · ${e.city||`随机城市`}`}function g(e){if(c.textContent=``,!e){c.append(Tr(`暂无地址，点击“获取地址”。`));return}for(let t of xr(e))c.append(v(t))}function _(e,t){let n=document.createElement(`button`);n.className=`opx-copy-row`,n.type=`button`,n.title=`点击复制`;let r=document.createElement(`span`);r.className=`opx-copy-label`,r.textContent=`${e}：`;let i=document.createElement(`strong`);i.textContent=t;let a=document.createElement(`span`);a.className=`opx-copy-feedback`,a.textContent=`已复制`,a.hidden=!0;let o=null;return n.append(r,i,a),n.addEventListener(`click`,async()=>{await navigator.clipboard.writeText(t),o&&window.clearTimeout(o),n.classList.add(`is-copied`),a.hidden=!1,o=window.setTimeout(()=>{n.classList.remove(`is-copied`),a.hidden=!0,o=null},1400)}),n}function v(e){let t=document.createElement(`div`);t.className=`opx-copy-section-body`;for(let n of e.items)n.value&&t.append(_(n.label,n.value));if(e.collapsed){let n=document.createElement(`details`);n.className=`opx-accordion-section`;let r=document.createElement(`summary`);return r.textContent=e.title,n.append(r,t),n}let n=document.createElement(`section`);n.className=`opx-copy-section`;let r=document.createElement(`div`);return r.className=`opx-copy-section-title`,r.textContent=e.title,n.append(r,t),n}}function xr(e){return[{title:`地址资料`,items:[{label:`国家`,value:`${e.countryLabel||e.countryCode} / ${e.countryCode}`},{label:`姓名`,value:e.fullName},{label:`电话`,value:e.phone},{label:`地址1`,value:e.line1},{label:`地址2`,value:e.line2},{label:`城市`,value:e.city},{label:`州/省`,value:e.stateFull?`${e.stateFull} / ${e.state}`:e.state},{label:`邮编`,value:e.postalCode}]},{title:`信用卡资料`,items:[{label:`卡类型`,value:e.creditCard.type},{label:`卡号`,value:e.creditCard.number},{label:`CVV`,value:e.creditCard.cvv},{label:`有效期`,value:e.creditCard.expires},{label:`后四位`,value:e.creditCard.last4}]},{title:`身份资料`,collapsed:!0,items:[{label:`性别`,value:e.identity.gender},{label:`称谓`,value:e.identity.title},{label:`生日`,value:e.identity.birthday},{label:`用户名`,value:e.identity.username},{label:`密码`,value:e.identity.password},{label:`临时邮箱`,value:e.identity.temporaryMail},{label:`系统`,value:e.identity.system},{label:`网站`,value:e.identity.website},{label:`安全问题`,value:e.identity.securityQuestion},{label:`安全答案`,value:e.identity.securityAnswer}]},{title:`就业资料`,collapsed:!0,items:[{label:`公司`,value:e.employment.companyName},{label:`职业`,value:e.employment.occupation},{label:`就业状态`,value:e.employment.employmentStatus},{label:`月薪`,value:e.employment.monthlySalary},{label:`公司规模`,value:e.employment.companySize},{label:`教育背景`,value:e.employment.educationalBackground}]}]}function Sr(){let e=document.createElement(`select`);e.className=`opx-select`;let t=document.createElement(`option`);t.value=`RANDOM`,t.textContent=`随机国家`,e.append(t);for(let t of ft){let n=document.createElement(`option`);n.value=t.code,n.textContent=`${t.label} / ${t.code}`,e.append(n)}return e}function Cr(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function wr(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Tr(e){let t=document.createElement(`div`);return t.className=`opx-empty-inline`,t.textContent=e,t}function Er(e,t,n){e.textContent=t,e.dataset.type=n}function Dr(e){return e instanceof Error?e.message:String(e)}function Or(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}var kr=8,Ar=4,jr=new Set([`data`,`message`,`msg`,`content`,`text`,`body`,`sms`,`otp`,`code`,`verifycode`,`verificationcode`,`captcha`,`result`,`value`]),Mr=new Set([`status`,`statuscode`,`httpstatus`,`ret`,`errno`,`errorcode`]),Nr=/^(no\s*message|no\s*sms|empty|none|null|暂无|没有|未收到)$/i,Pr=/^(ok|success|successful|true|请求成功|成功)$/i;function Fr(e){let t=[],n=[],r=new Set;return e.split(/\r?\n/).map(e=>e.trim()).filter(Boolean).forEach((e,i)=>{let a=e.indexOf(`----`);if(a<0){n.push(`第 ${i+1} 行缺少 ---- 分隔符`);return}let o=e.slice(0,a).trim(),s=e.slice(a+4).trim();if(!o||!s){n.push(`第 ${i+1} 行号码或 API 链接为空`);return}if(!Jr(s)){n.push(`第 ${i+1} 行 API 链接不是 http/https 地址`);return}let c=`${o}\n${s}`;r.has(c)||(r.add(c),t.push({id:Yr(o,s),phone:o,url:s}))}),{targets:t,errors:n}}function Ir(e){let t=e.trim();return!t||Nr.test(t)?``:t.match(RegExp(`\\b\\d{${Ar},${kr}}\\b`,`g`))?.[0]||``}function Lr(e){let t=Rr(e),n=t.map(e=>({...e,code:Ir(e.text)})).filter(e=>e.text&&!Vr(e.text)&&!Hr(e.text)).sort((e,t)=>zr(t)-zr(e))[0];return n?.code?{code:n.code,message:n.text}:{code:``,message:t.map(e=>e.text).find(e=>e&&!Vr(e)&&!Hr(e))||``}}function Rr(e){let t=[],n=new WeakSet;return r(e,``,0),t;function r(e,t,o){if(!(e==null||o>6)){if(typeof e==`string`){i(e,t,o),a(e,t,o);return}if(typeof e==`number`){Kr(t)&&i(String(e),t,o);return}if(typeof e==`object`&&!n.has(e)){if(n.add(e),Array.isArray(e)){e.forEach((e,n)=>r(e,t||String(n),o+1));return}for(let[t,n]of Object.entries(e))Gr(t)||r(n,t,o+1)}}}function i(e,n,r){let i=e.trim();!i||i.length>600||Gr(n)||t.push({text:i,key:n,depth:r,fromPreferredField:Wr(n)})}function a(e,t,n){let i=e.trim();if(!(!i||!/^[{[]/.test(i)))try{r(JSON.parse(i),t,n+1)}catch{}}}function zr(e){let t=0;return e.code&&(t+=100),e.fromPreferredField&&(t+=30),Br(e.text)&&(t+=20),Kr(e.key)&&(t+=10),Ur(e.text)&&(t-=8),t-=e.depth,t}function Br(e){return/code|验证码|驗證碼|verify|verification|security|otp|paypal|openai|chatgpt/i.test(e)}function Vr(e){return Nr.test(e.trim())}function Hr(e){return Pr.test(e.trim())}function Ur(e){return/^[{[]/.test(e.trim())}function Wr(e){return jr.has(qr(e))}function Gr(e){return Mr.has(qr(e))}function Kr(e){let t=qr(e);return t===`otp`||t===`smscode`||t===`verifycode`||t===`verificationcode`||t===`captcha`}function qr(e){return e.toLowerCase().replace(/[^a-z0-9]/g,``)}function Jr(e){try{let t=new URL(e);return t.protocol===`http:`||t.protocol===`https:`}catch{return!1}}function Yr(e,t){return`${e}|${t}`}async function Xr(e){let n;try{n=await t.runtime.sendMessage({type:`opx:fetch-sms-relay`,url:e.url})}catch(t){return{kind:`error`,target:e,message:`请求失败：${Qr(t)}`}}if(!Zr(n)||!n.ok)return{kind:`error`,target:e,message:n?.message||`API 返回结果无效`};let r=Lr({raw:n.raw,data:n.data,text:n.text,message:n.message}),i=r.message,a=r.code;return a?{kind:`code`,target:e,code:a,message:i}:{kind:`empty`,target:e,message:i||n.data||n.message||`暂无短信`}}function Zr(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function Qr(e){return e instanceof Error?e.message:String(e)}var $r=`opx.orchestrator.state`,ei=`[OPX Auto]`,ti=2e3,ni=5e3,ri=18e4,ii=!1,ai=null,oi=[],si={enabled:!1,currentStep:`idle`,statusMessage:`等待开始`,startedAt:0,completedSteps:[],lastError:``,generatedLink:``,updatedAt:0};function ci(e){return oi.push(e),()=>{oi=oi.filter(t=>t!==e)}}async function li(){return Ci((await t.storage.local.get($r))[$r])}async function J(e){let n=Ci({...await li(),...e,updatedAt:Date.now()});return await t.storage.local.set({[$r]:n}),Si(n),n}async function ui(){if(!(await Ie()).rawInput.trim()){await J({enabled:!1,currentStep:`error`,lastError:`请先在注册 tab 输入 Outlook 账号行`,statusMessage:`请先输入账号`});return}await J({enabled:!0,currentStep:`idle`,statusMessage:`自动化已启动，正在检测页面...`,startedAt:Date.now(),completedSteps:[],lastError:``,generatedLink:``}),fi()}async function di(){mi(),await J({enabled:!1,currentStep:`idle`,statusMessage:`已停止`})}function fi(){ai||(ai=window.setInterval(()=>void hi(),ti),hi())}async function pi(){let e=await li();e.enabled&&e.currentStep!==`done`&&e.currentStep!==`error`&&fi()}function mi(){ai&&=(window.clearInterval(ai),null)}async function hi(){if(!ii){ii=!0;try{let e=await li();if(!e.enabled){mi();return}await gi(e)}catch(e){console.warn(`${ei} tick error`,e),await J({currentStep:`error`,lastError:Ti(e),statusMessage:`出错：${Ti(e)}`})}finally{ii=!1}}}async function gi(e){let n=location.hostname,r=location.href;if(i()){if(e.completedSteps.includes(`fill-email`)){await Y(`wait-otp`,`已填过邮箱，等待跳转到验证码页...`);return}await Y(`fill-email`,`检测到登录页，正在填入邮箱...`);let t=await Xe().fillEmailFromInput();t.ok?await X(`fill-email`,`邮箱已填入，等待验证码页...`):await Y(`error`,t.message,t.message);return}if(h()){if(e.completedSteps.includes(`wait-otp`)){let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await X(`fill-profile`,`老号已登录，跳过资料填写`),await X(`fetch-session`,`Session 已读取：${e.session.email}`),await _i(e.session.accessToken);return}await Y(`fill-profile`,`验证码已处理，等待资料页或登录跳转...`);return}await Y(`wait-otp`,`检测到验证码页，正在等待 Outlook 验证码...`);let n=await Xe().waitForOutlookOtp();n.ok?await X(`wait-otp`,`验证码已填入：${n.code||``}`):await Y(`error`,n.message,n.message);return}if(D()){if(e.completedSteps.includes(`fill-profile`)){await Y(`fetch-session`,`资料已填，等待跳转到 chatgpt.com...`);return}await Y(`fill-profile`,`检测到资料页，正在填写...`);let t=await Xe().fillProfileAndCreate();t.ok?await X(`fill-profile`,`资料已填写并提交`):await Y(`error`,t.message,t.message);return}if(n===`chatgpt.com`&&!r.includes(`/auth`)&&!i()){if(e.completedSteps.includes(`generate-link`)&&e.generatedLink){await Y(`open-checkout`,`正在打开支付链接...`),window.location.href=e.generatedLink;return}e.completedSteps.includes(`fill-profile`)||await X(`fill-profile`,`已登录，跳过资料填写`),await Y(`fetch-session`,`正在读取 ChatGPT session...`);let n=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(!n?.ok||!n.session?.accessToken){await Y(`fetch-session`,n?.message||`等待登录完成...`);return}e.completedSteps.includes(`fetch-session`)||await X(`fetch-session`,`Session 已读取：${n.session.email}`),await _i(n.session.accessToken);return}if(n===`pay.openai.com`){if(e.completedSteps.includes(`open-checkout`)||await X(`open-checkout`,`已到达支付页`),e.completedSteps.includes(`wait-payment-page`)){await Y(`wait-payment-page`,`支付页已填写，等待跳转 PayPal...`);return}await Y(`wait-payment-page`,`支付页已到达，正在选择 PayPal 并填写地址...`),await Ei(3e3);let n=await t.runtime.sendMessage({type:`opx:fetch-random-address`,countryCode:`US`,city:``});if(n?.ok&&n?.address){let e=await bt(n.address);if(e.ok)await X(`wait-payment-page`,`支付页已填写 ${e.filled} 项，等待跳转 PayPal...`);else{Di(),await Ei(1e3);let e=n.address;Z(`#billingName`,e.fullName),Oi(`#billingCountry`,e.countryCode),await Ei(600),Z(`#billingAddressLine1`,e.line1),Z(`#billingAddressLine2`,e.line2),Z(`#billingLocality`,e.city),Z(`#billingAdministrativeArea`,e.state),Z(`#billingPostalCode`,e.postalCode),Z(`#phoneNumber`,e.phone),ki(),await X(`wait-payment-page`,`支付页已填写地址（回退方式），等待跳转 PayPal...`)}}else await Y(`wait-payment-page`,`获取地址失败，等待手动操作...`);return}if(n===`www.paypal.com`||n===`paypal.com`){if(e.completedSteps.includes(`wait-payment-page`)||await X(`wait-payment-page`,`已跳转 PayPal`),vi()){await Y(`wait-paypal-sms`,`检测到 PayPal 短信验证页，正在接码...`);let e=await yi();e.ok?(await X(`wait-paypal-sms`,`短信验证码已填入：${e.code}`),await Y(`done`,`全流程完成！`),await J({enabled:!1}),mi()):await Y(`wait-paypal-sms`,e.message)}else await Y(`wait-paypal-sms`,`PayPal 页面填写中，等待短信验证...`);return}if(n===`auth.openai.com`){if(e.completedSteps.includes(`wait-otp`)&&!e.completedSteps.includes(`fill-profile`)){if(D()){await Y(`fill-profile`,`检测到资料页，正在填写...`);let e=await Xe().fillProfileAndCreate();e.ok?await X(`fill-profile`,`资料已填写并提交`):await Y(`error`,e.message,e.message);return}let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await X(`fill-profile`,`已注册账号，跳过资料填写`),await X(`fetch-session`,`Session 已读取：${e.session.email}`),await _i(e.session.accessToken);return}await Y(`fill-profile`,`验证完成，等待页面跳转到资料页...`);return}if(e.completedSteps.includes(`fill-profile`)&&!e.completedSteps.includes(`fetch-session`)){await Y(`fetch-session`,`资料已提交，正在读取 session...`);let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(e?.ok&&e.session?.accessToken){await X(`fetch-session`,`Session 已读取：${e.session.email}`),await _i(e.session.accessToken);return}await Y(`fetch-session`,`Session 还未生成，继续等待...`);return}if(e.completedSteps.includes(`fetch-session`)&&!e.completedSteps.includes(`generate-link`)){let e=(await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`}))?.session?.accessToken||``;if(e){await _i(e);return}await Y(`generate-link`,`等待 session...`);return}await Y(e.currentStep,`在 auth.openai.com 中间页，等待跳转...`);return}}async function _i(e){await Y(`generate-link`,`正在生成 Plus 订阅链接...`);let n=await Re(),r=await t.runtime.sendMessage({type:`opx:create-checkout-link`,raw:e,options:n.checkoutOptions}),i=r?.link||r?.url||``;if(!r?.ok||!i){await Y(`error`,r?.message||`生成链接失败`,r?.message||``);return}await J({generatedLink:i}),await X(`generate-link`,`链接已生成`),await Y(`open-checkout`,`正在跳转到支付页...`),window.location.href=i}async function Y(e,t,n){let r={currentStep:e,statusMessage:t};n&&(r.lastError=n),await J(r),console.info(`${ei} [${e}] ${t}`)}async function X(e,t){let n=[...(await li()).completedSteps];n.includes(e)||n.push(e),await J({completedSteps:n,statusMessage:t}),console.info(`${ei} [DONE] ${e}: ${t}`)}function vi(){if(document.querySelector(`input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="验证码"], input[aria-label*="code" i], input[placeholder*="code" i]`)||document.querySelector(`input[name="ciBasic-0"], input[id="ci-ciBasic-0"], input[name^="ciBasic-"]`))return!0;let e=(document.body?.textContent||``).toLowerCase();return e.includes(`enter the code`)||e.includes(`verification code`)||e.includes(`输入验证码`)||e.includes(`confirm your number`)}async function yi(){let e=xi((await Be()).rawInput);if(!e.length)return{ok:!1,code:``,message:`没有配置接码 API 链接，请在接码 tab 输入`};let t=e[0],n=Date.now()+ri;for(;Date.now()<n;){let e=await Xr(t);if(e.kind===`code`&&e.code)return bi(e.code),{ok:!0,code:e.code,message:`已收到验证码：${e.code}`};await Ei(ni)}return{ok:!1,code:``,message:`等待短信验证码超时`}}function bi(e){let t=document.querySelectorAll(`input[name^="ciBasic-"]`);if(t.length>0&&e.length>=t.length){let n=Array.from(t).sort((e,t)=>(parseInt(e.name.replace(`ciBasic-`,``),10)||0)-(parseInt(t.name.replace(`ciBasic-`,``),10)||0));for(let t=0;t<n.length;t++){let r=n[t],i=e[t]||``,a=HTMLInputElement.prototype,o=Object.getOwnPropertyDescriptor(a,`value`);o?.set?o.set.call(r,i):r.value=i,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0}))}setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500);return}let n=document.querySelectorAll(`input[id^="ci-ciBasic-"]`);if(n.length>0&&e.length>=n.length){let t=Array.from(n).sort((e,t)=>(parseInt(e.id.replace(`ci-ciBasic-`,``),10)||0)-(parseInt(t.id.replace(`ci-ciBasic-`,``),10)||0));for(let n=0;n<t.length;n++){let r=t[n],i=e[n]||``,a=HTMLInputElement.prototype,o=Object.getOwnPropertyDescriptor(a,`value`);o?.set?o.set.call(r,i):r.value=i,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0}))}setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500);return}let r=document.querySelector(`input[name="otpCode"], input[data-testid="otpCode"], input[aria-label*="验证码"], input[aria-label*="code" i], input[placeholder*="code" i]`);if(!r)return;let i=HTMLInputElement.prototype,a=Object.getOwnPropertyDescriptor(i,`value`);a?.set?a.set.call(r,e):r.value=e,r.dispatchEvent(new Event(`input`,{bubbles:!0})),r.dispatchEvent(new Event(`change`,{bubbles:!0})),setTimeout(()=>{let e=document.querySelector(`button[type="submit"], button[data-testid="submit"], button.primary`);e&&!e.disabled&&e.click()},500)}function xi(e){let t=e.split(`
`).map(e=>e.trim()).filter(Boolean),n=[];for(let e of t){let t=e.split(/[\s|]+/),r=t.find(e=>e.startsWith(`http`)),i=t.find(e=>/^\+?\d{7,}$/.test(e))||``;r&&n.push({id:`${i||`auto`}-${Date.now()}`,phone:i,url:r})}return n}function Si(e){for(let t of oi)try{t(e)}catch{}}function Ci(e){if(!e||typeof e!=`object`)return{...si};let t=e;return{enabled:!!t.enabled,currentStep:wi(t.currentStep)?t.currentStep:`idle`,statusMessage:String(t.statusMessage||si.statusMessage),startedAt:Number(t.startedAt||0),completedSteps:Array.isArray(t.completedSteps)?t.completedSteps.filter(wi):[],lastError:String(t.lastError||``),generatedLink:String(t.generatedLink||``),updatedAt:Number(t.updatedAt||0)}}function wi(e){return typeof e==`string`&&[`idle`,`fill-email`,`wait-otp`,`fill-profile`,`fetch-session`,`generate-link`,`open-checkout`,`wait-payment-page`,`wait-paypal-sms`,`done`,`error`].includes(e)}function Ti(e){return e instanceof Error?e.message:String(e)}function Ei(e){return new Promise(t=>setTimeout(t,e))}function Di(){for(let e of[`[data-testid="paypal-accordion-item"]`,`#payment-method-accordion-item-title-paypal`,`button[data-testid="paypal-accordion-item-button"]`,`button[aria-label*="PayPal"]`,`[aria-label*="paypal" i]`]){let t=document.querySelector(e);if(t){t.click(),console.info(`[OPX Auto] 点击了 PayPal:`,e);return}}let e=document.querySelectorAll(`button, label, [role="button"], [role="radio"], div[class*="accordion"], div[class*="payment"]`);for(let t of Array.from(e)){let e=(t.textContent||``).toLowerCase();if(e.includes(`paypal`)&&!e.includes(`银行`)){t.click(),console.info(`[OPX Auto] 通过文本点击了 PayPal`);return}}let t=document.querySelectorAll(`input[type="radio"]`);for(let e of Array.from(t)){let t=e.closest(`label, div, li`);if(t&&(t.textContent||``).toLowerCase().includes(`paypal`)){e.click(),console.info(`[OPX Auto] 点击了 PayPal radio`);return}}console.warn(`[OPX Auto] 未找到 PayPal 选项`)}function Z(e,t){if(!t)return;let n=document.querySelector(e);if(!n||n.value===t)return;let r=HTMLInputElement.prototype,i=Object.getOwnPropertyDescriptor(r,`value`);i?.set?i.set.call(n,t):n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),n.dispatchEvent(new Event(`blur`,{bubbles:!0}))}function Oi(e,t){if(!t)return;let n=document.querySelector(e);if(!n)return;let r=Array.from(n.options).find(e=>e.value===t||e.text.toLowerCase().includes(t.toLowerCase()));r&&n.value!==r.value&&(n.value=r.value,n.dispatchEvent(new Event(`change`,{bubbles:!0})))}function ki(){let e=document.querySelectorAll(`input[type="checkbox"]`);for(let t of Array.from(e))if(!t.checked){let e=(t.closest(`label, div`)?.textContent||``).toLowerCase();(e.includes(`terms`)||e.includes(`consent`)||e.includes(`条款`)||e.includes(`同意`)||t.id.includes(`terms`))&&t.click()}}var Ai={idle:`等待开始`,"fill-email":`填入邮箱`,"wait-otp":`等待验证码`,"fill-profile":`填写资料`,"fetch-session":`读取 Session`,"generate-link":`生成订阅链接`,"open-checkout":`打开支付页`,"wait-payment-page":`等待支付页填写`,"wait-paypal-sms":`等待 PayPal 短信验证`,done:`全流程完成`,error:`出错`};function ji(e){let t=document.createElement(`div`);t.className=`opx-auto-panel`;let n=document.createElement(`div`);n.className=`opx-hint`,n.textContent=`一键自动化：输入 Outlook 账号后点击开始，全流程自动执行。`;let r=document.createElement(`div`);r.className=`opx-button-row`,r.style.marginTop=`12px`;let i=document.createElement(`button`);i.className=`opx-button`,i.type=`button`,i.textContent=`一键开始`;let a=document.createElement(`button`);a.className=`opx-button opx-button-secondary`,a.type=`button`,a.textContent=`停止`,a.disabled=!0;let o=document.createElement(`button`);o.className=`opx-button opx-button-secondary`,o.type=`button`,o.textContent=`重置`,r.append(i,a,o);let s=document.createElement(`div`);s.className=`opx-status`,s.style.marginTop=`12px`,s.textContent=`等待开始`;let c=document.createElement(`div`);c.className=`opx-steps-list`,c.style.marginTop=`12px`;let l=[`fill-email`,`wait-otp`,`fill-profile`,`fetch-session`,`generate-link`,`open-checkout`,`wait-payment-page`,`wait-paypal-sms`],u={};for(let e of l){let t=document.createElement(`div`);t.style.cssText=`display:flex;align-items:center;gap:6px;padding:3px 0;font-size:12px;color:#94a3b8;`;let n=document.createElement(`span`);n.style.cssText=`width:16px;text-align:center;`,n.textContent=`○`;let r=document.createElement(`span`);r.textContent=Ai[e],t.append(n,r),c.append(t),u[e]=t}let d=document.createElement(`div`);d.className=`opx-hint`,d.style.marginTop=`8px`,d.style.wordBreak=`break-all`,t.append(n,r,s,c,d),e.append(t),i.addEventListener(`click`,async()=>{i.disabled=!0,a.disabled=!1,await ui()}),a.addEventListener(`click`,async()=>{a.disabled=!0,i.disabled=!1,await di()}),o.addEventListener(`click`,async()=>{await di(),i.disabled=!1,a.disabled=!0,f({...Mi})}),ci(e=>{f(e)});function f(e){i.disabled=e.enabled,a.disabled=!e.enabled,s.textContent=e.statusMessage,s.dataset.type=e.currentStep===`error`?`error`:e.currentStep===`done`?`ok`:`pending`;for(let t of l){let n=u[t],r=n?.firstElementChild;!n||!r||(e.completedSteps.includes(t)?(r.textContent=`✔`,n.style.color=`#10b981`):e.currentStep===t?(r.textContent=`●`,n.style.color=`#f59e0b`):(r.textContent=`○`,n.style.color=`#94a3b8`))}e.generatedLink?d.textContent=`订阅链接：${e.generatedLink}`:d.textContent=``}let p=async()=>{f(await li())};return p(),{update:p}}var Mi={enabled:!1,currentStep:`idle`,statusMessage:`等待开始`,startedAt:0,completedSteps:[],lastError:``,generatedLink:``,updatedAt:0},Ni=[[`ID`,`印尼 / IDR`],[`DE`,`德国 / EUR`],[`JP`,`日本 / JPY`],[`US`,`美国 / USD`]];function Pi(e){let n=document.createElement(`div`);n.className=`opx-summary`;let r=document.createElement(`div`);r.className=`opx-session-card`;let i=Fi(`邮箱`,`未读取`),a=Fi(`套餐`,`未读取`),o=Fi(`Token`,`未读取`);r.append(i.row,a.row,o.row);let s=Ii(`读取 ChatGPT session`,`opx-button opx-button-secondary`),c=Ri([[`chatgptplusplan`,`ChatGPT Plus`],[`chatgptteamplan`,`ChatGPT Team`]]),l=Ri([[`custom`,`短链接 / custom`],[`hosted`,`长链接 / hosted`]]),u=Ri(Ni),d=Li(`Workspace 名称`,`text`),f=Li(`席位数量`,`number`);f.min=`2`,f.step=`1`;let p=document.createElement(`div`);p.className=`opx-grid`;let m=zi(`套餐类型`,c),h=zi(`链接形式`,l),g=zi(`计费区域`,u);p.append(m,h,g);let _=document.createElement(`div`);_.className=`opx-team-options`;let v=document.createElement(`div`);v.className=`opx-grid`,v.append(zi(`Workspace`,d),zi(`席位`,f)),_.append(v);let y=document.createElement(`textarea`);y.className=`opx-textarea opx-token-textarea`,y.placeholder=`自动读取或手动粘贴 ChatGPT session JSON / Access Token`,y.autocomplete=`off`,y.spellcheck=!1;let b=document.createElement(`div`);b.className=`opx-hint`,b.textContent=`切到提链接 tab 会读取 /api/auth/session；token 只在当前页面内使用。`;let x=Ii(`生成订阅链接`),S=document.createElement(`textarea`);S.className=`opx-textarea opx-output`,S.placeholder=`生成后的订阅链接`,S.readOnly=!0,S.spellcheck=!1;let C=document.createElement(`div`);C.className=`opx-button-row`;let w=Ii(`复制链接`,`opx-button opx-button-secondary`),T=Ii(`打开链接`,`opx-button opx-button-secondary`),E=Ii(`清空`,`opx-button opx-button-secondary`);C.append(w,T,E);let D=document.createElement(`div`);D.className=`opx-status`,D.textContent=`等待读取 ChatGPT session。`;let O=``,k=``,A=!1,ee=!1,te=async()=>{ae((await Re()).checkoutOptions)},ne=async()=>{await ie()},re=async()=>{try{let e=oe();await ze({checkoutOptions:e}),se(e),Q(D,`本地参数已更新`,`ok`)}catch(e){Q(D,Bi(e),`error`)}};for(let e of[c,l,u,d,f])e.addEventListener(`change`,()=>void re()),e.addEventListener(`input`,()=>void re());return s.addEventListener(`click`,()=>void ie()),y.addEventListener(`paste`,()=>window.setTimeout(()=>ce(!1),0)),y.addEventListener(`input`,()=>{k=``,(y.value.includes(`accessToken`)||y.value.length>900)&&ce(!1)}),x.addEventListener(`click`,async()=>{Q(D,`正在生成订阅链接...`,`pending`);let e=y.value.trim()?ce(!0):k;if(!e){Q(D,`没有 accessToken，请先读取 session 或手动粘贴。`,`error`);return}let n;try{n=oe(),await ze({checkoutOptions:n})}catch(e){Q(D,Bi(e),`error`);return}let r;try{r=await t.runtime.sendMessage({type:`opx:create-checkout-link`,raw:e,options:n})}catch(e){Q(D,`生成失败：${String(e)}`,`error`);return}let i=r?.link||r?.url||``;if(!Vi(r)||!r.ok||!i){Q(D,r?.message||`生成失败：返回结果无效`,`error`),le(``);return}le(i),Q(D,r.message,`ok`)}),w.addEventListener(`click`,async()=>{O&&(await navigator.clipboard.writeText(O),Q(D,`已复制链接`,`ok`))}),T.addEventListener(`click`,()=>{O&&window.open(O,`_blank`,`noopener,noreferrer`)}),E.addEventListener(`click`,()=>{y.value=``,k=``,b.textContent=`切到提链接 tab 会读取 /api/auth/session；token 只在当前页面内使用。`,b.classList.remove(`is-ok`),le(``),ue(``,``,``),Q(D,`已清空`,`ok`),y.focus()}),e.append(n,r,s,p,_,y,b,x,zi(`订阅链接`,S),C,D),te(),le(``),{update:te,onShow:ne};async function ie(){if(!A){A=!0,s.disabled=!0,Q(D,`正在读取 https://chatgpt.com/api/auth/session ...`,`pending`);try{let e=await t.runtime.sendMessage({type:`opx:fetch-chatgpt-session`});if(ee=!0,!Hi(e)){Q(D,`session 返回结果无效`,`error`);return}let n=e.session;ue(n?.email||``,n?.planType||``,n?.accessToken||``),n?.accessToken&&(k=n.accessToken,y.value=n.accessToken,b.textContent=`已从 ChatGPT session 读取 accessToken。`,b.classList.add(`is-ok`)),Q(D,e.message,e.ok?`ok`:`error`)}catch(e){Q(D,`读取 session 失败：${String(e)}`,`error`)}finally{s.disabled=!1,A=!1}}}function ae(e){let t=ye(e);c.value=t.planName,l.value=t.uiMode,u.value=t.region,d.value=t.workspaceName,f.value=String(t.seatQuantity),se(t)}function oe(){return ye({planName:c.value,uiMode:l.value,region:u.value,workspaceName:d.value,seatQuantity:Number(f.value||5)})}function se(e){let t=e.planName===`chatgptteamplan`?`Team · ${e.seatQuantity} seats`:`Plus`,r=e.uiMode===`hosted`?`长链接 hosted`:`短链接 custom`,i=ee?`session 已请求`:`session 待读取`;n.textContent=`${t} · ${r} · ${e.region} · ${i}`,_.hidden=e.planName!==`chatgptteamplan`,g.hidden=e.planName===`chatgptteamplan`}function ce(e){try{let e=ve(y.value);return y.value.trim()!==e&&(y.value=e),b.textContent=`已本地提取 accessToken。`,b.classList.add(`is-ok`),e}catch(t){return b.classList.remove(`is-ok`),e&&Q(D,Bi(t),`error`),``}}function le(e){O=e,S.value=e,w.disabled=!e,T.disabled=!e}function ue(e,t,n){i.value.textContent=e||`未读取`,a.value.textContent=t||`未读取`,o.value.textContent=n?`已获取`:`未获取`}}function Fi(e,t){let n=document.createElement(`div`);n.className=`opx-session-row`;let r=document.createElement(`span`);r.textContent=e;let i=document.createElement(`strong`);return i.textContent=t,n.append(r,i),{row:n,value:i}}function Ii(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Li(e,t){let n=document.createElement(`input`);return n.className=`opx-input`,n.type=t,n.placeholder=e,n}function Ri(e){let t=document.createElement(`select`);t.className=`opx-select`;for(let[n,r]of e){let e=document.createElement(`option`);e.value=n,e.textContent=r,t.append(e)}return t}function zi(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function Q(e,t,n){e.textContent=t,e.dataset.type=n}function Bi(e){return e instanceof Error?e.message:String(e)}function Vi(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function Hi(e){return!!(e&&typeof e==`object`&&typeof e.ok==`boolean`&&typeof e.message==`string`)}function Ui(e,t){let n=document.createElement(`textarea`);n.className=`opx-textarea`,n.placeholder=`邮箱或 Outlook 行`,n.autocomplete=`off`,n.spellcheck=!1;let r=document.createElement(`div`);r.className=`opx-hint`,r.textContent=`支持 user@example.com 或 email----password----client_id----refresh_token`;let i=Wi(`填入邮箱并继续`),a=document.createElement(`input`);a.className=`opx-input`,a.type=`text`,a.inputMode=`numeric`,a.placeholder=`验证码`,a.autocomplete=`one-time-code`;let o=Wi(`填入验证码并继续`),s=Wi(`自动接收并填入验证码`,`opx-button opx-button-secondary`),c=Wi(`填写资料并创建`),l=document.createElement(`div`);l.className=`opx-label`,l.textContent=`收码 API 地址（别人使用需修改）`;let u=document.createElement(`input`);u.className=`opx-input`,u.type=`text`,u.placeholder=`http://127.0.0.1:8787`,u.autocomplete=`off`,u.spellcheck=!1;let d=document.createElement(`div`);d.className=`opx-hint`,d.textContent=`⚠ 默认为本机地址，其他人使用需要改为公网收码服务地址`;let f=document.createElement(`div`);f.className=`opx-status`,f.textContent=`等待操作`;let p=new Set,m=new Set,h=e=>{e.addEventListener(`focus`,()=>p.add(e)),e.addEventListener(`blur`,()=>{p.delete(e),m.delete(e)}),e.addEventListener(`input`,()=>m.add(e)),e.addEventListener(`compositionstart`,()=>p.add(e)),e.addEventListener(`compositionend`,()=>p.add(e))};h(n),h(a),h(u);let g=e=>p.has(e)||m.has(e),_=async()=>{let e=t.getPageState(),a=await t.loadState();g(n)||n.value!==a.rawInput&&(n.value=a.rawInput),g(u)||u.value!==a.apiBase&&(u.value=a.apiBase),i.disabled=!e.canFillEmail,o.disabled=!e.canFillOtp,s.disabled=!e.canFillOtp||!a.autoOtp,c.disabled=!e.canFillProfile,r.textContent=a.autoOtp?`Outlook 行模式：验证码页会通过本地 API 自动收码`:`单邮箱模式：验证码需要手动输入`};return n.addEventListener(`input`,()=>{t.saveInput(n.value).then(e=>{m.delete(n),r.textContent=e.autoOtp?`Outlook 行模式：验证码页会通过本地 API 自动收码`:`单邮箱模式：验证码需要手动输入`})}),u.addEventListener(`input`,()=>{t.saveApiBase(u.value).then(()=>{m.delete(u)})}),i.addEventListener(`click`,async()=>{Ki(f,`正在提交邮箱...`,`pending`),await t.saveInput(n.value),Gi(f,await t.fillEmailFromInput()),await _()}),o.addEventListener(`click`,async()=>{Ki(f,`正在提交验证码...`,`pending`),Gi(f,await t.fillOtp(a.value)),await _()}),s.addEventListener(`click`,async()=>{Ki(f,`等待 Outlook 验证码...`,`pending`),Gi(f,await t.waitForOutlookOtp()),await _()}),c.addEventListener(`click`,async()=>{Ki(f,`正在填写资料...`,`pending`),Gi(f,await t.fillProfileAndCreate()),await _()}),e.append(n,r,i,a,o,s,c,l,u,d,f),_(),{update:_}}function Wi(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function Gi(e,t){Ki(e,t.message,t.ok?`ok`:`error`)}function Ki(e,t,n){e.textContent=t,e.dataset.type=n}var qi=`opx.versionCheck.state`,Ji={ignoredVersion:``,lastCheckedAt:0,latest:null};async function Yi(){return Qi((await t.storage.local.get(qi))[qi])}async function Xi(e){let n=Qi({...await Yi(),...e});return await t.storage.local.set({[qi]:n}),n}async function Zi(e){return Xi({ignoredVersion:ea(e)})}function Qi(e){let t=ta(e)?e:{};return{ignoredVersion:ea(t.ignoredVersion),lastCheckedAt:Number(t.lastCheckedAt||Ji.lastCheckedAt),latest:$i(t.latest)}}function $i(e){if(!ta(e))return null;let t=ea(e.version),n=String(e.htmlUrl||``).trim();return!t||!n?null:{version:t,tagName:String(e.tagName||t).trim(),name:String(e.name||e.tagName||t).trim(),body:String(e.body||``).trim(),htmlUrl:n,downloadUrl:String(e.downloadUrl||n).trim(),publishedAt:String(e.publishedAt||``).trim()}}function ea(e){return String(e||``).trim().replace(/^v/i,``)}function ta(e){return!!(e&&typeof e==`object`)}var na=`https://api.github.com/repos/suyancc/openai-plus-vxt/releases/latest`,ra=1800*1e3;async function ia(e=!1){let n=ca(t.runtime.getManifest().version),r=await Yi();if(!e&&r.latest&&Date.now()-r.lastCheckedAt<ra)return oa(n,r.latest,r.ignoredVersion);try{let e=await fetch(na,{headers:{Accept:`application/vnd.github+json`},cache:`no-store`});if(e.status===404)return await Xi({latest:null,lastCheckedAt:Date.now()}),{currentVersion:n,latest:null,updateAvailable:!1,ignored:!1,error:`当前仓库还没有 GitHub Release`};if(!e.ok)throw Error(`GitHub API ${e.status}`);let t=sa(await e.json());return await Xi({latest:t,lastCheckedAt:Date.now()}),oa(n,t,r.ignoredVersion)}catch(e){return{currentVersion:n,latest:r.latest,updateAvailable:!!(r.latest&&aa(r.latest.version,n)>0),ignored:!!(r.latest&&r.ignoredVersion===r.latest.version),error:e instanceof Error?e.message:String(e)}}}function aa(e,t){let n=ca(e).split(`.`).map(la),r=ca(t).split(`.`).map(la),i=Math.max(n.length,r.length);for(let e=0;e<i;e+=1){let t=(n[e]||0)-(r[e]||0);if(t!==0)return t>0?1:-1}return 0}function oa(e,t,n){return{currentVersion:e,latest:t,updateAvailable:!!(t&&aa(t.version,e)>0),ignored:!!(t&&n===t.version)}}function sa(e){let t=String(e.tag_name||``).trim(),n=ca(t),r=String(e.html_url||``).trim();if(!n||!r)return null;let i=e.assets?.find(e=>{let t=String(e.name||``).toLowerCase();return t.endsWith(`.zip`)&&t.includes(`chrome`)})?.browser_download_url||e.assets?.find(e=>String(e.name||``).toLowerCase().endsWith(`.zip`))?.browser_download_url;return{version:n,tagName:t,name:String(e.name||t).trim(),body:String(e.body||``).trim(),htmlUrl:r,downloadUrl:String(i||r).trim(),publishedAt:String(e.published_at||``).trim()}}function ca(e){return e.trim().replace(/^v/i,``)}function la(e){let t=Number.parseInt(e.replace(/\D.*$/,``),10);return Number.isFinite(t)?t:0}var ua=`https://t.me/fuck_open`;function da(e={}){let n=document.createElement(`div`);n.className=`opx-settings-overlay`,n.hidden=!0;let r=document.createElement(`section`);r.className=`opx-settings-dialog`,r.setAttribute(`role`,`dialog`),r.setAttribute(`aria-modal`,`true`),r.setAttribute(`aria-label`,`插件设置`);let i=document.createElement(`div`);i.className=`opx-settings-header`;let a=document.createElement(`div`);a.className=`opx-settings-title`;let o=document.createElement(`strong`);o.textContent=`设置`;let s=document.createElement(`span`);s.className=`opx-version-badge`,s.textContent=`v${t.runtime.getManifest().version}`;let c=ma(`×`,`关闭设置`);a.append(o,s),i.append(a,c);let l=document.createElement(`input`);l.type=`checkbox`,l.className=`opx-checkbox`;let u=document.createElement(`input`);u.type=`checkbox`,u.className=`opx-checkbox`;let d=fa(l,`OpenAI 支付页自动填写`,`用于 pay.openai.com/c/pay 页面，填写姓名、国家、地址、邮编、电话并勾选条款。`),f=fa(u,`PayPal 注册页自动填写`,`用于 paypal.com/checkoutweb/signup 页面，填写国家、邮箱、卡资料、姓名、地址和密码提示。`),p=document.createElement(`button`);p.className=`opx-external-link-button`,p.type=`button`,p.title=`立即检查 GitHub Release 最新版本`,p.textContent=`检测更新`;let m=document.createElement(`button`);m.className=`opx-external-link-button`,m.type=`button`,m.title=`打开 TG 群组`,m.append(pa(),document.createTextNode(`TG 群组：t.me/fuck_open`));let h=document.createElement(`div`);h.className=`opx-hint`,h.textContent=`国家、城市和获取地址在“地址”tab 中操作。`;let g=document.createElement(`div`);g.className=`opx-status`,r.append(i,d,f,p,m,h,g),n.append(r),c.addEventListener(`click`,v),n.addEventListener(`click`,e=>{e.target===n&&v()}),l.addEventListener(`change`,async()=>{await I({payOpenAiEnabled:l.checked}),$(g,`设置已保存`,`ok`)}),u.addEventListener(`change`,async()=>{await I({payPalSignupEnabled:u.checked}),$(g,`设置已保存`,`ok`)}),m.addEventListener(`click`,()=>{window.open(ua,`_blank`,`noopener,noreferrer`)}),p.addEventListener(`click`,async()=>{p.disabled=!0,$(g,`正在检测 GitHub 最新版本...`,`pending`);try{let t=await ia(!0);await e.onVersionChecked?.(),t.latest&&t.updateAvailable?$(g,`发现新版本 v${t.latest.version}，顶部已显示更新提示`,`ok`):t.latest?$(g,`当前已是最新版本 v${t.currentVersion}`,`ok`):$(g,t.error||`暂未找到可用 Release`,`pending`)}catch(e){$(g,e instanceof Error?e.message:String(e),`error`)}finally{p.disabled=!1}});let _=async()=>{let e=await L();l.checked=e.payOpenAiEnabled,u.checked=e.payPalSignupEnabled;let t=Number(e.payOpenAiEnabled)+Number(e.payPalSignupEnabled);$(g,t>0?`已开启 ${t} 项自动填写`:`自动填写未开启`,t>0?`ok`:`pending`)};return{element:n,open:()=>{n.hidden=!1,_()},update:_};function v(){n.hidden=!0}}function fa(e,t,n){let r=document.createElement(`div`);r.className=`opx-setting-item`;let i=document.createElement(`label`);i.className=`opx-check-row`;let a=document.createElement(`span`);a.textContent=t,i.append(e,a);let o=document.createElement(`div`);return o.className=`opx-setting-description`,o.textContent=n,r.append(i,o),r}function pa(){let e=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.classList.add(`opx-telegram-icon`),e.setAttribute(`viewBox`,`0 0 24 24`),e.setAttribute(`aria-hidden`,`true`);let t=document.createElementNS(`http://www.w3.org/2000/svg`,`path`);return t.setAttribute(`fill`,`currentColor`),t.setAttribute(`d`,`M21.9 4.3 18.7 19c-.2 1-.8 1.2-1.6.8l-4.6-3.4-2.2 2.1c-.2.2-.4.4-.9.4l.3-4.7 8.5-7.7c.4-.3-.1-.5-.6-.2L7.1 12.9 2.6 11.5c-1-.3-1-1 0-1.4L20.2 3.3c.8-.3 1.5.2 1.7 1Z`),e.append(t),e}function ma(e,t){let n=document.createElement(`button`);return n.className=`opx-icon-button`,n.type=`button`,n.textContent=e,n.title=t,n.setAttribute(`aria-label`,t),n}function $(e,t,n){e.textContent=t,e.dataset.type=n}var ha=3e3;function ga(e){let t=document.createElement(`div`);t.className=`opx-summary`;let n=document.createElement(`textarea`);n.className=`opx-textarea opx-sms-input`,n.placeholder=`+14642649811----https://xxxx.com/xxx
每行一个号码和 API 链接`,n.autocomplete=`off`,n.spellcheck=!1;let r=document.createElement(`div`);r.className=`opx-button-row opx-sms-actions`;let i=va(`保存并开始`),a=va(`立即获取`,`opx-button opx-button-secondary`),o=va(`清空历史`,`opx-button opx-button-secondary`);r.append(i,a,o);let s=ya(`当前号码`),c=document.createElement(`div`);c.className=`opx-sms-targets`;let l=ya(`验证码历史`),u=document.createElement(`div`);u.className=`opx-sms-table`;let d=document.createElement(`div`);d.className=`opx-status`;let f=new Map,p=null,m=null,h=``,g=null,_=!1;e.append(t,_a(`接码信息`,n),r,s,c,l,u,d),n.addEventListener(`input`,()=>{y(),S()}),n.addEventListener(`focus`,()=>{_=!0}),n.addEventListener(`blur`,()=>{_=!1,b()}),i.addEventListener(`click`,async()=>{await b(),S(),await w()}),a.addEventListener(`click`,async()=>{await b(),S(),await w()}),o.addEventListener(`click`,async()=>{let e=await Ve({history:[]});p=e,O(e.history),Ca(d,`验证码历史已清空，输入内容已保留。`,`ok`)});let v=async()=>{let e=await Be();p=e,!_&&n.value!==e.rawInput&&(n.value=e.rawInput,h=e.rawInput,S()),O(e.history),C()};return v(),{update:v,onShow:async()=>{await v(),x()}};function y(){g&&window.clearTimeout(g),g=window.setTimeout(()=>void b(),450)}async function b(){g&&=(window.clearTimeout(g),null);let e=n.value;e!==h&&(p=await Ve({rawInput:e}),h=e,C())}function x(){m===null&&(m=window.setInterval(()=>void w(),ha))}function S(){let e=Fr(n.value),t=new Set(e.targets.map(e=>e.id));for(let[e]of f)t.has(e)||f.delete(e);for(let t of e.targets){let e=f.get(t.id);e?e.target=t:f.set(t.id,{target:t,status:`waiting`,message:`等待获取`,code:``,lastCheckedAt:0,inFlight:!1})}if(c.textContent=``,!e.targets.length)c.append(ba(e.errors[0]||`暂无号码，按每行“号码----API链接”输入。`));else for(let t of e.targets){let e=f.get(t.id);e&&c.append(D(e))}e.errors.length?Ca(d,e.errors.join(`；`),`error`):e.targets.length?Ca(d,`已加载 ${e.targets.length} 个接码链接，每 3 秒自动获取。`,`pending`):Ca(d,`输入内容会自动保存。`,`pending`),C()}function C(){let e=Fr(n.value),r=p?.history.length||0,i=[...f.values()].filter(e=>e.code).length;t.textContent=`${e.targets.length} 个接码链接 · ${i} 个当前验证码 · ${r} 条历史`}async function w(){let e=Fr(n.value);!e.targets.length||e.errors.length||(await b(),await Promise.all(e.targets.map(e=>T(e))),S(),O(p?.history||[]))}async function T(e){let t=f.get(e.id);if(!t||t.inFlight)return;t.inFlight=!0,t.status=t.code?`found`:`waiting`,t.message=`正在获取...`,S();let n=await Xr(e);if(t.inFlight=!1,t.lastCheckedAt=Date.now(),n.kind===`code`){t.status=`found`,t.code=n.code,t.message=n.message,await E(e.phone,n.code,n.message),Ca(d,`${e.phone} 收到验证码 ${n.code}`,`ok`);return}if(n.kind===`error`){t.status=`error`,t.message=n.message,Ca(d,`${e.phone} 获取失败：${n.message}`,`error`);return}t.status=`waiting`,t.message=n.message}async function E(e,t,n){let r=p||await Be();if(r.history.some(r=>r.phone===e&&r.code===t&&r.message===n)){p=r;return}p=await Ve({history:[{id:`${e}-${t}-${Date.now()}`,phone:e,code:t,message:n,receivedAt:Date.now()},...r.history].slice(0,80)})}function D(e){let t=document.createElement(`div`);t.className=`opx-sms-target-row`,t.dataset.status=e.status;let n=document.createElement(`div`);n.className=`opx-sms-target-main`;let r=document.createElement(`strong`);r.textContent=e.target.phone;let i=document.createElement(`span`);i.textContent=e.code?e.message:e.message||`等待获取`,n.append(r,i);let a=document.createElement(`button`);return a.className=`opx-sms-code-chip`,a.type=`button`,a.textContent=e.code||(e.inFlight?`...`:`等待`),a.disabled=!e.code,a.title=e.code?`点击复制验证码`:`尚未收到验证码`,a.addEventListener(`click`,()=>void k(e.code,a)),t.append(n,a),t}function O(e){u.textContent=``;let t=document.createElement(`div`);if(t.className=`opx-sms-table-row opx-sms-table-head`,t.append(xa(`号码`),xa(`验证码`),xa(`时间`)),u.append(t),!e.length){let e=document.createElement(`div`);e.className=`opx-empty-inline`,e.textContent=`暂无验证码历史。`,u.append(e);return}for(let t of e){let e=document.createElement(`div`);e.className=`opx-sms-table-row`;let n=document.createElement(`button`);n.className=`opx-sms-code-chip`,n.type=`button`,n.textContent=t.code,n.title=t.message||`点击复制验证码`,n.addEventListener(`click`,()=>void k(t.code,n)),e.append(xa(t.phone),Sa(n),xa(wa(t.receivedAt))),u.append(e)}}async function k(e,t){if(!e)return;await navigator.clipboard.writeText(e);let n=t.textContent||e;t.textContent=`已复制`,t.classList.add(`is-copied`),window.setTimeout(()=>{t.textContent=n,t.classList.remove(`is-copied`)},1200)}}function _a(e,t){let n=document.createElement(`label`);n.className=`opx-field`;let r=document.createElement(`span`);return r.className=`opx-label`,r.textContent=e,n.append(r,t),n}function va(e,t=`opx-button`){let n=document.createElement(`button`);return n.className=t,n.type=`button`,n.textContent=e,n}function ya(e){let t=document.createElement(`div`);return t.className=`opx-section-title`,t.textContent=e,t}function ba(e){let t=document.createElement(`div`);return t.className=`opx-empty-inline`,t.textContent=e,t}function xa(e){let t=document.createElement(`div`);return t.className=`opx-sms-table-cell`,t.textContent=e,t}function Sa(e){let t=document.createElement(`div`);return t.className=`opx-sms-table-cell`,t.append(e),t}function Ca(e,t,n){e.textContent=t,e.dataset.type=n}function wa(e){return e?new Date(e).toLocaleTimeString(`zh-CN`,{hour12:!1,hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):`-`}function Ta(){let e=document.createElement(`section`);e.className=`opx-version-notice`,e.hidden=!0;let t=document.createElement(`div`);t.className=`opx-version-notice-title`;let n=document.createElement(`div`);n.className=`opx-version-notice-body`;let r=document.createElement(`div`);r.className=`opx-version-notice-actions`;let i=document.createElement(`button`);i.className=`opx-mini-button`,i.type=`button`,i.textContent=`下载更新`;let a=document.createElement(`button`);a.className=`opx-mini-button opx-mini-button-secondary`,a.type=`button`,a.textContent=`更新说明`;let o=document.createElement(`button`);o.className=`opx-mini-button opx-mini-button-secondary`,o.type=`button`,o.textContent=`忽略`,r.append(i,a,o),e.append(t,n,r);let s=null;return i.addEventListener(`click`,()=>{s?.downloadUrl&&window.open(s.downloadUrl,`_blank`,`noopener,noreferrer`)}),a.addEventListener(`click`,()=>{s?.htmlUrl&&window.open(s.htmlUrl,`_blank`,`noopener,noreferrer`)}),o.addEventListener(`click`,async()=>{s&&(await Zi(s.version),e.hidden=!0)}),{element:e,update:async(r=!1)=>{let i=await ia(r);s=i.latest,Ea(i,e,t,n)}}}function Ea(e,t,n,r){if(!e.latest||!e.updateAvailable||e.ignored){t.hidden=!0;return}n.textContent=`发现新版本 v${e.latest.version}`,r.textContent=Da(e.currentVersion,e.latest),t.hidden=!1}function Da(e,t){let n=t.body.split(/\r?\n/).map(e=>e.replace(/^#+\s*/,``).trim()).filter(Boolean).slice(0,2).join(` / `),r=`当前 v${e}，最新 ${t.tagName||`v${t.version}`}`;return n?`${r}。${n}`:r}var Oa=`
:host {
  all: initial;
  color-scheme: light dark;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.opx-shell {
  position: fixed;
  top: 72px;
  right: 0;
  z-index: 2147483647;
  display: flex;
  align-items: flex-start;
  max-height: calc(100vh - 88px);
}

.opx-panel {
  box-sizing: border-box;
  width: min(320px, calc(100vw - 42px));
  max-height: calc(100vh - 88px);
  margin-right: 18px;
  padding: 10px;
  border: 1px solid rgba(54, 211, 153, 0.28);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.32);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-color: rgba(47, 209, 124, 0.55) rgba(15, 23, 42, 0.72);
  scrollbar-width: thin;
}

.opx-panel::-webkit-scrollbar {
  width: 8px;
}

.opx-panel::-webkit-scrollbar-track {
  background: rgba(15, 23, 42, 0.72);
  border-radius: 999px;
}

.opx-panel::-webkit-scrollbar-thumb {
  background: rgba(47, 209, 124, 0.55);
  border-radius: 999px;
}

.opx-collapse-toggle {
  box-sizing: border-box;
  width: 32px;
  min-height: 64px;
  margin: 8px 0 0 0;
  padding: 8px 6px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-right: 0;
  border-radius: 8px 0 0 8px;
  background: #0b1220;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 14px;
  writing-mode: vertical-rl;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.28);
}

.opx-shell.is-collapsed .opx-panel {
  display: none;
}

.opx-shell.is-collapsed .opx-collapse-toggle {
  margin-right: 0;
  border-radius: 8px 0 0 8px;
  background: #102019;
}

.opx-topbar {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 34px;
  gap: 6px;
  align-items: stretch;
  margin-bottom: 8px;
}

.opx-tabs {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 4px;
  margin-bottom: 0;
  padding: 3px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 8px;
  background: rgba(15, 23, 42, 0.8);
}

.opx-tab {
  height: 30px;
  min-width: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 650;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-tab.is-active {
  background: #2fd17c;
  color: #04130a;
}

.opx-icon-button {
  box-sizing: border-box;
  width: 34px;
  height: 36px;
  border: 1px solid rgba(47, 209, 124, 0.36);
  border-radius: 8px;
  background: #111827;
  color: #93e4bd;
  cursor: pointer;
  font: inherit;
  font-size: 17px;
  font-weight: 700;
  line-height: 1;
}

.opx-icon-button:hover {
  border-color: rgba(47, 209, 124, 0.74);
  color: #bbf7d0;
}

.opx-state {
  margin: 0 0 8px;
  color: #93e4bd;
  font-size: 12px;
  line-height: 16px;
}

.opx-version-notice {
  display: grid;
  gap: 7px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.42);
  border-radius: 7px;
  background: rgba(47, 209, 124, 0.1);
  color: #dcfce7;
}

.opx-version-notice[hidden] {
  display: none;
}

.opx-version-notice-title {
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 800;
  line-height: 16px;
}

.opx-version-notice-body {
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

.opx-version-notice-actions {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 54px;
  gap: 5px;
}

.opx-mini-button {
  box-sizing: border-box;
  min-width: 0;
  height: 28px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 11px;
  font-weight: 750;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-mini-button-secondary {
  border: 1px solid rgba(47, 209, 124, 0.34);
  background: rgba(15, 23, 42, 0.72);
  color: #93e4bd;
}

.opx-view {
  display: block;
}

.opx-view[hidden] {
  display: none;
}

.opx-empty-view {
  min-height: 84px;
  display: grid;
  place-items: center;
  border: 1px dashed rgba(148, 163, 184, 0.28);
  border-radius: 8px;
  color: #94a3b8;
  font-size: 13px;
}

.opx-input,
.opx-select,
.opx-textarea {
  box-sizing: border-box;
  width: 100%;
  height: 36px;
  margin: 0 0 8px;
  padding: 0 10px;
  border: 1px solid rgba(148, 163, 184, 0.32);
  border-radius: 6px;
  background: #111827;
  color: #e5f7ef;
  font: inherit;
  font-size: 13px;
  outline: none;
}

.opx-select {
  appearance: none;
}

.opx-textarea {
  min-height: 72px;
  max-height: 140px;
  padding: 9px 10px;
  resize: vertical;
  line-height: 18px;
}

.opx-input:focus,
.opx-select:focus,
.opx-textarea:focus {
  border-color: #2fd17c;
}

.opx-hint {
  margin: -2px 0 8px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-hint.is-ok {
  color: #86efac;
}

.opx-summary {
  margin: 0 0 8px;
  padding: 7px 8px;
  border: 1px solid rgba(47, 209, 124, 0.28);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.08);
  color: #bbf7d0;
  font-size: 11px;
  line-height: 15px;
  word-break: break-word;
  white-space: pre-line;
}

.opx-session-card {
  display: grid;
  gap: 5px;
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-session-row {
  display: grid;
  grid-template-columns: 42px minmax(0, 1fr);
  gap: 6px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-session-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  word-break: break-word;
}

.opx-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 8px;
}

.opx-team-options[hidden] {
  display: none;
}

.opx-field {
  display: block;
  min-width: 0;
}

.opx-label {
  display: block;
  margin: 0 0 4px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 14px;
}

.opx-token-textarea {
  min-height: 92px;
}

.opx-output {
  min-height: 58px;
  resize: vertical;
}

.opx-button-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 6px;
}

.opx-address-actions {
  grid-template-columns: minmax(0, 1fr);
}

.opx-button {
  box-sizing: border-box;
  width: 100%;
  height: 34px;
  margin: 0 0 10px;
  border: 0;
  border-radius: 6px;
  background: #2fd17c;
  color: #04130a;
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
}

.opx-button-secondary {
  background: #182235;
  color: #93e4bd;
  border: 1px solid rgba(47, 209, 124, 0.36);
}

.opx-button:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}

.opx-status {
  min-height: 18px;
  color: #cbd5e1;
  font-size: 12px;
  line-height: 18px;
  word-break: break-word;
}

.opx-status[data-type="ok"] {
  color: #86efac;
}

.opx-status[data-type="error"] {
  color: #fca5a5;
}

.opx-settings-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: grid;
  place-items: start center;
  padding: 22px 10px;
  background: rgba(2, 6, 23, 0.58);
}

.opx-settings-overlay[hidden] {
  display: none;
}

.opx-settings-dialog {
  box-sizing: border-box;
  width: min(300px, calc(100vw - 52px));
  max-height: calc(100vh - 44px);
  overflow-y: auto;
  padding: 10px;
  border: 1px solid rgba(47, 209, 124, 0.38);
  border-radius: 8px;
  background: #0b1220;
  color: #e5f7ef;
  box-shadow: 0 20px 52px rgba(0, 0, 0, 0.42);
}

.opx-settings-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 0 0 10px;
  color: #bbf7d0;
  font-size: 14px;
  line-height: 18px;
}

.opx-settings-title {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}

.opx-version-badge {
  padding: 1px 6px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.08);
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 16px;
}

.opx-settings-header .opx-icon-button {
  width: 28px;
  height: 28px;
  font-size: 18px;
}

.opx-settings-dialog .opx-grid {
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
}

.opx-setting-item {
  margin: 0 0 8px;
  padding: 8px;
  border: 1px solid rgba(47, 209, 124, 0.22);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.54);
}

.opx-setting-item .opx-check-row {
  margin-bottom: 4px;
}

.opx-setting-description {
  margin-left: 26px;
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-external-link-button {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  width: 100%;
  min-height: 34px;
  margin: 0 0 8px;
  padding: 8px 10px;
  border: 1px solid rgba(47, 209, 124, 0.34);
  border-radius: 6px;
  background: rgba(47, 209, 124, 0.1);
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  text-align: left;
}

.opx-telegram-icon {
  flex: 0 0 auto;
  width: 14px;
  height: 14px;
}

.opx-external-link-button:hover {
  border-color: rgba(47, 209, 124, 0.7);
  background: rgba(47, 209, 124, 0.16);
  color: #dcfce7;
}

.opx-external-link-button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-check-row {
  display: grid;
  grid-template-columns: 18px minmax(0, 1fr);
  gap: 8px;
  align-items: center;
  margin: 0 0 10px;
  color: #e5f7ef;
  cursor: pointer;
  font-size: 12px;
  line-height: 16px;
}

.opx-checkbox {
  width: 16px;
  height: 16px;
  accent-color: #2fd17c;
}

.opx-address-summary {
  min-height: 68px;
}

.opx-settings-buttons {
  margin-top: 2px;
}

.opx-section-title {
  margin: 10px 0 6px;
  color: #bbf7d0;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
}

.opx-copy-list {
  display: grid;
  gap: 5px;
}

.opx-copy-section {
  display: grid;
  gap: 5px;
  margin: 5px 0 1px;
}

.opx-copy-section-title {
  color: #93e4bd;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
}

.opx-copy-section-body {
  display: grid;
  gap: 5px;
}

.opx-accordion-section {
  overflow: hidden;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.56);
}

.opx-accordion-section summary {
  padding: 7px 8px;
  color: #93e4bd;
  cursor: pointer;
  font-size: 11px;
  font-weight: 700;
  line-height: 15px;
  list-style-position: inside;
}

.opx-accordion-section .opx-copy-section-body {
  padding: 0 6px 6px;
}

.opx-copy-row,
.opx-empty-inline {
  box-sizing: border-box;
  width: 100%;
  min-height: 30px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
  color: #cbd5e1;
  font: inherit;
  font-size: 11px;
  line-height: 15px;
  text-align: left;
  word-break: break-word;
}

.opx-copy-row {
  cursor: pointer;
}

.opx-copy-row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 4px;
  align-items: start;
}

.opx-copy-row:hover {
  border-color: rgba(47, 209, 124, 0.48);
  color: #e5f7ef;
}

.opx-copy-row.is-copied {
  border-color: rgba(47, 209, 124, 0.72);
  background: rgba(47, 209, 124, 0.12);
}

.opx-copy-label {
  color: #94a3b8;
  white-space: nowrap;
}

.opx-copy-row strong {
  min-width: 0;
  color: #e5f7ef;
  font-weight: 600;
  overflow-wrap: anywhere;
}

.opx-copy-feedback {
  align-self: start;
  padding: 1px 5px;
  border-radius: 999px;
  background: rgba(47, 209, 124, 0.16);
  color: #86efac !important;
  font-size: 10px;
  font-weight: 700;
  line-height: 14px;
  white-space: nowrap;
}

.opx-copy-feedback[hidden] {
  display: none;
}

.opx-empty-inline {
  color: #94a3b8;
  border-style: dashed;
}

.opx-sms-input {
  min-height: 88px;
}

.opx-sms-actions {
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.86fr) minmax(0, 0.86fr);
}

.opx-sms-targets {
  display: grid;
  gap: 6px;
}

.opx-sms-target-row {
  box-sizing: border-box;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  min-height: 44px;
  padding: 7px 8px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.72);
}

.opx-sms-target-row[data-status="found"] {
  border-color: rgba(47, 209, 124, 0.5);
  background: rgba(47, 209, 124, 0.1);
}

.opx-sms-target-row[data-status="error"] {
  border-color: rgba(248, 113, 113, 0.42);
  background: rgba(127, 29, 29, 0.2);
}

.opx-sms-target-main {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.opx-sms-target-main strong,
.opx-sms-target-main span {
  min-width: 0;
  overflow-wrap: anywhere;
}

.opx-sms-target-main strong {
  color: #e5f7ef;
  font-size: 12px;
  line-height: 16px;
}

.opx-sms-target-main span {
  color: #94a3b8;
  font-size: 11px;
  line-height: 15px;
}

.opx-sms-code-chip {
  box-sizing: border-box;
  min-width: 56px;
  max-width: 92px;
  min-height: 28px;
  padding: 4px 8px;
  border: 1px solid rgba(47, 209, 124, 0.44);
  border-radius: 999px;
  background: #182235;
  color: #bbf7d0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  line-height: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.opx-sms-code-chip:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.opx-sms-code-chip.is-copied {
  background: #2fd17c;
  color: #04130a;
}

.opx-sms-table {
  display: grid;
  gap: 5px;
}

.opx-sms-table-row {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(64px, 0.8fr) 62px;
  gap: 6px;
  align-items: center;
  min-height: 32px;
  padding: 5px 6px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 6px;
  background: rgba(15, 23, 42, 0.58);
}

.opx-sms-table-head {
  min-height: 24px;
  background: transparent;
  border-color: transparent;
  color: #93e4bd;
  font-weight: 700;
}

.opx-sms-table-cell {
  min-width: 0;
  color: #cbd5e1;
  font-size: 11px;
  line-height: 15px;
  overflow-wrap: anywhere;
}

@media (max-height: 640px) {
  .opx-shell {
    top: 12px;
    max-height: calc(100vh - 24px);
  }

  .opx-panel {
    max-height: calc(100vh - 24px);
  }
}
`;function ka(e,t){e.innerHTML=``;let n=document.createElement(`style`);n.textContent=Oa;let r=document.createElement(`div`);r.className=`opx-shell`;let i=document.createElement(`button`);i.className=`opx-collapse-toggle`,i.type=`button`,i.textContent=`收起`,i.title=`收起侧边栏`,i.setAttribute(`aria-expanded`,`true`);let a=document.createElement(`aside`);a.className=`opx-panel`;let o=document.createElement(`div`);o.className=`opx-topbar`;let s=document.createElement(`div`);s.className=`opx-tabs`;let c=Ma(`register`,`注册`),l=Ma(`link`,`提链接`),u=Ma(`address`,`地址`),d=Ma(`sms`,`接码`),f=Ma(`auto`,`一键`);s.append(f,c,l,u,d);let p=document.createElement(`button`);p.className=`opx-icon-button`,p.type=`button`,p.textContent=`⚙`,p.title=`打开设置`,p.setAttribute(`aria-label`,`打开设置`);let m=document.createElement(`div`);m.className=`opx-state`;let h=ja(),g=ja(),_=ja(),v=ja(),y=ja(),b={auto:ji(y),register:Ui(h,t),link:Pi(g),address:br(_),sms:ga(v)},x=Ta(),S=da({onVersionChecked:()=>x.update(!0)}),C=`auto`,w=e=>{r.classList.toggle(`is-collapsed`,e),i.textContent=e?`展开`:`收起`,i.title=e?`展开侧边栏`:`收起侧边栏`,i.setAttribute(`aria-expanded`,e?`false`:`true`)},T=async e=>{He(e)&&(C=e,await Pe(e),E(),await b[e].onShow?.(),await D())},E=()=>{for(let e of[f,c,l,u,d])e.classList.toggle(`is-active`,e.dataset.tab===C);y.hidden=C!==`auto`,h.hidden=C!==`register`,g.hidden=C!==`link`,_.hidden=C!==`address`,v.hidden=C!==`sms`},D=async()=>{let e=await M();C=e.activeTab,w(e.panelCollapsed),E(),m.textContent=Aa(C,t),await b[C].update()};c.addEventListener(`click`,()=>void T(`register`)),l.addEventListener(`click`,()=>void T(`link`)),u.addEventListener(`click`,()=>void T(`address`)),d.addEventListener(`click`,()=>void T(`sms`)),f.addEventListener(`click`,()=>void T(`auto`)),p.addEventListener(`click`,()=>S.open()),i.addEventListener(`click`,()=>{let e=!r.classList.contains(`is-collapsed`);w(e),Fe(e)}),o.append(s,p),a.append(o,x.element,m,y,h,g,_,v,S.element),r.append(i,a),e.append(n,r),window.setInterval(()=>void D(),1e3),window.setTimeout(()=>void x.update(),800),D().then(()=>{b[C].onShow?.()})}function Aa(e,t){return e===`auto`?`一键自动化`:e===`register`?t.getPageState().label:e===`link`?`提链接：ChatGPT session`:e===`address`?`地址：随机资料`:`接码：短信验证码`}function ja(){let e=document.createElement(`section`);return e.className=`opx-view`,e}function Ma(e,t){let n=document.createElement(`button`);return n.className=`opx-tab`,n.type=`button`,n.dataset.tab=e,n.textContent=t,n}var Na=`opx-assistant-root`;function Pa(){if(document.getElementById(Na))return;let e=document.createElement(`div`);e.id=Na,document.documentElement.append(e);let t=e.attachShadow({mode:`open`}),n=Xe();ka(t,n),n.autoRunForCurrentPage()}var Fa=`__opx_assistant_content_loaded__`,Ia=e({matches:[`https://chatgpt.com/*`,`https://auth.openai.com/*`,`https://pay.openai.com/*`,`https://www.paypal.com/*`,`https://paypal.com/*`],runAt:`document_idle`,registration:`manifest`,main(){let e=globalThis;if(!e[Fa]){e[Fa]=!0,Pa();try{vt()}catch(e){console.warn(`[OPX] pay autofill init failed`,e)}try{sn()}catch(e){console.warn(`[OPX] PayPal autofill init failed`,e)}try{pi()}catch(e){console.warn(`[OPX] orchestrator resume failed`,e)}}}}),La={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},Ra=class e extends Event{static EVENT_NAME=za(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function za(e){return`${t?.runtime?.id}:content:${e}`}var Ba=typeof globalThis.navigation?.addEventListener==`function`;function Va(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Ba?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Ra(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Ra(e,t)),t=e)},1e3))}}}var Ha=class e{static SCRIPT_STARTED_MESSAGE_TYPE=za(`wxt:content-script-started`);id;abortController;locationWatcher=Va(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?za(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),La.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Ua={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Ia;return await e(new Ha(`content`,t))}catch(e){throw Ua.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;