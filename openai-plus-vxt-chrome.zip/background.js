// OpenAI Plus VXT - Background Service Worker
const browser = (typeof chrome !== 'undefined') ? chrome : self.browser;
function defineBackground(fn) { fn(); }


// src/features/address-autofill/address-source.ts
var MEIGUO_ADDRESS_ENDPOINT = "https://www.meiguodizhi.com/api/v1/dz";
var ADDRESS_COUNTRY_OPTIONS = [
  { code: "US", label: "\u7F8E\u56FD", path: "/" },
  { code: "CA", label: "\u52A0\u62FF\u5927", path: "/ca-address" },
  { code: "AU", label: "\u6FB3\u5927\u5229\u4E9A", path: "/au-address" },
  { code: "JP", label: "\u65E5\u672C", path: "/jp-address" },
  { code: "TW", label: "\u53F0\u6E7E", path: "/tw-address" },
  { code: "KR", label: "\u97E9\u56FD", path: "/kr-address" },
  { code: "HK", label: "\u9999\u6E2F", path: "/hk-address" },
  { code: "GB", label: "\u82F1\u56FD", path: "/uk-address" },
  { code: "DE", label: "\u5FB7\u56FD", path: "/de-address" },
  { code: "SG", label: "\u65B0\u52A0\u5761", path: "/sg-address" },
  { code: "FR", label: "\u6CD5\u56FD", path: "/fr-address" },
  { code: "IT", label: "\u610F\u5927\u5229", path: "/it-address" },
  { code: "ES", label: "\u897F\u73ED\u7259", path: "/es-address" },
  { code: "NL", label: "\u8377\u5170", path: "/nl-address" },
  { code: "MY", label: "\u9A6C\u6765\u897F\u4E9A", path: "/my-address" },
  { code: "RU", label: "\u4FC4\u7F57\u65AF", path: "/ru-address" },
  { code: "CN", label: "\u4E2D\u56FD", path: "/cn-address" },
  { code: "TH", label: "\u6CF0\u56FD", path: "/th-address" },
  { code: "PH", label: "\u83F2\u5F8B\u5BBE", path: "/ph-address" },
  { code: "AR", label: "\u963F\u6839\u5EF7", path: "/ar-address" },
  { code: "TR", label: "\u571F\u8033\u5176", path: "/tr-address" },
  { code: "VN", label: "\u8D8A\u5357", path: "/vn-address" }
];
var FALLBACK_ADDRESSES = [
  { countryCode: "US", countryLabel: "\u7F8E\u56FD", countryPath: "/", state: "CA", stateFull: "California", city: "Mountain View", postalCode: "94040", line1: "2685 California Street" },
  { countryCode: "CA", countryLabel: "\u52A0\u62FF\u5927", countryPath: "/ca-address", state: "Ontario", stateFull: "Ontario", city: "Toronto", postalCode: "M4W 1J7", line1: "909 Yonge Street" },
  { countryCode: "AU", countryLabel: "\u6FB3\u5927\u5229\u4E9A", countryPath: "/au-address", state: "NSW", stateFull: "New South Wales", city: "Sydney", postalCode: "2000", line1: "25 Market Street" },
  { countryCode: "GB", countryLabel: "\u82F1\u56FD", countryPath: "/uk-address", state: "England", stateFull: "England", city: "London", postalCode: "EC3C 6SB", line1: "78 Wardour St" },
  { countryCode: "DE", countryLabel: "\u5FB7\u56FD", countryPath: "/de-address", state: "Berlin", stateFull: "Berlin", city: "Berlin", postalCode: "10115", line1: "Rosenthaler Str. 89" },
  { countryCode: "JP", countryLabel: "\u65E5\u672C", countryPath: "/jp-address", state: "Tokyo", stateFull: "Tokyo", city: "Tokyo", postalCode: "124-0006", line1: "Horikiri, Katsushika-ku" },
  { countryCode: "SG", countryLabel: "\u65B0\u52A0\u5761", countryPath: "/sg-address", state: "Singapore", stateFull: "Singapore", city: "Singapore", postalCode: "039594", line1: "3 Temasek Boulevard" }
];
var FIRST_NAMES = ["Alex", "Blake", "Casey", "Drew", "Evan", "Jamie", "Jordan", "Morgan", "Riley", "Taylor"];
var LAST_NAMES = ["Adams", "Baker", "Carter", "Davis", "Evans", "Miller", "Parker", "Reed", "Turner", "Walker"];
async function fetchRandomAddress(countryCode, city) {
  const country = resolveCountry(countryCode);
  const normalizedCity = normalizeSearchValue(city || "");
  try {
    const address = await fetchMeiguoAddress(country, normalizedCity);
    return {
      ok: true,
      message: `\u5DF2\u83B7\u53D6 ${address.countryLabel} ${address.city} \u5730\u5740`,
      address
    };
  } catch (error) {
    const address = createFallbackAddress(country, normalizedCity);
    return {
      ok: true,
      message: `\u5730\u5740\u7AD9\u70B9\u6682\u4E0D\u53EF\u7528\uFF0C\u5DF2\u4F7F\u7528\u5185\u7F6E\u5907\u7528\u5730\u5740\uFF1A${errorMessage(error)}`,
      address
    };
  }
}
async function fetchMeiguoAddress(country, city) {
  const response = await fetch(MEIGUO_ADDRESS_ENDPOINT, {
    method: "POST",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify({
      city,
      path: country.path,
      method: city ? "refresh" : "address"
    })
  });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  const payload = await response.json();
  if (payload.status !== "ok" || !payload.address) {
    throw new Error(payload.status || "empty address");
  }
  return normalizeMeiguoAddress(payload.address, country);
}
function normalizeMeiguoAddress(source, country) {
  const state = clean(source.State);
  const city = toTitleCaseIfAscii(clean(source.City));
  const zip = clean(source.Zip_Code);
  const line1 = clean(source.Trans_Address) || clean(source.Address);
  if (!state || !city || !zip || !line1) {
    throw new Error("address payload missing required fields");
  }
  return {
    id: createAddressId(),
    fullName: toAsciiName(clean(source.Full_Name)) || randomName(),
    line1,
    line2: `Apt ${randomInt(100, 999)}`,
    city,
    state: country.code === "US" ? state.toUpperCase() : state,
    stateFull: clean(source.State_Full),
    postalCode: zip,
    countryCode: country.code,
    countryLabel: country.label,
    countryPath: country.path,
    phone: normalizePhone(clean(source.Telephone)),
    identity: {
      gender: clean(source.Gender),
      title: clean(source.Title),
      birthday: clean(source.Birthday),
      username: clean(source.Username),
      password: clean(source.Password),
      temporaryMail: clean(source.Temporary_mail),
      system: clean(source.System),
      userAgent: clean(source.Browser_User_Agent),
      website: clean(source.Website),
      securityQuestion: clean(source.Security_Question),
      securityAnswer: clean(source.Security_Answer)
    },
    employment: {
      educationalBackground: clean(source.Educational_Background),
      occupation: clean(source.Occupation),
      employmentStatus: clean(source.Employment_Status),
      monthlySalary: clean(source.Monthly_Salary),
      companySize: clean(source.Company_Size),
      companyName: clean(source.Company_Name)
    },
    creditCard: normalizeCreditCard(source),
    source: "meiguodizhi",
    fetchedAt: Date.now()
  };
}
function createFallbackAddress(country, city) {
  const fallback = FALLBACK_ADDRESSES.find((item) => item.countryCode === country.code) || FALLBACK_ADDRESSES.find((item) => item.countryCode === "US") || randomItem(FALLBACK_ADDRESSES);
  return {
    id: createAddressId(),
    fullName: randomName(),
    line1: fallback.line1,
    line2: `Apt ${randomInt(100, 999)}`,
    city: city || fallback.city,
    state: fallback.state,
    stateFull: fallback.stateFull,
    postalCode: fallback.postalCode,
    countryCode: fallback.countryCode,
    countryLabel: fallback.countryLabel,
    countryPath: fallback.countryPath,
    phone: `415${randomDigits(7)}`,
    identity: {
      gender: "",
      title: "",
      birthday: "",
      username: `user${randomDigits(6)}`,
      password: "",
      temporaryMail: "",
      system: "",
      userAgent: "",
      website: "",
      securityQuestion: "",
      securityAnswer: ""
    },
    employment: {
      educationalBackground: "",
      occupation: "",
      employmentStatus: "",
      monthlySalary: "",
      companySize: "",
      companyName: ""
    },
    creditCard: {
      type: "",
      number: "",
      cvv: "",
      expires: "",
      last4: "",
      maskedNumber: ""
    },
    source: "fallback",
    fetchedAt: Date.now()
  };
}
function resolveCountry(countryCode) {
  const normalized = normalizeSearchValue(countryCode || "");
  const upper = normalized.toUpperCase();
  if (!normalized || upper === "RANDOM") {
    return randomItem(ADDRESS_COUNTRY_OPTIONS);
  }
  return ADDRESS_COUNTRY_OPTIONS.find((item) => item.code === upper) || ADDRESS_COUNTRY_OPTIONS.find((item) => item.path === normalized) || ADDRESS_COUNTRY_OPTIONS.find((item) => item.label === normalized) || ADDRESS_COUNTRY_OPTIONS[0];
}
function normalizeSearchValue(value) {
  return value.replace(/\s+/g, " ").trim();
}
function clean(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}
function toTitleCaseIfAscii(value) {
  if (/[^a-zA-Z\s-]/.test(value)) {
    return value;
  }
  return value.toLowerCase().replace(/\b[a-z]/g, (char) => char.toUpperCase());
}
function toAsciiName(value) {
  return value.replace(/[^a-zA-Z]/g, "") || "";
}
function normalizePhone(value) {
  const digits = value.replace(/\D/g, "");
  if (digits.length >= 10) {
    return digits.slice(-10);
  }
  return `415${randomDigits(7)}`;
}
function normalizeCreditCard(source) {
  const number = clean(source.Credit_Card_Number).replace(/\D/g, "");
  const last4 = number.length >= 4 ? number.slice(-4) : "";
  return {
    type: clean(source.Credit_Card_Type),
    number,
    cvv: clean(source.CVV2),
    expires: clean(source.Expires),
    last4,
    maskedNumber: last4 ? `**** **** **** ${last4}` : ""
  };
}
function createAddressId() {
  return `${Date.now()}-${randomDigits(6)}`;
}
function randomName() {
  return `${randomItem(FIRST_NAMES)}${randomItem(LAST_NAMES)}`;
}
function randomDigits(length) {
  return Array.from({ length }, () => String(randomInt(0, 9))).join("");
}
function randomItem(items) {
  return items[randomInt(0, items.length - 1)];
}
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/features/link-extractor/checkout.ts
var CHECKOUT_URL = "https://chatgpt.com/backend-api/payments/checkout";
var ACCESS_TOKEN_RE = /"accessToken"\s*:\s*"([^"]+)"/;
var ACCESS_TOKEN_LOOSE_RE = /"accessToken"\s*:\s*"?([A-Za-z0-9_.-]+)/;
var JWT_RE = /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/;
var CHECKOUT_SESSION_RE = /(cs_(?:live|test)_[A-Za-z0-9]+)/;
var PROCESSOR_ENTITY_RE = /(?:\/checkout\/|processor_entity=)([A-Za-z0-9_]+)/;
var REGION_BILLING = {
  US: { country: "US", currency: "USD" },
  ID: { country: "ID", currency: "IDR" },
  DE: { country: "DE", currency: "EUR" },
  JP: { country: "JP", currency: "JPY" }
};
var DEFAULT_CHECKOUT_OPTIONS = {
  planName: "chatgptplusplan",
  uiMode: "custom",
  region: "US",
  workspaceName: "MyTeam",
  seatQuantity: 5
};
function extractAccessToken(raw) {
  const text = String(raw || "").trim();
  if (!text) {
    throw new Error("\u8BF7\u8F93\u5165\u5305\u542B accessToken \u7684 JSON \u6216\u5B57\u7B26\u4E32");
  }
  const token = extractFromJson(text) || extractFromAccessTokenField(text) || extractFirstJwt(text);
  if (!token) {
    throw new Error("\u672A\u627E\u5230 accessToken");
  }
  if (token.split(".").length !== 3) {
    throw new Error("accessToken \u683C\u5F0F\u4E0D\u6B63\u786E");
  }
  return token;
}
function normalizeCheckoutOptions(value) {
  const source = isRecord(value) ? value : {};
  return {
    planName: normalizePlanName(source.planName),
    uiMode: normalizeUiMode(source.uiMode),
    region: normalizeRegion(source.region || source.country),
    workspaceName: String(source.workspaceName || source.workspace_name || DEFAULT_CHECKOUT_OPTIONS.workspaceName).trim() || DEFAULT_CHECKOUT_OPTIONS.workspaceName,
    seatQuantity: normalizeSeatQuantity(source.seatQuantity)
  };
}
async function createCheckoutLink(raw, optionsInput) {
  let token;
  let checkoutOptions;
  let payload;
  try {
    token = extractAccessToken(raw);
    checkoutOptions = normalizeCheckoutOptions(optionsInput);
    payload = buildCheckoutPayload(checkoutOptions);
  } catch (error) {
    return fail(errorMessage2(error));
  }
  let response;
  try {
    response = await fetch(CHECKOUT_URL, {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload),
      credentials: "omit"
    });
  } catch (error) {
    return fail(`ChatGPT checkout \u8BF7\u6C42\u5931\u8D25\uFF1A${String(error)}`);
  }
  const text = await response.text();
  const data = parseJsonResponse(text);
  if (!response.ok) {
    return fail(`ChatGPT checkout HTTP ${response.status}\uFF1A${extractResponseError(data, text)}`);
  }
  if (!isRecord(data)) {
    return fail("ChatGPT checkout \u54CD\u5E94\u4E0D\u662F JSON \u5BF9\u8C61");
  }
  const result = extractCheckoutResult(data, checkoutOptions);
  const link = selectOutputLink(result, checkoutOptions.uiMode);
  if (!link) {
    return fail(`\u672A\u627E\u5230\u8BA2\u9605\u94FE\u63A5\uFF0C\u54CD\u5E94\u5B57\u6BB5\uFF1A${Object.keys(data).slice(0, 12).join(", ") || "\u7A7A"}`);
  }
  return {
    ok: true,
    message: checkoutOptions.uiMode === "hosted" ? "\u957F\u94FE\u63A5\u751F\u6210\u6210\u529F" : "\u77ED\u94FE\u63A5\u751F\u6210\u6210\u529F",
    url: link,
    link,
    longUrl: result.providerUrl,
    shortUrl: result.canonicalUrl,
    providerUrl: result.providerUrl,
    canonicalUrl: result.canonicalUrl,
    uiMode: checkoutOptions.uiMode,
    raw: data,
    source: "chatgpt_checkout",
    planName: checkoutOptions.planName,
    billingDetails: {
      country: result.billingDetails.country,
      currency: result.billingDetails.currency
    },
    responseKeys: Object.keys(data).slice(0, 20)
  };
}
function buildCheckoutPayload(options) {
  const isPlus = options.planName === "chatgptplusplan";
  const billingDetails = billingDetailsForRegion(options.region);
  const payload = {
    entry_point: isPlus ? "all_plans_pricing_modal" : "team_workspace_purchase_modal",
    plan_name: options.planName,
    billing_details: billingDetails,
    cancel_url: "https://chatgpt.com/#pricing",
    checkout_ui_mode: options.uiMode,
    promo_campaign: {
      promo_campaign_id: isPlus ? "plus-1-month-free" : "team-1-month-free",
      is_coupon_from_query_param: false
    }
  };
  if (!isPlus) {
    payload.team_plan_data = {
      workspace_name: options.workspaceName,
      price_interval: "month",
      seat_quantity: options.seatQuantity
    };
  }
  return payload;
}
function normalizePlanName(value) {
  return value === "chatgptplusplan" || value === "chatgptteamplan" ? value : DEFAULT_CHECKOUT_OPTIONS.planName;
}
function normalizeUiMode(value) {
  return value === "hosted" ? "hosted" : "custom";
}
function normalizeRegion(value) {
  const region = String(value || DEFAULT_CHECKOUT_OPTIONS.region).trim().toUpperCase();
  return region === "ID" || region === "DE" || region === "JP" || region === "US" ? region : DEFAULT_CHECKOUT_OPTIONS.region;
}
function normalizeSeatQuantity(value) {
  const quantity = Number(value || DEFAULT_CHECKOUT_OPTIONS.seatQuantity);
  if (!Number.isInteger(quantity) || quantity < 1) {
    throw new Error("team_plan_data.seat_quantity \u5FC5\u987B\u662F\u5927\u4E8E 0 \u7684\u6574\u6570");
  }
  return quantity;
}
function billingDetailsForRegion(region) {
  return REGION_BILLING[region] || REGION_BILLING.US;
}
function extractFromJson(text) {
  try {
    return findAccessToken(JSON.parse(text));
  } catch {
    return "";
  }
}
function findAccessToken(value, depth = 0) {
  if (!isRecord(value) || depth > 4) {
    return "";
  }
  if (typeof value.accessToken === "string") {
    return value.accessToken.trim();
  }
  for (const item of Object.values(value)) {
    const found = findAccessToken(item, depth + 1);
    if (found) {
      return found;
    }
  }
  return "";
}
function extractFromAccessTokenField(text) {
  const quoted = ACCESS_TOKEN_RE.exec(text);
  if (quoted?.[1]) {
    return quoted[1].trim();
  }
  const loose = ACCESS_TOKEN_LOOSE_RE.exec(text);
  if (!loose?.[1]) {
    return "";
  }
  const value = loose[1].trim().replace(/[",}\]\s]+$/, "");
  const jwt = JWT_RE.exec(value);
  return jwt?.[0]?.trim() || value;
}
function extractFirstJwt(text) {
  return JWT_RE.exec(text)?.[0]?.trim() || "";
}
function parseJsonResponse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}
function findProviderUrl(data) {
  for (const key of ["url", "stripe_hosted_url", "checkout_url"]) {
    const value = data[key];
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return "";
}
function extractCheckoutResult(data, options) {
  const providerUrl = findProviderUrl(data);
  const billingDetails = billingDetailsForRegion(options.region);
  const sessionId = findCheckoutSession(data, providerUrl);
  const processorEntity = findProcessorEntity(data, providerUrl, billingDetails.country);
  const canonicalUrl = sessionId && processorEntity ? `https://chatgpt.com/checkout/${processorEntity}/${sessionId}` : "";
  return {
    providerUrl,
    canonicalUrl,
    billingDetails
  };
}
function selectOutputLink(result, uiMode) {
  if (uiMode === "hosted") {
    return result.providerUrl || result.canonicalUrl;
  }
  return result.canonicalUrl || result.providerUrl;
}
function findCheckoutSession(data, providerUrl) {
  const direct = stringValue(data.checkout_session_id) || stringValue(data.session_id);
  if (direct) {
    return direct;
  }
  return extractCheckoutSession([
    providerUrl,
    stringValue(data.success_url),
    stringValue(data.cancel_url),
    stringValue(data.return_url),
    stringValue(data.client_secret)
  ].join(" "));
}
function findProcessorEntity(data, providerUrl, billingCountry) {
  const direct = stringValue(data.processor_entity);
  if (direct) {
    return direct;
  }
  const text = [
    providerUrl,
    stringValue(data.success_url),
    stringValue(data.cancel_url),
    stringValue(data.return_url)
  ].join(" ");
  const match = PROCESSOR_ENTITY_RE.exec(text);
  if (match?.[1]) {
    return match[1];
  }
  return billingCountry === "US" ? "openai_llc" : "openai_ie";
}
function extractCheckoutSession(value) {
  const raw = String(value || "");
  const match = CHECKOUT_SESSION_RE.exec(raw);
  if (match?.[1]) {
    return match[1];
  }
  try {
    return CHECKOUT_SESSION_RE.exec(decodeURIComponent(raw))?.[1] || "";
  } catch {
    return "";
  }
}
function stringValue(value) {
  return typeof value === "string" ? value.trim() : "";
}
function extractResponseError(data, text) {
  let message = "";
  if (isRecord(data)) {
    if (typeof data.detail === "string") {
      message = shorten(data.detail);
    }
    if (typeof data.error === "string") {
      message = shorten(data.error);
    }
    if (isRecord(data.error)) {
      if (typeof data.error.detail === "string") {
        message = shorten(data.error.detail);
      }
      if (typeof data.error.message === "string") {
        message = shorten(data.error.message);
      }
    }
  }
  if (!message) {
    message = shorten(text || "\u8BF7\u6C42\u5931\u8D25");
  }
  return explainStripeCurrencyError(message);
}
function explainStripeCurrencyError(message) {
  if (!/cannot combine currencies on a single customer/i.test(message)) {
    return message;
  }
  return [
    "Stripe \u9650\u5236\uFF1A\u540C\u4E00 customer \u4E0D\u80FD\u6DF7\u7528\u4E0D\u540C\u5E01\u79CD\u3002",
    "\u8FD9\u4E2A\u8D26\u53F7\u5F53\u524D\u5DF2\u6709 USD \u8BA2\u9605/\u4F1A\u8BDD\uFF0C\u5207\u5230\u65E5\u672C\u4F1A\u8BF7\u6C42 JPY\uFF0C\u56E0\u6B64\u88AB Stripe \u62D2\u7EDD\u3002",
    "\u8BF7\u6539\u7528\u6CA1\u6709\u73B0\u6709\u8BA2\u9605\u7684\u8D26\u53F7\uFF0C\u6216\u8005\u5207\u56DE\u7F8E\u56FD\u533A\u57DF\u540E\u518D\u751F\u6210\u3002"
  ].join(" ");
}
function fail(message) {
  return { ok: false, message };
}
function errorMessage2(error) {
  return error instanceof Error ? error.message : String(error);
}
function shorten(text, limit = 600) {
  return String(text || "").replace(/\s+/g, " ").slice(0, limit);
}
function isRecord(value) {
  return Boolean(value && typeof value === "object");
}

// src/features/link-extractor/session.ts
var SESSION_URL = "https://chatgpt.com/api/auth/session";
async function fetchChatGptSession() {
  let response;
  try {
    response = await fetch(SESSION_URL, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include"
    });
  } catch (error) {
    return fail2(`\u65E0\u6CD5\u8BF7\u6C42 ChatGPT session\uFF1A${String(error)}`);
  }
  const text = await response.text();
  const data = parseJson(text);
  if (!response.ok) {
    return fail2(`ChatGPT session HTTP ${response.status}\uFF1A${shorten2(text || response.statusText)}`);
  }
  if (!isRecord2(data)) {
    return fail2("ChatGPT session \u54CD\u5E94\u4E0D\u662F JSON \u5BF9\u8C61");
  }
  const session = extractSessionInfo(data);
  if (!session.accessToken) {
    return {
      ok: false,
      message: session.email ? "\u5DF2\u8BFB\u53D6\u8D26\u53F7\u4FE1\u606F\uFF0C\u4F46 session \u5185\u6CA1\u6709 accessToken" : "\u672A\u8BFB\u53D6\u5230\u767B\u5F55 session",
      session
    };
  }
  return {
    ok: true,
    message: "\u5DF2\u8BFB\u53D6 ChatGPT session",
    session
  };
}
function extractSessionInfo(data) {
  const user = isRecord2(data.user) ? data.user : {};
  const account = isRecord2(data.account) ? data.account : {};
  return {
    email: stringValue2(user.email),
    planType: stringValue2(account.planType) || stringValue2(account.plan_type),
    accessToken: stringValue2(data.accessToken),
    fetchedAt: Date.now()
  };
}
function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}
function stringValue2(value) {
  return typeof value === "string" ? value.trim() : "";
}
function fail2(message) {
  return { ok: false, message };
}
function shorten2(text, limit = 400) {
  return String(text || "").replace(/\s+/g, " ").slice(0, limit);
}
function isRecord2(value) {
  return Boolean(value && typeof value === "object");
}

// entrypoints/background.ts
var DEFAULT_OUTLOOK_API_BASE = "http://127.0.0.1:8787";
var DEFAULT_TIMEOUT_MS = 18e4;
var DEFAULT_INTERVAL_MS = 5e3;
var ASSISTANT_SCRIPT_FILE = "/content-scripts/content.js";
var ASSISTANT_URL_PREFIXES = [
  "https://chatgpt.com/",
  "https://auth.openai.com/",
  "https://pay.openai.com/",
  "https://www.paypal.com/",
  "https://paypal.com/"
];
var background_default = defineBackground(() => {
  installAssistantInjector();
  browser.runtime.onMessage.addListener((message) => {
    if (!isOutlookOtpMessage(message)) {
      if (isCheckoutLinkMessage(message)) {
        return createCheckoutLink(message.raw, message.options);
      }
      if (isChatGptSessionMessage(message)) {
        return fetchChatGptSession();
      }
      if (isRandomAddressMessage(message)) {
        return fetchRandomAddress(message.countryCode, message.city);
      }
      if (isSmsRelayFetchMessage(message)) {
        return fetchSmsRelay(message.url);
      }
      return void 0;
    }
    return waitForOutlookOtp(message);
  });
});
function installAssistantInjector() {
  browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== "complete" || !isAssistantUrl(tab.url)) {
      return;
    }
    setTimeout(() => void injectAssistant(tabId), 300);
  });
  void browser.tabs.query({}).then((tabs) => {
    for (const tab of tabs) {
      if (typeof tab.id === "number" && isAssistantUrl(tab.url)) {
        void injectAssistant(tab.id);
      }
    }
  }).catch((error) => {
    console.debug("[OPX] initial assistant injection skipped", error);
  });
}
async function injectAssistant(tabId) {
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      files: [ASSISTANT_SCRIPT_FILE]
    });
  } catch (error) {
    console.debug("[OPX] assistant injection skipped", { tabId, error });
  }
}
function isAssistantUrl(url) {
  return ASSISTANT_URL_PREFIXES.some((prefix) => url?.startsWith(prefix));
}
async function waitForOutlookOtp(message) {
  const startedAt = message.since ?? Date.now();
  const deadline = Date.now() + (message.timeoutMs ?? DEFAULT_TIMEOUT_MS);
  const intervalMs = message.intervalMs ?? DEFAULT_INTERVAL_MS;
  const apiBase = normalizeApiBase(message.apiBase || DEFAULT_OUTLOOK_API_BASE);
  while (Date.now() <= deadline) {
    const result = await fetchLatestOtp(apiBase, message.accountLine, startedAt);
    if (result.ok && result.code) {
      return result;
    }
    if (!result.ok && result.fatal) {
      return result;
    }
    await delay(intervalMs);
  }
  return {
    ok: false,
    message: "\u7B49\u5F85 Outlook \u9A8C\u8BC1\u7801\u8D85\u65F6"
  };
}
async function fetchLatestOtp(apiBase, accountLine, startedAt) {
  const graphResult = await fetchOtpViaGraph(accountLine, startedAt);
  if (graphResult) {
    return graphResult;
  }
  let response;
  try {
    response = await fetch(`${apiBase}/api/outlook/fetch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        account_line: accountLine,
        limit: 10,
        mailbox: "default",
        query: "OpenAI",
        unseen_only: false,
        mark_seen: false
      })
    });
  } catch (error) {
    return {
      ok: false,
      fatal: true,
      message: `\u65E0\u6CD5\u8FDE\u63A5 Outlook \u672C\u5730 API\uFF1A${String(error)}`
    };
  }
  if (!response.ok) {
    const detail = await readResponseDetail(response);
    return {
      ok: false,
      fatal: true,
      message: `Outlook API \u8FD4\u56DE ${response.status}\uFF1A${detail}`
    };
  }
  const payload = await response.json();
  const startedAtSeconds = startedAt / 1e3;
  const messages = [...payload.messages || []].sort(
    (a, b) => Number(b.received_at || 0) - Number(a.received_at || 0)
  );
  const fresh = messages.find((item) => {
    if (!item.otp) {
      return false;
    }
    const receivedAt = Number(item.received_at || 0);
    return !receivedAt || receivedAt >= startedAtSeconds - 15;
  });
  if (!fresh?.otp) {
    return {
      ok: false,
      message: "\u6682\u672A\u6536\u5230\u65B0\u7684 Outlook \u9A8C\u8BC1\u7801"
    };
  }
  return {
    ok: true,
    code: fresh.otp,
    message: `\u6536\u5230\u9A8C\u8BC1\u7801\uFF1A${fresh.otp}`
  };
}
var GRAPH_TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
var GRAPH_MESSAGES_URL = "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages";
var OTP_RE = /\b(\d{6})\b/;
async function fetchOtpViaGraph(accountLine, startedAt) {
  const parts = accountLine.split("----").map((s) => s.trim());
  if (parts.length < 4 || !parts[2] || !parts[3]) {
    return null;
  }
  const [email, password, clientId, refreshToken] = parts;
  let accessToken;
  try {
    const tokenResponse = await fetch(GRAPH_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        grant_type: "refresh_token",
        refresh_token: refreshToken,
        scope: "https://graph.microsoft.com/Mail.Read offline_access"
      }).toString()
    });
    if (!tokenResponse.ok) {
      const err = await tokenResponse.text();
      console.warn("[OPX Graph] token refresh failed:", tokenResponse.status, err);
      return {
        ok: false,
        fatal: false,
        message: `Graph API token \u5237\u65B0\u5931\u8D25 (${tokenResponse.status})`
      };
    }
    const tokenData = await tokenResponse.json();
    accessToken = tokenData.access_token || "";
    if (!accessToken) {
      return {
        ok: false,
        fatal: false,
        message: "Graph API \u672A\u8FD4\u56DE access_token"
      };
    }
  } catch (error) {
    console.warn("[OPX Graph] token fetch error:", error);
    return {
      ok: false,
      fatal: false,
      message: `Graph API \u8FDE\u63A5\u5931\u8D25\uFF1A${String(error)}`
    };
  }
  try {
    const searchParams = new URLSearchParams({
      "$top": "5",
      "$orderby": "receivedDateTime desc",
      "$filter": `receivedDateTime ge ${new Date(startedAt - 3e4).toISOString()}`,
      "$select": "subject,body,receivedDateTime,from"
    });
    const messagesResponse = await fetch(`${GRAPH_MESSAGES_URL}?${searchParams.toString()}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json"
      }
    });
    if (!messagesResponse.ok) {
      return {
        ok: false,
        fatal: false,
        message: `Graph API \u90AE\u4EF6\u8BFB\u53D6\u5931\u8D25 (${messagesResponse.status})`
      };
    }
    const data = await messagesResponse.json();
    const messages = data.value || [];
    for (const msg of messages) {
      const from = msg.from?.emailAddress?.address || "";
      const subject = msg.subject || "";
      const body = msg.body?.content || "";
      const fullText = `${subject} ${body}`;
      const isOpenAi = from.includes("openai") || subject.toLowerCase().includes("openai") || subject.includes("\u9A8C\u8BC1") || subject.toLowerCase().includes("verify");
      if (!isOpenAi) {
        continue;
      }
      const match = OTP_RE.exec(fullText);
      if (match?.[1]) {
        return {
          ok: true,
          code: match[1],
          message: `Graph API \u6536\u5230\u9A8C\u8BC1\u7801\uFF1A${match[1]}`
        };
      }
    }
    return {
      ok: false,
      message: "\u6682\u672A\u6536\u5230 OpenAI \u9A8C\u8BC1\u7801\u90AE\u4EF6"
    };
  } catch (error) {
    return {
      ok: false,
      fatal: false,
      message: `Graph API \u8BFB\u53D6\u90AE\u4EF6\u5931\u8D25\uFF1A${String(error)}`
    };
  }
}
function isOutlookOtpMessage(message) {
  return Boolean(
    message && typeof message === "object" && message.type === "opx:wait-outlook-otp" && typeof message.accountLine === "string"
  );
}
function isCheckoutLinkMessage(message) {
  return Boolean(
    message && typeof message === "object" && message.type === "opx:create-checkout-link" && typeof message.raw === "string" && typeof message.options === "object"
  );
}
function isChatGptSessionMessage(message) {
  return Boolean(
    message && typeof message === "object" && message.type === "opx:fetch-chatgpt-session"
  );
}
function isRandomAddressMessage(message) {
  return Boolean(
    message && typeof message === "object" && (message.type === "opx:fetch-random-address" || message.type === "opx:fetch-random-us-address")
  );
}
function isSmsRelayFetchMessage(message) {
  return Boolean(
    message && typeof message === "object" && message.type === "opx:fetch-sms-relay" && typeof message.url === "string"
  );
}
async function fetchSmsRelay(url) {
  let parsedUrl;
  try {
    parsedUrl = new URL(url);
    if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
      return {
        ok: false,
        message: "\u63A5\u7801 API \u53EA\u652F\u6301 http/https \u94FE\u63A5"
      };
    }
  } catch {
    return {
      ok: false,
      message: "\u63A5\u7801 API \u94FE\u63A5\u683C\u5F0F\u65E0\u6548"
    };
  }
  let response;
  try {
    response = await fetch(parsedUrl.toString(), {
      method: "GET",
      cache: "no-store"
    });
  } catch (error) {
    return {
      ok: false,
      message: `\u63A5\u7801 API \u8BF7\u6C42\u5931\u8D25\uFF1A${String(error)}`
    };
  }
  const status = response.status;
  const { parsed: detail, text } = await readSmsRelayResponse(response);
  if (!response.ok) {
    return {
      ok: false,
      status,
      message: `\u63A5\u7801 API \u8FD4\u56DE ${status}\uFF1A${text || response.statusText}`,
      text,
      raw: detail
    };
  }
  if (isRecord3(detail)) {
    const data = String(detail.data || "").trim();
    const message = String(detail.msg || detail.message || "OK");
    return {
      ok: isSmsRelaySuccessPayload(detail),
      status,
      message,
      data,
      text,
      raw: detail
    };
  }
  return {
    ok: true,
    status,
    message: "OK",
    data: String(detail || "").trim(),
    text,
    raw: detail
  };
}
async function readSmsRelayResponse(response) {
  const text = await response.text();
  if (!text) {
    return { parsed: "", text: "" };
  }
  try {
    return { parsed: JSON.parse(text), text };
  } catch {
    return { parsed: text, text };
  }
}
function normalizeApiBase(value) {
  return value.replace(/\/+$/, "");
}
async function readResponseDetail(response) {
  try {
    const data = await response.json();
    return data.detail || response.statusText;
  } catch {
    return response.statusText;
  }
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function isRecord3(value) {
  return Boolean(value && typeof value === "object");
}
function isSmsRelaySuccessPayload(value) {
  if (typeof value.success === "boolean") {
    return value.success;
  }
  if (typeof value.ok === "boolean") {
    return value.ok;
  }
  const codeValue = value.code ?? value.status ?? value.statusCode;
  if (codeValue === void 0 || codeValue === null || codeValue === "") {
    return true;
  }
  const code = Number(codeValue);
  if (Number.isNaN(code)) {
    return true;
  }
  return code === 0 || code === 1 || code === 200;
}
export {
  background_default as default
};
